<?php  include"inc/script/headerScript.php"?>
<?php
   $cmrId=Session::get("cmrId");
    if(!isset($_GET['view_orderId']) || $_GET['view_orderId']==NULL) {
       echo "<script>window.location='my_account.php?Purchase';</script>";
    }else{
      $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['view_orderId']);
      $id= base64_decode($_GET['view_orderId']);
      $get_cust_order_byId=$ct->get_cust_order_byId($id,$cmrId);
    }
?>
<!-- header script -->
<?php  include"inc/header_navigation.php"?>
<!-- Page Preloder -->
<?php include"inc/preloader.php";?>
<!-- Header section -->
  <!-- Page Info -->
  <div class="page-info-section page-info">
    <div class="container">
      <div class="site-breadcrumb">
        <a href="index.php">Home</a> /
        <a href="">Customer</a> /
        <a href="#">Profile</a> /
        <span>My Account</span> /
        <span>View Order / Order no "
           <?php
             $get_cust_order_byId =$ct->get_cust_order_byId($id,$cmrId);
             if($get_cust_order_byId){
              while($result=$get_cust_order_byId->fetch_assoc()){
           ?>
		    <?= $result['invoice_no']; ?>
			<?php }}?>
		  " 
		</span>
      </div>
      <img src="assest/img/page-info-art.png" alt="" class="page-info-art">
    </div>
  </div>
  <!-- Page Info end -->
	<!-- Page Info end -->
   <?php
      $active="Account";
      $custlogin=Session::get("custlogin",true);
      if ($custlogin==TRUE) {
   ?>
  <!-- Page -->
      <?php
        $id=Session::get("cmrId");
        $getCustonerInfo=$cmr->getCustonerInfo($id);
        if($getCustonerInfo){
          while ($result=$getCustonerInfo->fetch_assoc()) {
          if (!empty($result['email'])){
      ?>
	<div class="page-area contact-page js--service-section">
      <div class="container-fluid ">
        <div class="row  py-4">
  		   <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
  			  <div class="panel panel-default sidebar_menu">
  				 <div class="panel-heading">
  					<center class="">
  						<img src="<?= $result['pro_pic'] ?>" class="img-responsive" alt="auroraShop picture">
  					</center>
  					<br>
  					<h3 align="center" class="panel-title">
  					 User name:<?= $result['name'] ?>
  					</h3>
  				</div>
  				<div class="panel-body">
  					<ul class="nav nav-pills nav-stacked category_menu">
  						<li class="<?php if(isset($_GET['my_orders'])){echo "menu_active";} ?>">
  							<a href="my_account.php?my_orders">
  							<i class="fa fa-list"></i> My Orders
  						    </a>
  						</li>
  						<li class="<?php if(isset($_GET['edit_account'])){echo "menu_active";} ?>">
  							<a href="my_account.php?edit_account">
  							<i class="fa fa-pencil"></i> Edit Account
  						    </a>
  						</li>
  						<li class="<?php if(isset($_GET['change_pass'])){echo "menu_active";} ?>">
                <a href="my_account.php?change_pass">
                <i class="fa fa-user"></i> Change Passowrd
                  </a>
              </li>
              <li class="<?php if(isset($_GET['savlist'])){echo "menu_active";} ?>">
  							<a href="my_account.php?savlist">
  							<i class="fa fa-heart"></i> Save List
                 <?php
                   $cmrId=Session::get('cmrId');
                   $getsavelist_count=$pd->getsavelist_count($cmrId);
                    if (isset($getsavelist_count)) {
                        echo "$getsavelist_count";
                 }
                 ?>
                 <?php
                   //$cmrId=Session::get("cmrId");
                   //$query="SELECT * FROM  tbl_wlist WHERE cmrId='$cmrId' ORDER BY id DESC";
                   //$result=$db->select($query);
                   //if ($result) {
                  // $count=mysqli_num_rows($result);
                   //echo "(".$count.")";
                   //}else{
                   //echo "(0)";
                   //}
                 ?>
  						    </a>
  						</li>
              <li class="<?php if(isset($_GET['Purchase'])){echo "menu_active";} ?>">
                <a href="my_account.php?Purchase">
                 <i class="fa fa-cart-plus"></i> Purchase
                 <?php
                   $cmrId=Session::get('cmrId');
                   $getall_purchase_count=$ct->getall_purchase_count($cmrId);
                    if (isset($getall_purchase_count)) {
                        echo "$getall_purchase_count";
                 }
                 ?>
               </a>
               </li>
  				<li class="<?php if(isset($_GET['delete_account'])){echo "menu_active";} ?>">
  					<a href="my_account.php?delete_account">
  					<i class="fa fa-trash-o"></i> Delete Account
  					</a>
  			   </li>
               <?php
                if(isset($_GET['logout'])){
                  $cmrId= base64_decode(Session::get("cmrId"));
                  $delData=$ct->delCustomerCart();
                  $delComData=$pd->delCompareData($cmrId);
                  Session::destroy();
                 }
              ?>
  				<li class="">
  				 <a href="?logout=<?= base64_encode(Session::get("cmrId")) ?>">
  					<i class="fa fa-sign-out"></i> Logo Out
  				 </a>
  			    </li>
  			  </ul>
  			 </div>
  			</div>
  	    </div>
       <?php }} }else{
        $msg="<div class='alert alert-danger text-center'>
                <p class='thank_msg'>Customer available on hrer to seen!!</p>
                <p>Please start to Registration to continue shop</p>
                <i class='fa fa-exclamation-triangle font_100 mr-1'></i>
            </div>";
          echo $msg;
        }?>
		<div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
  	       <div class="box2">
          <?php
           $getVat=$cat->getallVat();
           if ($getVat){
               $result=$getVat->fetch_assoc();
               $vat=$result['vatprcnt'];
               //echo $vat;
           }else{
            $msg="<div class='alert
              alert-danger text-center'>
              Something went wrong
              <i class='fa fa-exclamation-triangle font35'> </i>
             </div>";
           echo $msg;
           }
          ?>
		  <?php
		   $cmrId=Session::get("cmrId");
			if(!isset($_GET['view_orderId']) || $_GET['view_orderId']==NULL) {
			   echo "<script>window.location='my_account.php?Purchase';</script>";
			}else{
			  $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['view_orderId']);
			  $id= base64_decode($_GET['view_orderId']);
			  $get_cust_order_byId=$ct->get_cust_order_byId($id,$cmrId);
			}
		  ?>
    	  <?php
            $get_cust_order_byId =$ct->get_cust_order_byId($id,$cmrId);
            if($get_cust_order_byId){
              $ship_chrg=0;
              $qty=0;
              $sum=0;
              while($result=$get_cust_order_byId->fetch_assoc()){
          ?>
	       <form action="" method="post">
           <div class="table-responsive  tbl_scrolY">
		   <h4 class="text-primary view_ttl"><i class="fa fa-user"></i> Your Order Details<small> statistics OverView</small>
             <a href="my_account.php?Purchase" class="btn btn-sm btn-primary"> GO TO BACK</a>
            </h4>
            <hr>
             <h4 class="text-primary">
              <i class="fa fa-bolt fa_color"></i> Your Shiftment Details
             </h4>
              <table class="table cstm_tbl table-bordered table-hover">
        	  	  <tr>
                 <td class="text-bold text-primary">CUSTOMER NAME</td>
                 <td class="text-bold text-primary">
                   <?= $result['fname'];?> <?= $result['lname'];?>
                 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER PHONE</td>
                <td class="text-bold text-primary"><?php echo $result['phone'];?></td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">CUSTOMER ZIP-CODE</td>
                  <td class="text-bold text-primary"><?php echo $result['zip'];?></td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">CUSTOMER ADDRESS</td>
                 <td class="text-bold text-primary"><?php echo $result['addrs'];?></td>
                </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER CITY</td>
                <td class="text-bold text-primary"><?php echo $result['city'];?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER COUNTRY</td>
                <td class="text-bold text-primary"><?php echo $result['country'];?></td>
               </tr>
             </table>
             <h3 class="text-primary view_ttl">
              <i class="fa fa-cart-plus fa_color"></i> Your Order Details
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
               <tr>
                <td class="text-bold text-primary">PRODUCT NAME</td>
                <td class="text-bold text-primary">
                  <?= $result['p_name'];?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT IMAGE</td>
                <td class="text-bold text-primary">
                  <img src="admin/<?= $result['image'];?>" width="60px" height="40px" alt="Product Image">
                </td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">PRODUCT PRICE</td>
                  <td class="text-bold text-primary">Tk.<?= $result['price'] ?></td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">ORDER INVOICE</td>
                 <td class="text-bold text-primary"><?= $result['invoice_no'] ?></td>
                </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT QUANTITY</td>
                <td class="text-bold text-primary"><?= $result['quantity'] ?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT SIZE</td>
                <td class="text-bold text-primary"><?= $result['pro_size'] ?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT SIPPING CHARGE</td>
                <td class="text-bold text-primary"><?= $result['ship_method']?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">ORDER STATUS</td>
                <td class="text-bold text-primary">
                  <?php
                   if ($result['status']=='0'){?>
                    PENDIND
                  <?php }elseif($result['status']=='1'){?>
                    ACCEPTED
                  <?php }else{?>
                    DENIED
                 <?php } ?>
                </td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">ORDER RECIEVED BY</td>
                 <td class="text-bold text-primary">
                   <?php
                     $ordr_accept=$result['ordr_accept'];
                     if(isset($ordr_accept)) {
                      echo $ordr_accept;
                     }else{
                      echo "N/A";
                     }
                    ?>
					<?php
                     $user_role=$result['user_role'];
                     if($user_role=="1") {
                      echo "(Admin)";
                     }elseif($user_role=="2"){
                      echo "(Moderator)";
                     }elseif($user_role=="3"){
                      echo "(Mentor)";
                     }else{
						echo "(N/A)"; 
					 }
                    ?>
                </td>
               </tr>
           </table>
             <table class="table cstm_tbl table-bordered table-hover">
               <h3 class="text-primary view_ttl">
                <i class="fa fa-sign-out fa_color"></i> Your Payment Details
               </h3>
               <tr>
                <td class="text-bold text-primary">PAYMENT STATUS</td>
                <td class="text-bold text-primary">
                  <?php
                   if ($result['status']=='0'){?>
                    PENDING
                  <?php }elseif($result['status']=='1'){?>
                    PAID
                  <?php }else{?>
                    DENIED
                 <?php } ?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">PAYABLE AMOUNT</td>
                <td class="text-bold text-primary">
                  <?php
                    if ($result['status']=='0'){
                    echo "PENDING";
                   }elseif($result['status']=='1'){
                    $total=$result['price'] * $result['quantity'];
                    $qty=$qty+$result['quantity'];
                    $ship=$ship_chrg+$result['ship_method'];
                    $sum=$sum+ $total;
                    $vat=$sum * 0.05;
                    $Subtotal=ceil($sum+$ship+$vat);
                    echo $Subtotal;
                  }else{
                    echo "DENIED";
                  } ?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">SHIPPING METHOD</td>
                <?php
                  if ($result['status']=='0'){ ?>
                 <td class="text-bold text-primary">PENDING</td>
                <?php }else{?>
                 <td class="text-bold text-primary">
                   <?php
                     if ($result['ship_method']=='150'){?>
                      Next day delivery (<?= $result['ship_method'];?>)
                   <?php }elseif($result['ship_method']=='100'){?>
                    Standard delivery (<?= $result['ship_method'];?>)
                   <?php }else{?>
                    Personal Pickup(N/A)
                  <?php } ?>
                 </td>
              <?php  } ?>
               </tr>
               <tr>
                <td class="text-bold text-primary">PAYMENT METHOD</td>
                <?php
                  if ($result['status']=='0'){ ?>
                 <td class="text-bold text-primary">PENDING</td>
               <?php }else{?>
                <td class="text-bold text-primary">
                  <?php
                   if ($result['p_method']=='1'){?>
                    BKASH
                  <?php }elseif($result['p_method']=='2'){?>
                    ROCKET
                  <?php }else{?>
                    (N/A)
                 <?php } ?>
                </td>
              <?php  } ?>
               </tr>
               <tr>
                <td class="text-bold text-primary">PAYMENT DATE</td>
                <?php
                  if ($result['status']=='0'){ ?>
                 <td class="text-bold text-primary">PENDING</td>
                <?php }else{?>
                <td class="text-bold text-primary">
                  <?= $fm->formatDate3($result['date'])?>
                </td>
               <?php  } ?>
               </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT SHIFTED DURATION</td>
                <?php
                  if ($result['status']=='0'){ ?>
                 <td class="text-bold text-primary">PENDING</td>
                <?php }else{?>
                 <td class="text-bold text-primary">
                   <?php
                     if ($result['ship_method']=='150'){?>
                      Next day delivery
                   <?php }elseif($result['ship_method']=='100'){?>
                    Product would be shifted about 1 week
                   <?php }else{?>
                    Personal Pickup
                  <?php } ?>
                 </td>
              <?php  } ?>
               </tr>
             </table>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No Order Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>
      </div>
     </div>
    </div>
    </div>
     <?php }else {
        echo "<script>window.open('login.php','_self')</script>";
        }
       ?>
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>
