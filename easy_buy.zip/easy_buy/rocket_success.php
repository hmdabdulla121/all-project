 <?php
  //if(isset($_GET['customerId'])){
   // $id    =$_GET['customerId'];
    //$price =$_GET['price'];
    //$time  =$_GET['time'];
    //$confirm=$ct->OrderconfirmByCustomer($id,$time,$price);
  //}
  ?>
	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->
  <?php
   $login= Session::get("custlogin");
   if ($login==false) {
    echo "<script>window.location='login.php';</script>";
   }
  ?>

  <!-- Header section -->
  <!-- Page Info -->
  <div class="page-info-section page-info">
    <div class="container">
      <div class="site-breadcrumb">
        <a href="index.php">Home</a> /
        <a href="cart.php">Cart</a> /
        <a href="checkout.php">Check out</a> /
        <span>Rocket Payment Success</span>
      </div>
      <img src="assest/img/page-info-art.png" alt="" class="page-info-art">
    </div>
  </div>
  <!-- Page Info end -->
<section class="success_bg">
  <div class="container">
			<div class="Success">
				<h2 class="text-light">Rocket Payment Success</h2>
				<p class="text-light scsp">Order Successfully finished</p>
				<p><!-- <i class="fa fa-envelope font text-info"></i> --> <img src="assest/img/success.png" width="200" height="100" class="rounded my-1" alt=""></p>
				<p class="text-light">Thanks for purchase.Recieved Your Order Successfully.We will review your order & An email confirmation would be sent to your email with delivery details,Please save this email for furter communication.We will contact you ASAP about 3 business day & with deleviery details.Here is your order details<a href="my_account.php?my_orders" data-placement="top" title="Click here" data-html="true" data-toggle="tooltip" style="color:#6EBFEA;">Visit here!!</a></p>
				<h3 class="pb-1" style="color:#6EBFEA ;text-transform: uppercase;"> have a nice Day!!!</h3>
			  <div class="back text-center">
				<a class="site-btn btn-clear" href="index.php">Go Shop</a>
			 </div>
      </div>
     </div>
  </section>
 <?php include"inc/footer.php"?>
 <?php include"inc/script/footerScript.php"?>
