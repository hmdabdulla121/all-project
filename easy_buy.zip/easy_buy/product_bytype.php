
<?php 
  $active="Shop";
?>
<!-- header script -->
<?php include"inc/script/headerScript.php";?>
<!-- Page Preloder -->
<?php include"inc/preloader.php";?>
 <!-- Header section -->
<?php  include"inc/header_navigation.php"?>
<!-- Header section -->
  <div class="page-info-section page-info">
    <div class="container">
      <div class="site-breadcrumb">
        <a href="index.php">Home</a> / 
        <a href="shop.php">Shop</a> / 
        <span>Category Products</span>
      </div>
      <img src="assest/img/page-info-art.png" alt="" class="page-info-art">
    </div>
  </div>
  <!-- Hero section end -->
  <div class="js--service-section py-4" id="shop_content">
    <div class="container-fluid">
      <div class="row">
       <div class="col-xl-2 col-lg-3 col-md-12  col-sm-12 col-xs-12">
      </div>
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="shop">
  		   <div class="row">
  			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_1'])){
                 $type_1=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_1']);
                 $getProductBytype=$pd->getProd_see_all_type1();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_2'])){
                 $type_2=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_2']);
                 $getProductBytype=$pd->getProd_see_all_type2();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_3'])){
                 $type_3=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_3']);
                 $getProductBytype=$pd->getProd_see_all_type3();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_4'])){
                 $type_4=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_4']);
                 $getProductBytype=$pd->getProd_see_all_type4();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_5'])){
                 $type_5=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_5']);
                 $getProductBytype=$pd->getProd_see_all_type5();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_6'])){
                 $type_6=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_6']);
                 $getProductBytype=$pd->getProd_see_all_type6();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_7'])){
                 $type_7=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_7']);
                 $getProductBytype=$pd->getProd_see_all_type7();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_8'])){
                 $type_8=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_8']);
                 $getProductBytype=$pd->getProd_see_all_type8();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_9'])){
                 $type_9=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_9']);
                 $getProductBytype=$pd->getProd_see_all_type9();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_10'])){
                 $type_10=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_10']);
                 $getProductBytype=$pd->getProd_see_all_type10();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			    <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_11'])){
                 $type_11=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_11']);
                 $getProductBytype=$pd->getProd_see_all_type11();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_12'])){
                 $type_12=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_12']);
                 $getProductBytype=$pd->getProd_see_all_type12();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_13'])){
                 $type_13=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_13']);
                 $getProductBytype=$pd->getProd_see_all_type13();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_14'])){
                 $type_14=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_14']);
                 $getProductBytype=$pd->getProd_see_all_type14();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_15'])){
                 $type_15=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_15']);
                 $getProductBytype=$pd->getProd_see_all_type15();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_16'])){
                 $type_16=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_16']);
                 $getProductBytype=$pd->getProd_see_all_type16();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_17'])){
                 $type_17=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_17']);
                 $getProductBytype=$pd->getProd_see_all_type17();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_18'])){
                 $type_18=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_18']);
                 $getProductBytype=$pd->getProd_see_all_type18();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_19'])){
                 $type_19=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_19']);
                 $getProductBytype=$pd->getProd_see_all_type19();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
			   <?php 
			    //error_reporting(0);
			    if (isset($_GET['type_20'])){
                 $type_20=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['type_20']);
                 $getProductBytype=$pd->getProd_see_all_type20();
		         if($getProductBytype){ 
		          while ($result=$getProductBytype->fetch_assoc()){         
		       ?>
              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
                <div class="product-item">
                 <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                 </figure>
                 <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
                </div>
               </div>
  			   <?php }}} ?>
  			  </div>			
  			</div>			
  		</div>
  	</div>
  </div>
  </div>
  <?php include 'inc/footer.php'; ?>
  <?php include 'inc/script/footerScript.php'; ?>