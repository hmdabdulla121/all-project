<?php 
  $active="Shop";
?>
<!-- header script -->
<?php include"inc/script/headerScript.php";?>
 <!--====serch product line 140==== -->
<?php 
   if (!isset($_GET['search']) || $_GET['search']==NULL) {
	  echo "<script>window.location='index.php?search=null';</script>";
   }else{
	//error_reporting(0);
     $search=$_GET['search'];
     $product_search=$pd->product_search($search);
	 $product_search_count=$pd->product_search_count($search);
   }
?>
<!-- Page Preloder -->
<?php include"inc/preloader.php";?>
  <!-- Header section -->
<?php  include"inc/header_navigation.php"?>
<!-- Header section -->
  <div class="page-info-section page-info">
    <div class="container">
      <div class="site-breadcrumb">
        <a href="index.php">Home</a> / 
        <a href="javascript:void(0)">Search Product</a> / In search of 
        <span>
		"
		<?php
          if(isset($product_search)){
			echo $search;  
		  }
		?>
		" search query out
		<?php
		  if(isset($product_search_count)){
			echo $product_search_count;
		 }
		?> items
		</span>
      </div>
      <img src="assest/img/page-info-art.png" alt="" class="page-info-art">
    </div>
  </div>
  <!-- Hero section end -->
  <div class="js--service-section py-4"" id="shop_content">
    <div class="container-fluid">
      <div class="row">
       <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="shop">
  		   <div class="row">
  			 <?php 
		       $product_search= $pd->product_search($search);
		        if($product_search){ 
		          while ($result=$product_search->fetch_assoc()){         
		       ?>
            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
              <div class="product-item">
                <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">                 
                </figure>
                <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
              </div>
            </div>
  			   <?php }}else{
             $msg ="<div class='col-lg-12 alert alert-danger text-center'>
                      <P class='text-danger  mt-1'>
                        <i class='fa fa-power-off mr-1'>
                          No search query avilabe right now
                        </i>
                      <a href='index.php'>Click here go to home..</a>
                    </P>
                 </div>";
             echo  $msg;
            } ?>
  			  </div>			
  			</div>			
  		</div>
  	</div>
  </div>
  </div>
  <?php include 'inc/footer.php'; ?>
  <?php include 'inc/script/footerScript.php'; ?>