             <?php
                  $cmrId=Session::get("cmrId");
                  if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['update'])){
                      $updateCustomer=$cmr->customerUpdate($_POST,$_FILES,$cmrId);
                }
             ?>
             <center>
                <h2 class="text-success">Edit Your account</h2>
                <p class="text-muted">
                  Ff you have any question, feel free to <a href="contact.php">Contact us.</a>Our Customer Serviec Work <strong>24/7</strong>
                </p>
                <?php
                  if (isset($updateCustomer)) {
                  echo $updateCustomer;
                } ?>
               </center>
               <hr>
               <?php
                 $id=Session::get("cmrId");
                 $getCustonerInfo=$cmr->getCustonerInfo($id);
                 if($getCustonerInfo){
                  while ($result=$getCustonerInfo->fetch_assoc()) {
              ?>
              <form action="" method="POST" enctype="multipart/form-data">
              <div class="form prof_scrolY">
                <div class="form-group">
                  <label for="">Customer Name</label>
                  <input type="text" class="form-control" name="name" value="<?= $result['name'];?>">
                </div>
                <div class="form-group">
                  <label for="">Customer Email</label>
                  <input type="email" class="form-control" name="email" value="<?= $result['email'];?>">
                </div>
                <div class="form-group">
                  <label for="">Customer Country</label>
                  <input type="text" class="form-control" name="country" value="<?= $result['country'];?>">
                </div>
                <div class="form-group">
                  <label for="">Customer city</label>
                  <input type="text" class="form-control" name="city" value="<?= $result['city'];?>">
                </div>
                <div class="form-group">
                  <label for="">Customer Contact</label>
                  <input type="text" class="form-control" name="phone" value="<?= $result['phone'];?>">
                </div>
                <div class="form-group">
                  <label for="">Customer Addresss</label>
                  <input type="text" class="form-control" name="address" value="<?= $result['address'];?>">
                </div>
                <div class="form-group font_height_custom">
                  <label for="">Customer Image</label>
                  <input type="file" class="form-control mb-3 font_height_custom" name="pro_pic">
                    <img src="<?= $result['pro_pic'];?>" width="100" height="100" class="img-responsive editImg" data-toggle="modal" data-target="#preview<?= $result['cstmrId'];?>">
                      <!-- Modal -->
                      <div class="modal fade" id="preview<?= $result['cstmrId'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                          <div class="modal-content">
                            <div class="modal-body cstmodal">
                              <img src="<?= $result['pro_pic'];?>" width="600" height="400" class="img-fluid priview" width="600px" alt="priview">
                            </div>
                          </div>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                      </div>
                   </div>
                </div>
               <div class="text-center">
                  <button type="submit" name="update" class="btn btn-primary btn-lg">
                   <i class="fa fa-user-md"></i> Update Now
                  </button>
                </div>
            </form>

            <?php }} ?>
