	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->

	<!-- Header section -->
	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a> /
				<a href="">Sales</a> /
				<a href="">Bags</a> /
				<a href="cart.php">Cart</a> /
				<span>Checkout</span>
			</div>
			<img src="assest/img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->
	 <?php
	    $custlogin=Session::get("custlogin",true);
	    if ($custlogin==false) {
		echo "<script>window.open('login.php','_self')</script>";
       }
	 ?>
     <?php
        $id=Session::get("cmrId");
        $getCustonerInfo=$cmr->getCustonerInfo($id);
        if($getCustonerInfo){
          while ($result=$getCustonerInfo->fetch_assoc()) {
          if (!empty($result['email'])){
      ?>

	<!-- Page -->
	<div class="page-area contact-page js--service-section">
	<div class="page-area cart-page spad ">
		<div class="container">
		   <?php
		      if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['order'])){
		       error_reporting(0);
		  	   $cmrId=Session::get("cmrId");
		       $orderInsert=$ct->orderInsert($_POST,$cmrId);
			   $delData=$ct->delchkorderdata($cmrId);
		       $getpendorder=$ct->getpendorder($cmrId);
		       if ($getpendorder) {
                 while($result=$getpendorder->fetch_assoc()){
                 if ($result['p_method']=="1" & $result['status']=="0"){
                 	//header("location:www.bkash.com");
                     echo "<script>window.open('bkash_success.php','_self')</script>";
                 }elseif ($result['p_method']=="2" & $result['status']=="0"){
                 	echo "<script>
                 	        window.open('rocket_success.php','_self')
                 	      </script>";
                 }elseif ($result['p_method']=="3" & $result['status']=="0"){
                 	echo "<script>window.open('success.php','_self')</script>";
                 }else{
                	$msg ="<h6 class='alert alert-danger text-dark'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> OPPS SOMTHING WENT WEONG!!
                     </h6>";
                  echo $msg;
                }
               }
               //delete ordr after redirect to bkash
               $delpendorder=$ct->delpendorder($cmrId);
               }
              }
		    ?>
		    <?php if (isset($orderInsert)) {
			      echo $orderInsert;
			} ?>
			 <form action="" method="POST" class="checkout-form">
				<?php
				  $query ="SELECT * FROM tbl_curtorder ORDER BY orderId ASC";
				  $result=$db->select($query);
				  $count=mysqli_num_rows($result);
				  if($count>0){
			    ?>
				<div class="row">
					<div class="col-lg-6">
						<h4 class="checkout-title">Billing Address</h4>
						<div class="row">
							<div class="col-md-6">
								<input type="text" name="fname" placeholder="First Name *">
							</div>
							<div class="col-md-6">
								<input type="text" name="lname" placeholder="Last Name *">
							</div>
							<div class="col-md-12">
								<select name="country">
									<option>Country *</option>
									<option value="USA">USA</option>
									<option value="UK">UK</option>
									<option value="BANGLADESH">BANGLADESH</option>
									<option value="India">India</option>
								</select>
								<input type="text" name="addrs" placeholder="Address *">
								<input type="text" name="zip" placeholder="Zipcode *">
								<select name="city">
								  <option>City/Town *</option>
								  <option value="">City/Town *</option>
								  <option value="Natore">Natore</option>
								  <option value="Dhaka">Dhaka</option>
								</select>
								<input type="text" name="post" placeholder="Post code *">
								<input type="text" name="phone" placeholder="Phone no *">

							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="order-card">
							<div class="order-details">
								<div class="od-warp">
								   <h4 class="checkout-title">Your order</h4>
								   <table class="order-table">
									  <thead>
										<tr>
											<th>Product</th>
											<th>Total</th>
										</tr>
									  </thead>
									  <tbody>
									  	<?php
									      $cmrId=Session::get("cmrId");
							              $getAllOrder=$ct->getcheckoutOrder($cmrId);
							              if ($getAllOrder) {
							                  //error_reporting(0);
							                  $ship_chrg=0;
							                  $qty=0;
							                  $sum=0;
							              while($result=$getAllOrder->fetch_assoc()) {
							            ?>
										 <tr>
										    <td>
										    <?= $fm->textShortrn($result['p_name'],20); ?>
										    </td>
										    <td>Tk.
										    	<?= $result['price'] ?>
                                            </td>
										 </tr>
										 <tr>
										    <td>
										     quantity
										    </td>
										    <td>
										     <?= $result['quantity'];?>
                                            </td>
										 </tr>

										  <tr>
										  	<td>Invoice</td>
										  	<td><?= $result['invoice_no']  ?></td>
										  </tr>
										  <tr class="cart-subtotal">
											<td>Shipping</td>
											<td>
											<?php
											if ($result['ship_method']=='100') {
											   echo "Standard delivery(100)";
											}elseif ($result['ship_method']=='150') {
											   echo "Next day delivery(150)";
											}else{
												 echo "N/A";
										     }
											?>
										  </td>
										  </tr>
										  <?php
                                            $total=$result['price'] * $result['quantity'];
								             $qty=$qty+$result['quantity'];
								             $ship=$ship_chrg+$result['ship_method'];
								             $sum=$sum+ $total;
								             $vat=$sum * 0.05;
								             $Subtotal=ceil($sum+$ship);
								              Session::set("qty",$qty);
								              Session::set("sum",$Subtotal);
										   ?>
										  <?php }}else{
									        $msg="<div class='alert alert-danger text-center'>
									                <p class='thank_msg'>No available cart product here now!!</p>
									                <p>Please start to <a href='shop.php'>Shopping</a> to continue Shopping!!</p>
									                 <i class='fa fa-exclamation-triangle font35'></i>
									            </div>";
									          echo $msg;
									        }?>
										</tbody>
										<tfoot>
									     <?php
						                   $getData=$ct->
						                   getcheckoutOrder($cmrId);
						                   if($getData){
						                  ?>
										  <tr class="order-total">
											<th>Total</th>
											<th>Tk.
                                               <?php
                                                $ship=$ship_chrg+$result['ship_method'];
                                                $vat=$sum * 0.05;
                                                $grand=$Subtotal+$vat;
								                   echo $grand;
                                                ?>
												</th>
											</tr>
										<?php } ?>
										</tfoot>
									</table>
								</div>
								 <div class="payment-method">
								   <div class="pm-item" data-toggle="modal" data-target="#bk_pay_op">
									<input type="radio" name="pm" id="one" value="<?php echo(base64_encode(1));?>">
									  <label for="one">
										<img src="assest/img/bkash.jpg" width="40" height="20" class="mr-1" alt="Bkash">Pay with bkash
								      </label>
								  </div>
								  <div class="pm-item"  data-toggle="modal" data-target="#rk_pay_op">
									<input type="radio" name="pm" id="two" value="<?php echo(base64_encode(2));?>">
									<label for="two"><img src="assest/img/rocket.jpg" width="40" height="20" class="mr-1" alt="Bkash">Pay with Rocket</label>
								  </div>
								  <div class="pm-item">
									<input type="radio" name="pm" id="three" value="<?php echo(base64_encode(3));?>">
									<label for="three"><i class="fa fa-american-sign-language-interpreting mr-1 cs_on_font"></i><span class="cs_title">Cash on delievery</span></label>
								  </div>
								   <button type="submit" name="order" class="site-btn btn-full">Place Order</button>
							  </div>
							</div>
						  </div>
					   </div>
					   <div class="modal fade" id="bk_pay_op" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	                <div class="modal-dialog modal-dialog-centered" role="document">
	                   <div class="modal-content">
	                     <div class="modal-header text-center">
	                       <div class="text-center">
	                       		<img src="assest/img/bkash.jpg" width="100" height="60" class="mr-1" alt="Bkash">
	                       </div>
	                       <h3 class="modal-title" id="exampleModalCenterTitle">Payment with Bkash</h3>
	                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	                        <span aria-hidden="true">&times;</span>
	                       </button>
	                     </div>
	                       <div class="modal-body">
	                       	 <p class="text_pay">Please Pay first to this number <span class="text-success">"01780500809"</span> <span class="text-info">for confirm Order</span></p>
	                          <div class="form-group">
				       		    <input type="text" class="form-control" name="bk_num" placeholder="Enter Bkash Number" >
				       		  </div>
				       		  <div class="form-group">
				       			<input type="text" class="form-control" name="bk_txrId" placeholder="Enter Bkash Transaction Id" >
				       		  </div>
	                      </div>
	                      <div class="modal-footer">
					        <span class="btn btn-secondary" data-dismiss="modal">Close</span>
					        <span class="btn btn-primary" data-dismiss="modal">Ok</span>
					      </div>
	                    </div>
	                 </div>
	              </div>
	              <div class="modal fade" id="rk_pay_op" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	                <div class="modal-dialog modal-dialog-centered" role="document">
	                   <div class="modal-content">
	                     <div class="modal-header text-center">
	                       <div class="text-center">
	                       		<img src="assest/img/rocket.jpg" width="100" height="60" class="mr-1" alt="Bkash">
	                       </div>
	                       <h3 class="modal-title" id="exampleModalCenterTitle">Payment with Rocket</h3>
	                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	                        <span aria-hidden="true">&times;</span>
	                       </button>
	                     </div>
	                       <div class="modal-body">
	                       	 <p class="text_pay">Please Pay first to this number <span class="text-success">"01780500809"</span> <span class="text-info">for confirm Order</span></p>
	                          <div class="form-group">
				       		    <input type="text" class="form-control" name="rk_num" placeholder="Enter Rocket Number" >
				       		  </div>
				       		  <div class="form-group">
				       			<input type="text" class="form-control" name="rk_txrId" placeholder="Enter Rocket Transaction Id" >
				       		  </div>
	                      </div>
	                      <div class="modal-footer">
					        <span class="btn btn-secondary" data-dismiss="modal">Close</span>
					        <span class="btn btn-primary" data-dismiss="modal">Ok</span>
					      </div>
	                    </div>
	                 </div>
	              </div>
					</div>
                 <?php
			      }else{
			      	echo "<script>window.open('index.php','_self')</script>";
			      	//$msg="<div class='alert alert-danger text-center'>
					  //<p class='thank_msg'> You can't perform this action hence there is no product on your cart.No available cart product here right now!!</p>
					  //<p>Please start to <a href='shop.php'>Shopping</a> to continue Shopping!!</p>
					  //<i class='fa fa-exclamation-triangle font35'></i>
                       // </div>";
			   // echo $msg;
				}?>
				</form>
			  </div>
		</div>
	   <?php }} }else{
           $msg="<div class='alert alert-danger text-center'>
                <p class='thank_msg'>You have to be registered member complete ceck out process.Please be a registered member or if you have membership login first!!</p>
                <p>Please start to <a href='cmst_register.php'>Registration</a> or <a href='login.php'>login</a> to continue checkout process!!</p>
                <i class='fa fa-exclamation-triangle font35'></i>
            </div>";
           echo $msg;
          }?>
	    <!-- Page -->
	 	<!-- Footer top section -->
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>
