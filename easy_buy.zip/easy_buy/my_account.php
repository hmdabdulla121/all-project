	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	

  <!-- Header section -->
  <!-- Page Info -->
  <div class="page-info-section page-info">
    <div class="container">
      <div class="site-breadcrumb">
        <a href="index.php">Home</a> /
        <a href="">Customer</a> /
        <a href="#">Profile</a> /
        <span>My Account</span> /
		<span>
		<?php
           if (isset($_GET['my_orders'])) {
              echo "View Your Orders";
           }
		   if (isset($_GET['edit_account'])) {
              echo "Edit Account";
           }
		   if (isset($_GET['change_pass'])) {
              echo "Change Password";
           }
		   if (isset($_GET['savlist'])) {
              echo "Your Wish List";
           }
		   if (isset($_GET['Purchase'])) {
              echo "Your Purchase View";
           }
         ?>
		</span>
      </div>
      <img src="assest/img/page-info-art.png" alt="" class="page-info-art">
    </div>
  </div>
  <!-- Page Info end -->
   <?php
      $active="Account";
      $custlogin=Session::get("custlogin",true);
      if ($custlogin==TRUE) {
   ?>
  <!-- Page -->
      <?php
        $id=Session::get("cmrId");
        $getCustonerInfo=$cmr->getCustonerInfo($id);
        if($getCustonerInfo){
          while ($result=$getCustonerInfo->fetch_assoc()) {
          if (!empty($result['email'])){
      ?>
	<div class="page-area contact-page js--service-section">
      <div class="container-fluid ">
        <div class="row  py-4">
  		   <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
  			  <div class="panel panel-default sidebar_menu">
  				 <div class="panel-heading">
  					<center class="">
  						<img src="<?= $result['pro_pic'] ?>" class="img-responsive" alt="auroraShop picture">
  					</center>
  					<br>
  					<h3 align="center" class="panel-title">
  					 User name:<?= $result['name'] ?>
  					</h3>
  				</div>
  				<div class="panel-body">
  					<ul class="nav nav-pills nav-stacked category_menu">
  						<li class="<?php if(isset($_GET['my_orders'])){echo "menu_active";} ?>">
  							<a href="my_account.php?my_orders">
  							<i class="fa fa-list"></i> My Orders
  						    </a>
  						</li>
  						<li class="<?php if(isset($_GET['edit_account'])){echo "menu_active";} ?>">
  							<a href="my_account.php?edit_account">
  							<i class="fa fa-pencil"></i> Edit Account
  						    </a>
  						</li>
  						<li class="<?php if(isset($_GET['change_pass'])){echo "menu_active";} ?>">
                <a href="my_account.php?change_pass">
                <i class="fa fa-user"></i> Change Passowrd
                  </a>
              </li>
              <li class="<?php if(isset($_GET['savlist'])){echo "menu_active";} ?>">
  				<a href="my_account.php?savlist">
  				<i class="fa fa-heart"></i> Save List
                 <?php
                   $cmrId=Session::get('cmrId');
                   $getsavelist_count=$pd->getsavelist_count($cmrId);
                    if (isset($getsavelist_count)) {
                        echo "$getsavelist_count";
                 }
                 ?>
  				</a>
  			  </li>
              <li class="<?php if(isset($_GET['Purchase'])){echo "menu_active";} ?>">
                <a href="my_account.php?Purchase">
                 <i class="fa fa-cart-plus"></i> Purchase
                 <?php
                   $cmrId=Session::get('cmrId');
                   $getall_purchase_count=$ct->getall_purchase_count($cmrId);
                    if (isset($getall_purchase_count)) {
                        echo "$getall_purchase_count";
                 }
                 ?>
               </a>
               </li>
  				<li class="<?php if(isset($_GET['delete_account'])){echo "menu_active";} ?>">
  					<a href="my_account.php?delete_account">
  					<i class="fa fa-trash-o"></i> Delete Account
  					</a>
  			   </li>
               <?php
                if(isset($_GET['logout'])){
                  $cmrId= base64_decode(Session::get("cmrId"));
                  $delData=$ct->delCustomerCart($cmrId);
                  //$delComData=$pd->delCompareData($cmrId);
                  Session::destroy();
                 }
              ?>
  				<li class="">
  				 <a href="?logout=<?= base64_encode(Session::get("cmrId")) ?>">
  					<i class="fa fa-sign-out"></i> Logo Out
  				 </a>
  			    </li>
  			  </ul>
  			 </div>
  			</div>
  	    </div>
       <?php }} }else{
        $msg="<div class='alert alert-danger text-center'>
                <p class='thank_msg'>Customer available on hrer to seen!!</p>
                <p>Please start to Registration to continue shop</p>
                <i class='fa fa-exclamation-triangle font_100 mr-1'></i>
            </div>";
          echo $msg;
        }?>
  	   <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
  	       <div class="box2">
  	       	 	<?php
                    if (isset($_GET['my_orders'])){
                      include 'my_orders.php';
                    }
                ?>
                <?php
                    if (isset($_GET['pay_offline'])){
                      include 'payOffline.php';
                    }
                ?>
                <?php
                    if (isset($_GET['edit_account'])){
                    	include 'edit_account.php';
                    }
  	       	 	  ?>
                <?php
                    if (isset($_GET['change_pass'])){
                      include 'change_pass.php';
                    }
                ?>
                <?php
                    if (isset($_GET['savlist'])){
                      include 'my_savelist.php';
                    }
                ?>
				<?php
                    if (isset($_GET['Purchase'])){
                      include 'purchase.php';
                    }
                ?>
                <?php
                    if (isset($_GET['delete_account'])){
                      include 'delete_account.php';
                    }
                ?>
  	       	 </div>
           </div>
        </div>
  	   </div>
     <?php }else {
        echo "<script>window.open('login.php','_self')</script>";
        }
       ?>
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>
