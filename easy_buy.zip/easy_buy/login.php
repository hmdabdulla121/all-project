	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->

<!-- Page Info -->
<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.html">Home</a> 
				<span>Login</span>
			</div>
			<img src="assest/img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->


	<!-- Page -->
	<div class="page-area contact-page js--service-section">
		<div class="container spad">
			<div class="text-center contact_head">
				<h4 class="contact-title">Customer Login</h4>
			</div>
			<?php 
			   if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['cms_login'])){
			      $CustomerLogin=$cmr->CustomerLogin($_POST);
			    }
			 ?>
				<div class="row">
					<div class="col-lg-6 col-md-6 offset-lg-3 offset-md-3">
					<?php
						if(isset($CustomerLogin)){
						echo $CustomerLogin;
						}
					?>
					<form action="" class="contact-form" method="POST">
					  <div class="row">
					    <div class="col-md-12">
					     <input type="email" name="cms_email" placeholder="Email *"> 
					    </div>
					    <div class="col-md-12">
						<input type="password" name="cms_pass" placeholder="Password *"> 
					    </div>
					    <div class="col-md-12">
						  <div class="text-center">
							<button type="submit" name="cms_login" class="site-btn btn_login">Login</button>
						  </div>
					    </div>
					    <div class="col-md-12">
					     <div class="pad_20 sign_up_link text_center">
							<p><span>Not a Member?</span><a href="cmst_register.php">Signup Now</a></p>
							<small>Feel any Trouble <a href="contact.php">Contact Us</a> or <a href="forgot_pass.php">forgot Password</a></small>
						 </div>
					    </div>
					  </div>
				    </form>
				</div>
			 </div>
			
		</div>
		<div class="container contact-info-warp">
			<div class="contact-card">
				<div class="contact-info">
					<h4>Shipping & Returnes</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
				<div class="contact-info">
					<h4>Informations</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
			</div>
		</div>
		<div class="map-area">
			<div class="map" id="map-canvas"></div>
		</div>
	</div> 
	<!-- Page end -->
 	<!-- Footer top section -->	
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>