           <?php
              if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['updatePass'])){
                 $cmrId=Session::get("cmrId");
                $customerPassUpdate=$cmr->customerPassUpdate($_POST,$cmrId);
               }
             ?>
               <center>
                <h2 class="text-success">Change Your Password</h2>
                <p class="text-muted">
                  Ff you have any question, feel free to <a href="contact.php">Contact us.</a>Our Customer Serviec Work <strong>24/7</strong>
                </p>
               </center>
               <hr>
                <?php if (isset($customerPassUpdate)) {
                   echo $customerPassUpdate;
                 } ?>
                <form action="" method="POST">
                  <div class="table-responsive tbl_scrolY_changePass">
                     <div class="form-group">
                       <label for="">Your Old Password</label>
                       <input type="password" class="form-control" name="old_pass" placeholder="Old Password">
                     </div>
                     <div class="form-group">
                       <label for="">Your New password</label>
                       <input type="password" class="form-control" name="new_pass" placeholder="New Pasowrd">
                     </div>
                     <div class="form-group">
                       <label for="">Confirm Your New Password</label>
                       <input type="password" class="form-control" name="new_pass_agin" placeholder="Confirm Password">
                     </div>
                 </div>
                 <div class="text-center">
                   <button type="submit" name="updatePass" class="btn btn-primary btn-lg">
                      <i class="fa fa-user-md"></i> Update Now
                   </button>
                 </div>
              </form>
