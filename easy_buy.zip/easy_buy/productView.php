	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->

	<!-- Header section -->
	    <?php
		$cmrId=Session::get("cmrId");
	if (!isset($_GET['shop_proId']) || $_GET['shop_proId']==NULL) {
		echo "<script>window.location='404.php';</script>";
	}else{
		 $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['shop_proId']);
		 $id=base64_decode($_GET['shop_proId']);
	}
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['addcart'])){
    	 error_reporting(0);
      	 $quantity=$_POST['quantity'];
      	 $cs=$_POST['cs'];
      	 $sc=$_POST['sc'];
         $addCart =$ct->addtoCart($quantity,$cs,$sc,$id,$cmrId);
     }
   ?>
   <?php 
    $cmrId=Session::get("cmrId");
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['save_wlId'])){
         $savetWlist= $pd->saveWishListData($id,$cmrId);
    }
  ?>
	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a> /
				   <span>Product View</span> /
				    <?php
					  $getPd= $pd->getSingleProduct($id);
					   if($getPd){
					     while ($result=$getPd->fetch_assoc()){
					?>
				     <span>"<?= $result['p_name'];?>"</span>
			        <?php }}?>
			</div>
			<img src="assest/img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->
	<!-- Page -->
<div class="page-area contact-page js--service-section">
  <div class="page-area product-page spad ">
  <form action="" class="form-horizontal" method="POST" enctype="multipart/form-data">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<?php
					  $getPd= $pd->getSingleProduct($id);
					   if($getPd){
					     while ($result=$getPd->fetch_assoc()){
					?>
					<figure class="pro_fig">
						<img class="product-big-img" src="admin/<?= $result['pro_imageL'];?>" alt="">
					</figure>
				   <?php }} ?>
					<div class="product-thumbs">
						<div class="product-thumbs-track">
							<?php
					          $getPd= $pd->getSingleProduct($id);
					           if($getPd){
					             while ($result=$getPd->fetch_assoc()){
					        ?>
							<div class="pt" data-imgbigurl="admin/<?= $result['pro_imageL'];?>"><img src="admin/<?= $result['pro_imageL'];?>" alt=""></div>
							<div class="pt" data-imgbigurl="admin/<?= $result['pro_imageM'];?>"><img src="admin/<?= $result['pro_imageM'];?>" alt=""></div>
							<div class="pt" data-imgbigurl="admin/<?= $result['pro_imageS'];?>"><img src="admin/<?= $result['pro_imageS'];?>" alt=""></div>
							<?php }} ?>

						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<?php if (isset($addCart)) {
					    echo $addCart;
				    } ?>
					<?php if (isset($savetWlist)) {
					    echo $savetWlist;
				    } ?>
					<?php
					  $getPd= $pd->getSingleProduct($id);
					    if($getPd){
					      while ($result=$getPd->fetch_assoc()){
					?>
					<div class="product-content">
						<h2><?= $result['p_name'];?></h2>
						<div class="pc-meta">
							<h4 class="price">Tk.<?= $result['price'];?></h4>
							<div class="review">
								<div class="rating">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star is-fade"></i>
								</div>
								<span>(2 reviews)</span>
							</div>
						</div>
						<p><?= $result['body'];?></p>
						<div>
							<input type="number" name="quantity" class="form-control" value="1">
						</div>
						<div class="color-choose">
							<span>Colors:</span>
							<div class="cs-item">
								<input type="radio" name="cs" id="black-color" value="black" checked>
								<label class="cs-black" for="black-color"></label>
							</div>
							<div class="cs-item">
								<input type="radio" name="cs" id="blue-color" value="blue">
								<label class="cs-blue" for="blue-color"></label>
							</div>
							<div class="cs-item">
								<input type="radio" name="cs" id="yollow-color" value="yollow">
								<label class="cs-yollow" for="yollow-color"></label>
							</div>
							<div class="cs-item">
								<input type="radio" name="cs" id="orange-color" value="orange">
								<label class="cs-orange" for="orange-color"></label>
							</div>
						</div>
						<div class="size-choose">
							<span>Size:</span>
							<div class="sc-item">
								<input type="radio" name="sc" id="L-size" value="l-size" checked>
								<label for="L-size">L</label>
							</div>
							<div class="sc-item">
								<input type="radio" name="sc" id="XL-size" value="xl-size">
								<label for="XL-size">XL</label>
							</div>
							<div class="sc-item">
								<input type="radio" name="sc" id="XXL-size" value="xxl-size">
								<label for="XXL-size">XXL</label>
							</div>
						</div>
						<button type="submit" class="site-btn btn-line" name="addcart"><i class="fa fa-paper-plane mr-1"></i> ADD TO CART</button>
						<?php
						$cmrId=Session::get("cmrId");
						if ($cmrId) {
						?>
						<button type="submit" name="save_wlId" class="site-btn btn_wish">
			  			  <img src="assest/img/icons/heart.png" alt="">
  							save
			  			</button>
						<?php } ?>
					</div>
				   <?php }} ?>
				</div>
			</div>
			<div class="product-details">
				<div class="row">
					<?php
					  $getPd= $pd->getSingleProduct($id);
					    if($getPd){
					      while ($result=$getPd->fetch_assoc()){
					?>
					<div class="col-lg-10 offset-lg-1">
						<ul class="nav" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="1-tab" data-toggle="tab" href="#tab<?= $result['productId'];?>" role="tab" aria-controls="tab-1" aria-selected="true">Description</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="2-tab" data-toggle="tab" href="#tab2<?= $result['productId'];?>" role="tab" aria-controls="tab-2" aria-selected="false">Additional information</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="3-tab" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">Reviews (0)</a>
							</li>
						</ul>
						<div class="tab-content">
							<!-- single tab content -->
							<div class="tab-pane fade show active" id="tab<?= $result['productId'];?>" role="tabpanel" aria-labelledby="tab-1">
								<p><?= $result['body'];?></p>
							</div>
							<div class="tab-pane fade" id="tab2<?= $result['productId'];?>" role="tabpanel" aria-labelledby="tab-2">
								<p class="text-center no_prev" style="    font-size:20px;padding: 25px 20px;background: #ddd;">No Preview</p>
							</div>
							<div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab-3">
                                <p class="text-center na_all" style="    font-size:20px;padding: 25px 20px;background: #ddd;">N/A</p>
							</div>
						</div>
					</div>
				<?php }} ?>
				</div>
			</div>

			<div class="text-center rp-title">
				<h5>Related products</h5>
			</div>
			<div class="row">
				<?php
					  $getPd= $pd->getShopproduct_like();
					    if($getPd){
					      while ($result=$getPd->fetch_assoc()){
					?>
				  <div class="col-lg-3 col-sm-6 col-xs-6 mb-5">
					<div class="product-item">
						<figure>
							<img src="admin/<?= $result['pro_imageL'];?>" class="proimg" alt="">
							<div class="meta_rel">
								<div class="pi-m-left">
									<a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>">
									<button>quick view</button>
									</a>
								</div>
							</div>
						</figure>
						<div class="product-info text-center">
							<h6><?= $result['p_name'];?></h6>
							<p>Tk.<?= $result['price'];?></p>
							<a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
						</div>
					</div>
				</div>
              <?php }} ?>
			</div>
		</div>
      </form>
	</div>
	<!-- Page end -->
	 	<!-- Footer top section -->
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>
