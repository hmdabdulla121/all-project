<?php include"inc/script/headerScript.php";?>
<?php
   if(isset($_GET['delId'])){
      $id=$_GET['delId'];
	  $cmrId=Session::get("cmrId");
	  $id=base64_decode($_GET['delId']);
	  $delPurchslist=$ct->delPurchslist($id,$cmrId);
	}
?>