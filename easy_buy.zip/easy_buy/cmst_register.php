	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->


	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a> /
				<span>Register</span>
			</div>
			<img src="assest/img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->
  <?php 
   if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['Register'])){
     $registerCustomer=$cmr->customerRegister($_POST,$_FILES);
    }
   ?>

	<!-- Page -->
	<div class="page-area contact-page js--service-section">
	<div class="page-area contact-page">
		<div class="container spad">
			<div class="text-center contact_head">
				<h4 class="contact-title">Customer Registration</h4>
				<small>Be Member to continue shopping and be happy*</small>
				<p class="text-muted">"If You have any questions,feel free to contact us.Our Customer Service work"</p>
			</div>
			<div class="row">
				<div class="col-lg-8 offset-lg-2">
					<?php if (isset($registerCustomer)) {
		             echo $registerCustomer;
		            } ?>
				</div>
			</div>
			<form accept="" method="POST" class="contact-form" enctype="multipart/form-data">
				<div class="row">
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="text" name="name" placeholder="Your Name *"> 
					</div>
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="email" name="email" placeholder="Email *"> 
					</div>
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="password" name="password" placeholder="Password *"> 
					</div>
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="text" name="country" placeholder="Country *"> 
					</div>
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="text" name="city" placeholder="City *"> 
					</div>
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="text" name="phone" placeholder="Contact *"> 
					</div>
					<div class="offset-lg-2 offset-md-2 col-lg-8 col-md-8">
						<input type="file" name="pro_pic">
						<textarea name="address" placeholder="Enter residential address"></textarea> 
					</div>
					<div class="col-md-12">
						<div class="text-center">
							<button type="submit" name="Register" class="site-btn">Register Now</button>
						</div>
					</div>
				</div>
			</form>
		</div>
		<div class="container contact-info-warp">
			<div class="contact-card">
				<div class="contact-info">
					<h4>Shipping & Returnes</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
				<div class="contact-info">
					<h4>Informations</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
			</div>
		</div>
		<div class="map-area">
			<div class="map" id="map-canvas"></div>
		</div>
	</div> 
	<!-- Page end -->


	   <!-- Footer top section -->	
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>