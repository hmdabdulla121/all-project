	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->
	<?php 
  if($_SERVER['REQUEST_METHOD']=='POST') {
	 $cfname=$fm->validation($_POST['cfname']);
	 $clname=$fm->validation($_POST['clname']);
   	 $email=$fm->validation($_POST['email']);
   	 $csubject =$fm->validation($_POST['csubject']);
  	 $msg =$fm->validation($_POST['msg']);

	 $cfname=mysqli_real_escape_string($db->link,$cfname);
	 $clname=mysqli_real_escape_string($db->link,$clname);
     $email=mysqli_real_escape_string($db->link,$email);
     $csubject=mysqli_real_escape_string($db->link,$csubject);
	 $msg =mysqli_real_escape_string($db->link,$msg);
	 $reciver_email="arfanarif796@gmail.com";

     $error="";
    if(empty($cfname)){
    	$error="First Name must not be empty!!";
	}
	elseif(empty($clname)){
    	$error="Last Name must not be empty!!";
    }elseif(empty($email)){
    	$error="Email field must not be empty!!";
    }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
    	$error="Invalid email!!";
	}elseif(empty($csubject)){
    	$error="Massege field must not be empty!!";
    }elseif(empty($msg)){
    	$error="Massege field must not be empty!!";
    }else{
        $query="INSERT INTO tbl_contact (cfname,clname,email,Subject,msg) VALUES('$cfname','$clname','$email','$csubject','$msg')";
		$insert_rows=$db->insert($query);
		//auto message to admin
	    $headers="MIME-Version:1.0"."\r\n";
        $headers.="Content-type:text/html;charset=UTF-8"."\r\n";
		mail($reciver_email,$email,$cfname,$clname,$csubject,$msg);

		//auto reply message from website to client
		$from="smadobd@gmail.com";
		$subject="Welcome to our website";
		$msg="
		  <div class='text-center text-info'>
		     <h5>Thanks for sending us message.ASAP we will reply your massage!!</h5>
		  </div>
		";
		$headers="MIME-Version:1.0"."\r\n";
        $headers.="Content-type:text/html;charset=UTF-8"."\r\n";
		mail($from,$email,$subject,$msg);
    	if ($insert_rows){
			$msg="Message sent successfully!";
    	}else{
    		$error="Message not sent";
    	}
    }
 }
?>
	<!-- Page Info -->
	<div class="page-area contact-page js--service-section">
	<div class="page-info-section page-info ">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.html">Home</a> /
				<span>Contact</span>
			</div>
			<img src="assest/img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->


	<!-- Page -->
	<div class="page-area contact-page">
		<div class="container spad">
			<div class="text-center contact_head">
				<h4 class="contact-title">Get in Touch</h4>
			</div>
			<form method="POST" class="contact-form">
				<div class="row">
					<div class="col-lg-8">
					<?php 
					if($error){
						echo "<h6 class='alert alert-danger'>$error</h6>";
					}
					if($msg){
					   echo "<h6 class='alert alert-success'>$msg</h6>";
					} 
                   ?>
					</div>
					<div class="col-md-6">
						<input type="text" name="cfname" placeholder="First Name *"> 
					</div>
					<div class="col-md-6">
						<input type="text" name="clname" placeholder="Last Name *"> 
					</div>
					<div class="col-md-12">
						<input type="email" name="email" placeholder="Customer E-mail *"> 
					</div>
					<div class="col-md-12">
						<input type="text" name="csubject" placeholder="Subject">
						<textarea name="msg" placeholder="Message"></textarea>
						<div class="text-center">
							<button type="submit" class="site-btn">Send Message</button>
						</div>
					</div>
				</div>
			</form>
		</div>
		<div class="container contact-info-warp">
			<div class="contact-card">
				<div class="contact-info">
					<h4>Shipping & Returnes</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
				<div class="contact-info">
					<h4>Informations</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
			</div>
		</div>
		<div class="map-area">
			<div class="map" id="map-canvas"></div>
		</div>
	</div> 
	<!-- Page end -->


   <!-- Footer top section -->	
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>