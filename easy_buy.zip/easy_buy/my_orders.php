               <div class="table-responsive tbl_scrolY_accnt">
  	       	 	 	<table class="table table-bordered table-hover">
  	       	 	 		<thead> <!--order get by getpendingOrder where cmrId=cmrId-->
                     <?php
                        $cmrId=Session::get("cmrId");
                        $getAllOrder=$ct->getallorder($cmrId);
                        if ($getAllOrder) {
                      ?>
  	       	 	 			<tr>
  	       	 	 				<th>On</th>
  	       	 	 				<th>Due Amount</th>
  	       	 	 				<th>Invoice No</th>
  	       	 	 				<th>Qty</th>
  	       	 	 				<th>Size</th>
  	       	 	 				<th>Order Date</th>
  	       	 	 				<th>Payment Status</th>
  	       	 	 				<th>Order Status</th>
  	       	 	 			</tr>
                    <?php } ?>
  	       	 	 		</thead>
  	       	 	 		<tbody> <!--order get by getpendingOrder where cmrId=cmrId-->
                   <?php
                     $cmrId=Session::get("cmrId");
                     $getAllOrder=$ct->getallorder($cmrId);
                     if ($getAllOrder) {
                      $i=0;
                       while($result=$getAllOrder->fetch_assoc()) {
                      $i++;
                      $add_date=$result['date'];
                    ?>
                    <tr>
                      <td>#<?= $i ?></td>
                      <td>Tk.<?= $result['price'] ?></td>
                      <td><?= $result['invoice_no'] ?></td>
                      <td><?= $result['quantity'] ?></td>
                      <td><?= $result['pro_size'] ?></td>
                      <td>
                        <?php  $unixTimastap=$ago->convertToUnixTimestamp($add_date); ?>
                        <?= "Ordered ".$ago->convertToagoFormate($unixTimastap)." ago ";?>
                      </td>
                       <?php
                         if ($result['status']=='0'){?>
                       <td>Pending</td>
                       <?php }else{?>
                        <td>Paid Confirmed</td>
                       <?php } ?>
                      <td>
                        <?php
                         if ($result['status']=='0'){?>
                        <span readonly class="btn btn-primary btn-sm">Pending</span>
                        <a href="order_cancel.php?ord_dlId=<?= base64_encode($result['orderId']);?>& price=<?= base64_encode($result['price'])?> & time=<?= base64_encode($result['date'])?>" onclick="return confirm('Are You Sure to Cancel Order?');" class="btn btn-success btn-sm"><i class="fa fa-share-square fa_color"></i> Cancel Order</a>
                        <?php }elseif($result['status']=='1'){?>
                        <a href="javasacript:void(0)" readonly class="btn btn-info btn-sm ">Shifted</a>
                       <?php } ?>
                       </td>
                    </tr>
                   <?php }}else{
                      $msg="<div class='alert alert-danger text-center'>
                              <p>No Order Available right now!! <a href='index.php'>Please Continue shopping</a></p>
                              <i class='fa fa-exclamation-triangle font35'></i>
                          </div>";
                        echo $msg;
                      }?>
  	       	 	 		</tbody>
  	       	 	 	</table>
  	       	 	 </div>
