<?php 
  $active="Shop";
?>
<!-- header script -->
<?php include"inc/script/headerScript.php";?>
<!-- header script -->
<?php 
  if (isset($_GET['smado_type_shop'])){
      $smado_type_shop=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['smado_type_shop']);
      $smado_type_shop=base64_decode($_GET['smado_type_shop']);
      $getProductByCat=$pd->getProductByCat($smado_type_shop);
  }
?>
<!-- Page Preloder -->
<?php include"inc/preloader.php";?>
 <!-- Header section -->
<?php  include"inc/header_navigation.php"?>
<!-- Header section -->
<?php  include"inc/page_info.php"?>
  <!-- Hero section end -->
  <div class="js--service-section py-4"" id="shop_content">
    <div class="container-fluid">
      <div class="row">
       <div class="col-xl-2 col-lg-3 col-md-12  col-sm-12 col-xs-12">
        <!-- Header section -->
      </div>
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="shop">
  		   <div class="row">
  			 <?php 
			   error_reporting(0);
		       $getProductByCat= $pd->getProductByCat($smado_type_shop);
		        if($getProductByCat){ 
		          while ($result=$getProductByCat->fetch_assoc()){         
		       ?>
            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-6 mb-5">
              <div class="product-item">
                <figure>
                  <img src="admin/<?= $result['pro_imageL'];?>" alt="" class="proimg">
                </figure>
                <div class="product-info text-center">
                  <h6><?php echo $result['p_name'];?></h6>
                  <a href="">
                      <div class="review">
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star is-fade"></i>
                    </div>
                    <span>(2 reviews)</span>
                  </div>
                  </a>
                  <p>$<?php echo $result['price'];?></p>
                  <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>" class="site-btn btn-line">ADD TO CART</a>
                </div>
              </div>
            </div>
  			   <?php }}else{
             $msg ="<div class='col-lg-12 alert alert-danger text-center'>
                      <P class='text-danger  mt-1'>
                        <i class='fa fa-power-off mr-1'>
                          No product avilabe right now
                        </i>
                      <a href='index.php'>Click here go to home..</a>
                    </P>
                 </div>";
             echo  $msg;
            } ?>
  			  </div>			
  			</div>			
  		</div>
  	</div>
  </div>
  </div>
  <?php include 'inc/footer.php'; ?>
  <?php include 'inc/script/footerScript.php'; ?>