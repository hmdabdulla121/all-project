        <?php 
		      if($_SERVER['REQUEST_METHOD']=='POST') {
				   $activat_web_theme= $ct->activat_web_theme($_POST);
			    }
			  ?>
          <div class="content box">
           <h1 class="text-primary"><i class="fas fa-globe fa_color mr-1"></i> Web Theme Activation <small>statistics OverView</small>
             <a href="userControl.php?theme_view" class="btn btn-primary btn-sm"> <i class="fas fa-eye"></i> View All</a>
 			</h1>
 			<ol class="breadcrumb">
			  <li class="active"><a href="index.php">Dashboard</a></li>
			  <li class="active"><a href="userControl.php?web_theme">Theme </a></li>
			  <li><span class="up_title"><i class="fa fa-plus"></i> Add Your Theme</span></li>
			</ol>
         <?php if(isset($activat_web_theme)){ echo $activat_web_theme;}?>
	        <form action="" method="POST" class="form" enctype="multipart/form-data">
             <div class="table-responsive  tbl_scrolY_theme">
             	<div class="selected_thm text-primary">
             		<h4 class="crnt_th_ttl"> <i class="fas fa-swatchbook fa_color fa-2x mr-1"></i> Current Theme</h4>
             	  <?php 
				   $get_theme=$ct->get_web_theme();
					if($get_theme) {
					   while($result=$get_theme->fetch_assoc()) {
				  ?>
			      <?php if ($result['theme']==1) {?>
            	<div>
            		<input checked type="radio" id="df">
            		<label for="df">Default Theme</label>
            	</div>
            	<div>
            		<input type="radio" id="dg">
            		<label for="dg">Deep Green Theme</label>
            	</div>
            	<div>
            		<input type="radio" id="ds">
            		<label for="ds">Deep sky Theme</label>
            	</div>
            	<?php }elseif ($result['theme']==2) { ?>
            	<div>
            		<input  type="radio" id="df">
            		<label for="df">Default Theme</label>
            	</div>
            	<div>
            		<input checked type="radio" id="dg">
            		<label for="dg">Deep Green Theme</label>
            	</div>
            	<div>
            		<input type="radio" id="ds">
            		<label for="ds">Deep sky Theme</label>
            	</div>
            	 <?php }elseif ($result['theme']==3) { ?>
            	<div>
            		<input  type="radio" id="df">
            		<label for="df">Default Theme</label>
            	</div>
            	<div>
            		<input type="radio" id="dg">
            		<label for="dg">Deep Green Theme</label>
            	</div>
            	<div>
            		<input checked type="radio" id="ds">
            		<label for="ds">Deep sky Theme</label>
            	</div>
            	<?php }?>
               <?php }}?>
            </div>
              <table class="table cstm_tbl table-bordered table-hover">
			    <tr class="text-primary">
			     <td class="text-bold text-primary">Change Theme</td>
			     <td>
				<select name="theme" class="form-control">
					<option value="">--Select Theme--</option>
					<?php 
					  $get_theme=$ct->get_web_theme();
					   if($get_theme) {
					     while($result=$get_theme->fetch_assoc()) {
					 ?>
					<?php if ($result['theme']==1) {?>
					<option selected="selected" value="<?= base64_encode(1)?>">Default</option>
					<option value="<?= base64_encode(2)?>">Deep Green</option>
					<option value="<?= base64_encode(3)?>">Deep sky</option>
					<?php }elseif ($result['theme']==2) { ?>
					<option selected="selected" value="<?= base64_encode(2)?>">Deep Green</option>
					<option value="<?= base64_encode(1)?>">Default</option>
					<option value="<?= base64_encode(3)?>">Deep sky</option>
					 <?php }elseif ($result['theme']==3) { ?>
					<option selected="selected" value="<?= base64_encode(3)?>">Deep sky</option>
					<option value="<?= base64_encode(1)?>">Default</option>
					<option value="<?= base64_encode(2)?>">Deep Green</option>
					<?php }?>
				   <?php }}?>
				</select>
				</td>
			 </tr>
       <tr class="text-primary">
            <td class="text-bold text-primary">Add Theme Title</td>
            <td class="text-bold text-primary">
            <textarea  name="theme_ttl" class="form-control" placeholder="Enter Product Type Title" cols="30" rows="5"></textarea>
            </td>
       </tr>
     </table>
		</div>
    <div class="catbtn">
		 <button type="Submit" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Add Theme</button>
	 </div>
  </form>
</div>
