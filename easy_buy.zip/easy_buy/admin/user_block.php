<?php include 'inc/header.php'; ?>
<?php 
    if(isset($_GET['user_bl_Id'])){
     $user_bl_Id=base64_decode($_GET['user_bl_Id']);
     $user_activation=$al->user_activation($user_bl_Id);
     if(isset($user_activation)) {
	   echo "<script>window.location='userControl.php?view_users';</script>";  
	}     
  }
?>