<div class="content box">
<h1 class="text-primary"><i class="fa fa-users"></i> All Visitors graph <small>statistics OverView</small>
    <span class="sort_view">View by 
      <i class="fas fa-caret-down fa_color"></i>
      <div class="sort_list" id="sort_list">
        <p>View by month</p>
        <p>View by Year</p>
      </div>
    </span>
  </h1>
  <ol class="breadcrumb">
   <h3 class="trafic fa_color">Total Traffic <small class="fa_color">100</small></h3>
   <h3 class="trafic fa_color">Today Traffic <small class="fa_color">100</small></h3>
   <h3 class="trafic fa_color">
    <form action="">
      <input type="date" class="form-control input_sort">
      <button type="submit" class="btn <bt></bt>n-sm btn-primary sort_btn">submit</button>
    </form>
   </h3>
  </ol>
  <div class="row">
  <div class="col-md-6">
	<div id="chart_div"></div>
  </div>
  <div class="col-md-6">
	<canvas id="myChart"></canvas>
  </div>
  
  </div>
</div>
