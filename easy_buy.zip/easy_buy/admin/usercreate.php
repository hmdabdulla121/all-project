<div class="content box">
  <h1 class="text-primary"><i class="fa fa-user-md"></i> Admin Role Assignment <small>statistics OverView</small>
    <a href="userControl.php?view_users" class="btn btn-primary btn-sm"> <i class="fas fa-eye"></i> View</a>
  </h1>
  <ol class="breadcrumb">
    <li class="active"><a href="index.php">Dashboard</a></li>
    <li class="active"><a href="userControl.php?user">User</a></li>
    <li><span class="up_title"><i class="fa fa-plus"></i> Add New User</span></li>
  </ol>
   <?php
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['user'])){
       $addUserAdmin=$al->addUserAdmin($_POST);
     }
    ?>
    <hr>
     <form action="" method="POST">
       <div class="tbl_scrolY_user">
         <?php if(isset($addUserAdmin)){
            echo  $addUserAdmin;
         } ?>
          <table class="table cstm_tbl table-bordered table-hover">
			 <tr class="text-primary">
			   <td class="text-bold text-primary">Enter User Name</td>
			   <td>
			     <input type="text" class="form-control" name="user_name" placeholder="Enter User Name">
			   </td>
			 </tr>
			 <tr class="text-primary">
			     <td class="text-bold text-primary">Enter User Email</td>
			     <td>
				 <input type="email" class="form-control" name="user_email" placeholder="Enter User Email">
				 </td>
			  </tr>
               <tr class="text-primary">
                 <td class="text-bold text-primary">Enter User Password</td>
                 <td class="text-bold text-primary">
                   <input type="password" class="form-control" name="user_pass" placeholder="Enter Pasowrd">
                 </td>
               </tr>
				       <tr class="text-primary">
                 <td class="text-bold text-primary">Enter User Role</td>
                 <td class="text-bold text-primary">
                <select class="form-control text-primary" name="user_role">
				          <option value="">Selcet Role</option>
				          <option value="<?= base64_encode(1)?>">Admin</option>
				          <option value="<?= base64_encode(2)?>">Moderator</option>
				          <option value="<?= base64_encode(3)?>">Mentor</option>
				         </select>
              </td>
            </tr>
         </table>
         <div class="adn_info_box">
           <h4 class="text-primary" id="adn_click"><i class="fa fa-paperclip"></i> Additional Info 
             <span class="pull-right addn_info">
               <i class="fa fa-caret-down"></i> 
             </span>
            </h4>
            <div class="info_list" id="adn_open">
               <table class="table cstm_tbl table-bordered table-hover">
                 <tr class="text-primary">
                   <td class="text-bold text-primary">USER COUNTRY</td>
                   <td>
                     <input type="text" class="form-control" name="country" placeholder="Enter User Name">
                   </td>
                 </tr>
                 <tr class="text-primary">
                     <td class="text-bold text-primary">USER CITY</td>
                     <td>
                   <input type="text" class="form-control" name="city" placeholder="Enter User Email">
                   </td>
                  </tr>
                 <tr class="text-primary">
                   <td class="text-bold text-primary">USER PHONE</td>
                   <td class="text-bold text-primary">
                     <input type="text" class="form-control" name="phone" placeholder="User Phone">
                   </td>
                 </tr>
                 <tr class="text-primary">
                   <td class="text-bold text-primary">USER ADDRESS</td>
                   <td class="text-bold text-primary">
                    <textarea name="adrs" class="form-control" cols="30" rows="4" placeholder="write here.."></textarea> 
                   </td>
                 </tr>
             </table>
            </div>
         </div>
      </div>
      <div class="text-center mt-4">
        <button type="submit" name="user" class="btn btn-primary btn-lg">
           <i class="fa fa-user-md"></i> Create User
        </button>
      </div>
     </form>
    </div>
