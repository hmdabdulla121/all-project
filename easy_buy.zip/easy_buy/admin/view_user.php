<?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <?php include 'inc/left_part.php'; ?>
      </div>
         <div class="col-sm-12 col-lg-9 col-md-9 col-xs-12" id="bg_light">
          <div class="content box">
            <h1 class="text-primary"><i class="fa fa-user-md"></i> User Information View <small>statistics OverView</small>
             <a href="userControl.php?view_users" class="btn btn-sm btn-primary">BACK TO VIEW</a>
            </h1>
            <hr>
           <?php
            if(!isset($_GET['userview_Id']) || $_GET['userview_Id']==NULL) {
               echo "<script>window.location='userControl.php?view_users';</script>";
           }else{
              $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['userview_Id']);
              $id= base64_decode($_GET['userview_Id']);
              $getuserView=$al->getuserView_byId($id);
             }
              if($_SERVER['REQUEST_METHOD']=='POST') {
                echo "<script>window.location='userControl.php?view_users';</script>";
              }
           ?>
    		  <?php
            $getuserView =$al->getuserView_byId($id);
            if($getuserView){
              while($result=$getuserView->fetch_assoc()){
                    $add_date=$result['add_date'];
          ?>
	       <form action="" method="post">
           <div class="table-responsive  tbl_scrolY">
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> User Individual Details
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
        	  	  <tr>
                 <td class="text-bold text-primary">USER NAME</td>
                 <td class="text-bold text-primary">
                   <?= $result['adminUser'];?>
                 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">USER E-MAIL</td>
                <td class="text-bold text-primary"><?php echo $result['adminEmail'];?></td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">USER ROLE</td>
                  <td class="text-bold text-primary">
                    <?php
                    if ($result['user_role']=='1') {
                       echo "Admin";
                     }elseif ($result['user_role']=='2') {
                       echo "Moderator";
                     }else{
                       echo "Mentor";
                     }
                     ?>
                  </td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">USER PASSWORD</td>
                 <td class="text-bold text-primary">
      				 <?php
                  $adminEmail=Session::get("adminEmail");
                  $user_role =Session::get("user_role");
                  $status    =Session::get("status");
                  if($user_role=="1" AND $status=="0"){?>
                <?php echo base64_decode($result['adminPass']);?>
                <?php }elseif($adminEmail AND !$user_role=="1"){?>
                <?php echo base64_decode($result['adminPass']);?>
                <?php }else{
                  echo $result['adminPass'];
                }?>
      				 </td>
              </tr>
               <tr>
                <td class="text-bold text-primary">UESER ADD STATUS</td>
                <td class="text-bold text-primary">
                  <?php  $unixTimastap=$ago->convertToUnixTimestamp($add_date); ?>
                  <?= "Created ".$ago->convertToagoFormate($unixTimastap)." ago ";?>
                </td>
               </tr>
             </table>
             <table class="table cstm_tbl table-bordered table-hover">
               <h3 class="text-primary">
                <i class="fa fa-dashboard"></i> User Additional Details
               </h3>
               <tr>
                <td class="text-bold text-primary">USER COUNTRY</td>
                <td class="text-bold text-primary">
                  <?php
                    if (!$result['country']==''){ ?>
                      <?= $result['country'];?>   
                   <?php }else{
                    echo "N/A";
                  } ?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">USER CITY</td>
                <td  class="text-bold text-primary">
                  <?php
                    if (!$result['city']==''){ ?>
                      <?= $result['city'];?>   
                   <?php }else{
                    echo "N/A";
                  } ?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">USER PHONE</td>
                 <td class="text-bold text-primary">
                   <?php
                    if (!$result['phone']==''){ ?>
                      <?= $result['phone'];?>   
                   <?php }else{
                    echo "N/A";
                  } ?>
                 </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">USER ADDRESS</td>
                <td  class="text-bold text-primary">
                <textarea class="form-control text-primary" cols="30" rows="5">
                  <?php
                    if (!$result['adrs']==''){ ?>
                        <?= $result['adrs'];?>   
                     <?php }else{
                      echo "N/A";
                  } ?>
                </textarea>
                </td>
               </tr>
             </table>
            </div>
            <div class=" mt-5 mb-3">
              <button type="submit" class="btn btn-md btn-primary" name="button">Ok</button>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No Order Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>

   </div>
   </div>
</section>
<?php include 'inc/footer.php'; ?>
