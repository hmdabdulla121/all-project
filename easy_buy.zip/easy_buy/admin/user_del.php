        <?php include 'inc/header.php'; ?>
          <?php 
			if(!isset($_GET['userdlId']) || $_GET['userdlId']==NULL) {
		     echo "<script>window.location='userControl.php?view_users';</script>";
		    }else{
		       $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['userdlId']);
		       $id=base64_decode($_GET['userdlId']);
		    }
			   $delUser=$al->delUser($id);
			if(isset($delUser)) {
		     echo "<script>window.location='userControl.php?view_users';</script>";  
		    }
		  ?>
		<?php include 'inc/footer.php'; ?>