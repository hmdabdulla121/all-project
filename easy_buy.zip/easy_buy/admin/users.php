<div class="content box">
  <h1 class="text-primary"><i class="fa fa-user-md"></i> All role based users <small>statistics OverView</small>
    <span>Total:<?php
       $getuser=$al->getuser();
              if (isset($getuser)) {
                echo "$getuser";
              }
     ?></span>
         <a href="userControl.php?user" class="btn btn-primary btn-sm"> <i class="fas fa-plus"></i> Add</a>
  </h1>
  <ol class="breadcrumb">
    <!-- <li class="active"><a href="index.php">Dashboard</a></li> -->
    <form action="" method="GET">
        <input type="text" class="form-control serch_input" id="user_src" name="search" placeholder="Search Users">
        <button type="submit" class="btn btn-md btn-primary"><i class="fa fa-search"></i></button>
      </form>
  </ol>
  <div class="table-responsive table-responsive-lg table-responsive-md tbl_scrolY_order">
    <table class="table cstm_tbl table-bordered table-hover" id="tbl_user">
      <thead>
        <tr class="text-primary">
          <th>SL:</th>
          <th>User Name</th>
          <th>E-mail</th>
          <th>Role</th>
          <th>Password</th>
          <th>Created date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $getallUser=$al->getallUser();
          if ($getallUser){
            $i=0;
             while ($result=$getallUser->fetch_assoc()){
            $i++;
            $add_date=$result['add_date'];
        ?>
        <tr class="text-primary">
          <td><?= $i;?></td>
          <td><?= $result['adminUser'] ; ?></td>
          <td><?= $result['adminEmail'] ; ?></td>
          <td>
            <?php
            if ($result['user_role']=='1') {
               echo "Admin";
             }elseif ($result['user_role']=='2') {
               echo "Moderator";
             }else{
               echo "Mentor";
             }
             ?>
          </td>
          <td><?= ($result['adminPass']); ?></td>
          <td>
            <?php  $unixTimastap=$ago->convertToUnixTimestamp($add_date); ?>
            <?= "Created ".$ago->convertToagoFormate($unixTimastap)." ago ";?>
          </td>
          <td>
            <a href="view_user.php?userview_Id=<?= base64_encode( $result['adminId']);?>" class="btn btn-info btn-sm"> <i class="fas fa-th-list"></i> View</a>
			 <?php
			   $adminEmail=Session::get("adminEmail");
			   $user_role =Session::get("user_role");
			   $status    =Session::get("status");
			   if($user_role=="1" AND $status=="0"){?>
			   <a href="user_edit.php?userId=<?= base64_encode( $result['adminId']);?>" class="btn btn-primary btn-sm"> <i class="fa fa-edit"></i> Edit</a>
              <a href="user_del.php?userdlId=<?= base64_encode( $result['adminId']);?>" class="btn btn-danger btn-sm" onclick="return confirm('Are You Sure to delete!!')"><i class="fas fa-share-square mr-1"></i> Remove</a>
            <?php 
              if($result['status']==0){ ?>
             <a href="user_block.php?user_bl_Id=<?= base64_encode( $result['adminId']);?>" class="btn btn-success btn-sm" onclick="return confirm('Are You Confirm!!')"><i class="fa fa-power-off"></i> Block</a>
             <?php }elseif ($result['status']=='1') { ?>
              <a href="user_unblock.php?user_unblk_Id=<?= base64_encode( $result['adminId']);?>" class="btn btn-info btn-sm" onclick="return confirm('Are You Confirm!!')">unblock</a>
			 <?php }?>
             <?php } ?>
          </td>
        </tr>
        <?php }}else{
          $msg="<div class='alert alert-danger text-center'>
                   <p class='thank_msg'>No available data here to show in result!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i
               </div>";
          echo $msg;
         }?>
      </tbody>
    </table>
  </div>
</div>
