 <?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
 	<div class="container-fluid">
 	   <div class="row">
 	     <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
 		   <?php include 'inc/left_part.php'; ?>	
 	     </div>
 	     <div class="col-lg-9 col-md-9 col-sm-6 col-xs-12"> 
           <div class="content">
 			<h1 class="text-primary"><i class="fa fa-edit"></i>Update Payment <small>statistics OverView</small>
             <a href="userControl.php?view_Vat=on" class="btn btn-primary btn-sm"> <i class="fas fa-eye"></i> Back to List</a>
 			</h1>
 			<ol class="breadcrumb">
			  <li><a href="index.php">Dashboard</a></li>
			  <li><a href="userControl.php?view_Vat">Vat</a></li>
			  <li><span class="up_title"><i class="fa fa-edit"></i> Update Your Vat</span></li>
			</ol>
			<?php 
				if (!isset($_GET['vatid']) || $_GET['vatid']==NULL) {
					echo "<script>window.location='vatlist.php';</script>";
			}else{
				$id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['vatid']);
				$id=base64_decode($_GET['vatid']);
			}
			    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['upvat'])) {
				   $upvat_name=$_POST['upvat_name'];
				   $up_vat  =$_POST['up_vat'];
				   $up_prcnt=$_POST['up_prcnt'];
				   $up_date =$_POST['up_date'];
				   $updatevat=$cat->vatUpdate($upvat_name,$up_vat,$up_prcnt,$up_date,$id);
				}
			?>
				 <?php 
				    if(isset($updatevat)) {
				    echo $updatevat;
				  } ?>
			  <form action="" method="POST" class="form" enctype="multipart/form-data">
					<div>
						<label for="name" class="pro_lbl">Category Name</label>
						<?php 
			              $getvat =$cat->getvatById($id);
			              if($getvat){
			                 while($result=$getvat->fetch_assoc()){        	
			            ?>
						<input type="text" name="upvat_name" class="form-control" value="<?php echo $result['vatname'];?>">
						<label for="name" class="my_2">Vat</label>
						<input type="text" name="up_vat" class="form-control" value="<?php echo $result['vat'];?>">
						<label for="name" class="my_2">Vat Percent</label>
						<input type="text" name="up_prcnt" class="form-control" value="<?= $result['vatprcnt'];?>">
					   <?php }} ?>
					</div>
					<div>
						<label for="name" class="my_2">Update Date</label>
						<?php 
			              $getvat =$cat->getvatById($id);
			              if($getvat){
			                 while($result=$getvat->fetch_assoc()){        	
			            ?>
						<input type="date" name="up_date" class="form-control">
						<?php }} ?>
					</div>
					<div class="catbtn">
						<button type="Submit" name="upvat" class="btn btn-primary btn-md"><i class="fa fa-paper-plane mr-2"></i> Update Vat</button>
					</div>
			  </form>
		   </div>
 	     </div>
 	   </div>
 	 </div>
 </section>
 <?php include 'inc/footer.php'; ?>