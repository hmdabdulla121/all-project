       <div class="content">
 			<h1 class="text-primary"><i class="fa fa-dashboard"></i>Header Slider  List<small>statistics OverView</small>
 				<span>Total:<?php 
 				   $getPro_intro_slider_count=$cat->getPro_intro_slider_count();
                  if (isset($getPro_intro_slider_count)) {
                  	echo "$getPro_intro_slider_count";
                  }
 				 ?></span>
             <a href="userControl.php?header_slider_add" class="btn btn-primary btn-sm"> <i class="fas fa-plus"></i> Add</a>
 			</h1>
 			<ol class="breadcrumb">
			  	<form action="searchpro_type.php" method="GET">
			  	  <input type="text" class="form-control serch_input" name="search" placeholder="Search Product Category">
			  	  <button type="submit" class="btn btn-md btn-primary"><i class="fa fa-search"></i></button>
			  	</form>
			</ol>
			 <form action="" method="POST" enctype="multipart/form-data">
				 <div class="table-responsive tbl_scrolY">
				  <table class="table table-hover table-bordered table-striped">
					<thead>
					  <tr>
						<th>sL:</th>
                        <th>Slider Title</th>
                        <th>Product Type</th>
						<th>Image</th>
						<th>Date</th>
					    <th>Action</th>
					  </tr>
					</thead>
					<tbody>
					   <?php 
			            $getall_header_slider=$cat->getall_header_slider();
			              if ($getall_header_slider){
			                $i=0;
			                 while ($result=$getall_header_slider->fetch_assoc()){
			                $i++;     	
			           ?>
					  <tr>
						<td><?php echo $i; ?></td>
						<td><?= $fm->textShortrn($result['slider_ttl'],20);?></td>
						<td>
                       <select class="form-control">
					  	<?php
					      $getallPro_type =$cat->getallPro_type();
					       if ($getallPro_type){
					        while ($value=$getallPro_type->fetch_assoc()){
					    ?>
					      <option
						   <?php
		                     if ($result['pro_typeId']==$value['pro_typeId']) { ?>
		                        selected="selected"
		                     <?php
		                       }
		                     ?>  value="<?php echo $value['pro_typeId'] ?>">
						    		    <?php echo $value['product_type'] ?>
					      </option>
					    <?php }} ?>
					    </select>
						</td>
                        <td>
						  <img src="<?= $result['slider_img'];?>" width="45px"  height="35px" alt="">
						</td>
						<td><?php echo $fm->formatDate($result['add_date'])?></td>
						<td>
						<a href="view_header_slider.php?view_head_slId=<?php echo base64_encode($result['hdslId'])?>" class="btn btn-sm btn-success tool_tip">
						<i class="fas fa-th-list"></i>
						View</a>
						<a href="edit_header_slider.php?edit_head_slId=<?php echo base64_encode($result['hdslId'])?>" class="btn btn-sm btn-primary tool_tip_edt"><i class="fas fa-edit mr-1"></i>Edit</a>
						  <a href="delhead_slider.php?del_head_slId=<?php echo base64_encode($result['hdslId'])?>" onclick="return confirm('Are You Sure to delete!!')" class="btn btn-sm btn_dlt tool_tip_del"><i class="fas fa-share-square mr-1"></i>Remove</a>
					    </td>
					  </tr>
					 <?php }}else{
						  $msg="<div class='alert alert-danger text-center'>
			                 <p class='thank_msg'>No available data here to show in result!!</p>
				             <i class='fa fa-exclamation-triangle font35'></i
				           </div>";
		                  echo $msg;
	                    }?>					
					 </tbody>	
					</table>
					</div>
				  </form>
				</div>