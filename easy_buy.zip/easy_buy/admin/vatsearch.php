           <?php include 'inc/header.php'; ?>
           <?php 
			if (!isset($_GET['search']) || $_GET['search']==NULL) {
				echo "<script>window.location='404.php';</script>";
			}else{
				 $search=$_GET['search'];
				 $search_vat =$cat->search_vat($search);
			}
		  ?>
          <section class="dashboard_conent">
		 	<div class="container-fluid">
		 	  <div class="row">
		 	   <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
		 		   <?php include 'inc/left_part.php'; ?>	
		 	   </div>
		 	  <div class="col-lg-9 col-md-9 col-sm-6 col-xs-12"> 
             <div class="content">
 			  <h1 class="text-primary"><i class="fa fa-dashboard"></i> Vat <small>statistics OverView</small>
 				<span>Total:<?php 
 				   $getvat=$cat->getvats();
                  if (isset($getvat)) {
                  	echo "$getvat";
                  }
 				 ?></span>
             <a href="userControl.php?my_Vat" class="btn btn-primary btn-sm"> <i class="fas fa-plus"></i> Add</a>
 			</h1>
 			<ol class="breadcrumb">
			    <form action="vatsearch.php" method="GET">
			  	  <input type="text" id="smado-tbl" data-action="filter" data-filters="#smado-tbl" class="form-control serch_input" name="search" placeholder="Search Product">
			  	  <button type="submit" class="btn btn-md btn-primary"><i class="fa fa-search"></i></button>
			  	</form>
			</ol>
			 <form action="" method="POST" enctype="multipart/form-data">
				 <div class="table-responsive">
				  <table class="table table-hover table-bordered table-striped">
					<thead>
					  <tr>
					  	<th>SL:</th>
						<th>Vat Name</th>
						<th>Vat</th>
						<th>Vat Percent</th>
						<th>Date</th>
					    <th>Action</th>
					  </tr>
					</thead>
					<tbody>
						<?php 
					 	    $search_vat =$cat->search_vat($search);
			                if($search_vat){ 
			                $i=0;
			              	while ($result=$search_vat->fetch_assoc()){
			              	$i++;      		
		                 ?>
					   <tr id="smado-tbl">
					   	 <td><?= $i;?></td>
						 <td><?= $result['vatname'] ; ?></td>
						 <td><?= $result['vat'] ; ?></td>
						 <td><?= $result['vatprcnt'];?>%</td>
						 <td><?php echo $fm->formatDate($result['add_date'])?></td>
						 <td>
						  <a href="vatedit.php?vatid=<?= base64_encode($result['vatId'])?>" class="btn btn-sm btn-primary">Edit</a>
						  <a href="delvat.php?delvat=<?= base64_encode($result['vatId'])?>" onclick="return confirm('Are You Sure to delete!!')" class="btn btn-sm btn_dlt">Del</a>
					     </td>
					   </tr>
					  <?php }} ?>					
					 </tbody>	
				  </table>
				</div>
			  </form>
		    </div>
 	     </div>
 	   </div>
 	 </div>
 </section>
 <?php include 'inc/footer.php'; ?>