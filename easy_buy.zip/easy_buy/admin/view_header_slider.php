<?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <?php include 'inc/left_part.php'; ?>
      </div>
         <div class="col-sm-12 col-lg-9 col-md-9 col-xs-12" id="bg_light">
          <div class="content box">
            <h1 class="text-primary"><i class="fa fa-dashboard"></i> Product Intro Slider View <small>statistics OverView</small>
             <a href="userControl.php?view_header_slider" class="btn btn-sm btn-primary">BACK TO VIEW</a>
            </h1>
            <hr>
           <?php
            if(!isset($_GET['view_head_slId']) || $_GET['view_head_slId']==NULL) {
               echo "<script>window.location='userControl.php?view_header_slider';</script>";
           }else{
              $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['view_head_slId']);
              $id= base64_decode($_GET['view_head_slId']);
              $get_header_slider_ById=$cat->get_header_slider_ById($id);
             }
              if($_SERVER['REQUEST_METHOD']=='POST') {
                echo "<script>window.location='userControl.php?view_header_slider';</script>";
              }
           ?>
            <?php
               $get_header_slider_ById=$cat->get_header_slider_ById($id);
               if($get_header_slider_ById){
                  while($result=$get_header_slider_ById->fetch_assoc()){
                   $add_date=$result['add_date'];
		    ?>
	       <form action="" method="post">
           <div class="table-responsive tbl_scrolY_proslider">
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> PRODUCT HEADER SLIDER DETAILS VIEWS
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
        	  	<tr>
                 <td class="text-bold text-primary">HEADER SLIDER TITLE</td>
                  <td  readonly class="text-bold text-primary">
                   <?= $result['slider_ttl'];?>
                  </td>
                </tr>
               <tr class=" text-primary">
                <td class="text-bold text-primary">Product Type</td>
                <td class="text-bold text-primary">
                  <select class="form-control">
                    <?php
					  $getallPro_type =$cat->getallPro_type();
					    if ($getallPro_type){
					     while ($value=$getallPro_type->fetch_assoc()){
				    ?>
					 <option
				     <?php
		              if ($result['pro_typeId']==$value['pro_typeId']){?>
		                        selected="selected"
		            <?php
		               }
		             ?> value="<?php echo $value['pro_typeId'] ?>">
						       <?php echo $value['product_type'] ?>
				   </option>
					 <?php }} ?>
				  </select>
                </td>
                </tr>
                <tr>
                <td class="text-bold text-primary">HEADER SLIDER ADD STATUS</td>
                <td class="text-bold text-primary">
                  <?php  $unixTimastap=$ago->convertToUnixTimestamp($add_date); ?>
                  <?= "Product added ".$ago->convertToagoFormate($unixTimastap)." ago ";?>
                </td>
               </tr>
              </table>
			  <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
			    <h5 class="img_txt text-center">Header slider  Product</h5>
				<img src="<?php echo $result['slider_img'];?>" style="margin:10px 4px;border:2px solid #ccc;border-radius: 3px;" width="100%" height="220px" alt="Product Image">
              </div>
			 </div>
            <div class=" mt-5 mb-3">
              <button type="submit" class="btn btn-md btn-primary" name="button">Ok</button>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No Order Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>

   </div>
   </div>
</section>
<?php include 'inc/footer.php'; ?>
