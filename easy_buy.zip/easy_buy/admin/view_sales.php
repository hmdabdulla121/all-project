<?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <?php include 'inc/left_part.php'; ?>
      </div>
         <div class="col-sm-12 col-lg-9 col-md-9 col-xs-12" id="bg_light">
          <div class="content box">
            <h1 class="text-primary"><i class="fa fa-dashboard"></i> Sales Report History <small>statistics OverView</small>
             <a href="userControl.php?sales_reports" class="btn btn-sm btn-primary">BACK TO VIEW</a>
			 <a href="userControl.php?sales_reports" class="btn btn-sm btn-info"> <i class="fa fa-print"></i> Print</a>
            </h1>
            <hr>
           <?php
            if(!isset($_GET['v_salesId']) || $_GET['v_salesId']==NULL) {
               echo "<script>window.location='userControl.php?sales_reports';</script>";
           }else{
              $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['v_salesId']);
              $id= base64_decode($_GET['v_salesId']);
              $get_sales_byId =$ct->get_sales_byId($id);
             }
              if($_SERVER['REQUEST_METHOD']=='POST') {
                echo "<script>window.location='userControl.php?sales_reports';</script>";
              }
           ?>
    		  <?php
            $get_sales_byId =$ct->get_sales_byId($id);
            if($get_sales_byId){
              $ship_chrg=0;
              $qty=0;
              $sum=0;
              while($result=$get_sales_byId->fetch_assoc()){
          ?>
	       <form action="" method="post">
           <div class="table-responsive  tbl_scrolY">
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> Order History
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
               <tr>
                <td class="text-bold text-primary">PRODUCT NAME</td>
                <td class="text-bold text-primary">
                  <?= $result['p_name'];?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT IMAGE</td>
                <td class="text-bold text-primary">
                  <img src="<?= $result['image'];?>" width="60px" height="40px" alt="Product Image">
                </td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">PRODUCT PRICE</td>
                  <td class="text-bold text-primary">Tk.<?= $result['price'] ?></td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">ORDER INVOICE</td>
                 <td class="text-bold text-primary"><?= $result['invoice_no'] ?></td>
                </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT SIPPING CHARGE</td>
                <td class="text-bold text-primary"><?= $result['ship_method']?></td>
               </tr>
             </table>
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> Shiftment History
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
        	  	  <tr>
                 <td class="text-bold text-primary">CUSTOMER NAME</td>
                 <td class="text-bold text-primary">
                   <?= $result['fname'];?> <?= $result['lname'];?>
                 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER PHONE</td>
                <td class="text-bold text-primary"><?php echo $result['phone'];?></td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">CUSTOMER ZIP-CODE</td>
                  <td class="text-bold text-primary"><?php echo $result['zip'];?></td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">CUSTOMER ADDRESS</td>
                 <td class="text-bold text-primary"><?php echo $result['addrs'];?></td>
                </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER CITY</td>
                <td class="text-bold text-primary"><?php echo $result['city'];?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER COUNTRY</td>
                <td class="text-bold text-primary"><?php echo $result['country'];?></td>
               </tr>
             </table>
             <table class="table cstm_tbl table-bordered table-hover">
               <h3 class="text-primary">
                <i class="fa fa-dashboard"></i> Payment History
               </h3>
               <tr>
                <td class="text-bold text-primary">PAYMENT STATUS</td>
                <td class="text-bold text-primary">
                  <?php
                   if ($result['status']=='0'){?>
                    PAID
                  <?php }elseif($result['status']=='1'){?>
                    UNPAID
                  <?php }else{?>
                    DENIED
                 <?php } ?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">TOTAL PAYABLE AMOUNT</td>
                <td class="text-bold text-primary">
                  <?php
                    if ($result['status']=='0'){
                     $total=$result['price'] * $result['quantity'];
                     $qty=$qty+$result['quantity'];
                     $ship=$ship_chrg+$result['ship_method'];
                     $sum=$sum+ $total;
                     $vat=$sum * 0.05;
                     $Subtotal=ceil($sum+$ship+$vat);
                     echo $Subtotal;
                    }elseif($result['status']=='1'){
                     echo "N/A";
                    }else{
                    echo "DENIED";
                  } ?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">SHIPPING METHOD</td>
                <?php
                  if ($result['status']=='1'){ ?>
                 <td>N/A</td>
                <?php }else{?>
                 <td class="text-bold text-primary">
                   <?php
                     if ($result['ship_method']=='150'){?>
                      Next day delivery (<?= $result['ship_method'];?>)
                   <?php }elseif($result['ship_method']=='100'){?>
                    Standard delivery (<?= $result['ship_method'];?>)
                   <?php }else{?>
                    Personal Pickup(N/A)
                  <?php } ?>
                 </td>
              <?php  } ?>
               </tr>
               <tr>
                <td class="text-bold text-primary">PAYMENT METHOD</td>
                <?php
                  if ($result['status']=='1'){ ?>
                 <td>N/A</td>
               <?php }else{?>
                <td class="text-bold text-primary">
                  <?php
                   if ($result['p_method']=='1'){?>
                    BKASH
                  <?php }elseif($result['p_method']=='2'){?>
                    ROCKET
                  <?php }else{?>
                    (N/A)
                 <?php } ?>
                </td>
              <?php  } ?>
               </tr>
               <tr>
                <td class="text-bold text-primary">PAYMENT DATE</td>
                <?php
                  if ($result['status']=='1'){ ?>
                 <td>N/A</td>
                <?php }else{?>
                <td class="text-bold text-primary">
                  <?= $fm->formatDate3($result['pay_dt'])?>
                </td>
               <?php  } ?>
               </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT SHIFTED DURATION</td>
                <?php
                  if ($result['status']=='1'){ ?>
                 <td>N/A</td>
                <?php }else{?>
                 <td class="text-bold text-primary">
                   <?php
                     if ($result['ship_method']=='150'){?>
                      Next day delivery
                   <?php }elseif($result['ship_method']=='100'){?>
                    Product would be shifted about 1 week
                   <?php }else{?>
                    Personal Pickup
                  <?php } ?>
                 </td>
              <?php  } ?>
               </tr>
             </table>
            </div>
            <div class=" mt-5 mb-3">
              <button type="submit" class="btn btn-md btn-primary" name="button">Ok</button>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No Order Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>

   </div>
   </div>
</section>
<?php include 'inc/footer.php'; ?>
