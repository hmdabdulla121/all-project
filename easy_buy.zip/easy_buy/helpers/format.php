<?php
// format class
class Format{

  public static function formatDate($date)
     {
	 	return date('M d Y',strtotime($date));
	 }
	// {
	// 	return date('F j,Y,g:i a ',strtotime($date));
	// }
	 public static function formatDate2($date){
	 	return date('g:i a,F j,Y ',strtotime($date));
	 }
	 public static function formatDate3($date){
	 		return date('F j,Y,g:i a ',strtotime($date));
	 }
  public static function textShortrn($text,$limit=400){
		$text=$text." ";
		$text=substr($text,0,$limit);
		$text=substr($text,0,strrpos($text, ' '));
		$text=$text.".....";
		return $text;
	}
  public static function validation($data)
	{
	    $data= trim($data);
	    $data= stripcslashes($data);
	    $data= htmlspecialchars($data);
	    return $data;
	}
  public static function title(){
	  	$path=$_SERVER['script_FILENAME'];
	  	$title=basename($path,'.php');
	  	if ($title=='index') {
	  		$title='home';
	  	}elseif ($title=='contact') {
	  		$title='contact';
	  	}
	  	return $title=ucfirst($title);
   }
   public static function getRealIpUser(){
      switch (true) {
        case (!empty($_SERVER['HTTP_X_REAL_IP'])):return $_SERVER['HTTP_X_REAL_IP'];
        case (!empty($_SERVER['HTTP_CLIENT_IP'])):return $_SERVER['HTTP_CLIENT_IP'];
        case (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])):return $_SERVER['HTTP_X_FORWARDED_FOR'];
        default: return $_SERVER['REMOTE_ADDR'];
      }
    }
 }
?>
