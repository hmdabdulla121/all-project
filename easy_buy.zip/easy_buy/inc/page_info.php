  <div class="page-info-section page-info">
    <div class="container">
      <div class="site-breadcrumb">
        <a href="index.php">Home</a> / 
		<span>
         <?php 
		  if(isset($_GET['smado_cat_shop'])){	
            echo "Category Products List";
		   }elseif(isset($_GET['smado_type_shop'])){
			 echo "Type Products List" ;
		  }
		  ?>
       </span>		 
      </div>
      <img src="assest/img/page-info-art.png" alt="" class="page-info-art">
    </div>
  </div>