          <div>
		  <div class="left_part">
              <?php 
			     $getProduct_catBy_type4=$cat->getProduct_catBy_type11();
			     if(isset($getProduct_catBy_type4)){ 
				   $result=$getProduct_catBy_type4->fetch_assoc();
			    ?>
			   <div class="offer_zone_title">
                <?php echo $result['product_type_tle'] ; ?>
               </div>
               <?php }?>
			   <?php 
			     $getProduct_catBy_type4=$cat->getProduct_catBy_type11();
			     if(isset($getProduct_catBy_type4)){ 
				 while ($result=$getProduct_catBy_type4->fetch_assoc()){
			    ?>
			    <div class="left_menu">
			    <a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>">
				  <?php echo $result['product'];?>
			     <i class="fa fa-angle-right"></i>
			   </a>
			  </div>
			  <?php }}?>
			  <a href="product_bytype.php?type_11" class="see_all">
				  <i class="fa fa-sign-out mr-1"></i> Go to see all
			  </a>
	    </div>
		<span class="left_open left_open11">
		 <i class="fa fa-align-justify fa_color"></i>
		 </span>
		 </div>