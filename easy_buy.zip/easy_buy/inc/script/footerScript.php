<!--====== Javascripts & Jquery ======-->
    <script src="assest/js/jquery-3.3.1.min.js"></script>
	<script src="assest/js/jquery.waypoints.min.js"></script>
	<script src="assest/js/owl.carousel.min.js"></script>
	<script src="assest/js/bootstrap.min.js"></script>
	<script src="assest/js/wow.min.js"></script>
	<script src="assest/js/mixitup.min.js"></script>
	<script src="assest/js/html5shiv.min.js"></script>
	<script src="assest/js/respond.min.js"></script>
	<script src="assest/js/sly.min.js"></script>
	<script src="assest/js/jquery.nicescroll.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCWTIlluowDL-X4HbYQt3aDw_oi2JP0Krc&sensor=false"></script>
	<script src="assest/js/map.js"></script> 
    <script src="assest/js/main.js"></script>
	</body>
</html>