           <div class="row intro_slider owl-carousel">
				<?php 
			     $getallPro_typeBy_type=$cat->getallPro_intro_slider_type14();
			     if($getallPro_typeBy_type){ 
				   $result=$getallPro_typeBy_type->fetch_assoc();
			    ?>
			       <div class="intro_item slide_pro">
						<a href="javscript:void(0)">
						 <figure>
							<img src="admin/<?= $result['slider_img1'];?>" class="proimg" alt="">
						 </figure>
						</a>
					</div>
					<div class="intro_item slide_pro">
						<a href="javscript:void(0)">
						 <figure>
							<img src="admin/<?= $result['slider_img2'];?>" class="proimg" alt="">
						 </figure>
						</a>
					</div>
					<div class="intro_item slide_pro">
						<a href="javscript:void(0)">
						 <figure>
							<img src="admin/<?= $result['slider_img3'];?>" class="proimg" alt="">
						 </figure>
						</a>
					</div>
					<?php }?>
			   </div>