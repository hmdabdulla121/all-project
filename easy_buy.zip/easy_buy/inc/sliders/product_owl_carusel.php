            <div class="row product-slider owl-carousel" id="product-filter">
				  <?php
					  $getPd= $pd->getShopproduct_like();
					    if($getPd){
					      while ($result=$getPd->fetch_assoc()){
					?>
				   <div class="product-slide col-lg-3 col-md-6 col-xs-12">
					<div class="product-item slide_pro text-center">
						<a href="productView.php?shop_proId=<?= base64_encode($result['productId'])?>">
						 <figure>
							<img src="admin/<?= $result['pro_imageL'];?>" class="proimg" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
		                        <a href="productView.php?shop_proId=<?= base64_encode($result['productId'])?>">
									<button>quick view</button>
									</a>
								</div>
							</div>
						  </figure>
						</a>		
					</div>
				  </div>
				<?php }} ?>
			 </div>