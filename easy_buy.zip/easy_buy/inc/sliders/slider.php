               <div class="bd-example">
				  <div id="myCarousel" class="carousel slide" data-ride="carousel">
				    <ol class="carousel-indicators">
					 <?php
                      $getall_header_slider=$cat->getall_header_slider();
                      if($getall_header_slider){
						$i=-1;
                       while($result=$getall_header_slider->fetch_assoc()){
					    $i++;
		             ?>
				      <li data-target="#myCarousel" data-slide-to="<?php echo $i; ?>" class="active"></li>
					  <?php }}?>
				      
				    </ol>
				    <div class="carousel-inner">
					 <!-- retrive 0-1=1 image query-->
					<?php
                      $getall_header_slider_home=$cat->getall_header_slider_home();
                      if($getall_header_slider_home){
                       while($result=$getall_header_slider_home->fetch_assoc()){
		             ?>
				      <div class="carousel-item active">
				        <img src="admin/<?= $result['slider_img'];?>" class="d-block w-100" alt="...">
				        <div class="carousel-caption d-md-block">
				          <h5>We are the Largest E-Shopper BD</h5>
				          <p>Get More and Save More!!.</p>
				        </div>
				      </div>
					   <?php }}?>
					   <!-- retrive 1-6=7 image query-->
				       <?php
                        $getall_header_slider_home1to6=$cat->getall_header_slider_home1to6();
                        if($getall_header_slider_home1to6){
                         while($result=$getall_header_slider_home1to6->fetch_assoc()){
		               ?>
				      <div class="carousel-item">
				        <img src="admin/<?= $result['slider_img'];?>" class="d-block w-100" alt="...">
				        <div class="carousel-caption d-md-block">
				          <h5>We are the Largest E-Shopper BD</h5>
				          <p>Get More and Save More!!.</p>
				        </div>
				      </div>
					   <?php }}?>
				    </div>
				    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
				      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				      <span class="sr-only">Previous</span>
				    </a>
				    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
				      <span class="carousel-control-next-icon" aria-hidden="true"></span>
				      <span class="sr-only">Next</span>
				    </a>
				  </div>
				</div>