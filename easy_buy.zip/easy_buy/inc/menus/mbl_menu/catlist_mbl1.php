                         <div class="sub_catM" id="show_mbl_cat<?= $result['pro_typeId']?>">
						   <?php 
			                $getAllproCat=$cat->getProcat_type1_lm_0_10_by_catId();
			                if ($getAllproCat){
			                 while ($result=$getAllproCat->fetch_assoc()){    	
					       ?>
							<a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
							 <?php }}?>
						  </div>