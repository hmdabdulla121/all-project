          <div class="custom_menu">
 	  		<ul>
			  <li class="dropdown need-help"><a href="javascript:void(0)" class="dropdown-toggle">Need?</a> <!-- dropdown-menu -->
			  <ul class="dropdown-menu dropdown-left dropdown-primay dropdown-need-help show-need-help">
					  <li class="menu-content">
					    <div class="dropdown-header">
						 <div class="call_us_now">
						   <div class="phone-icon">
						    <i class="fa fa-phone"></i>
						   </div>
						   <div class="phone-number">
						      Call Us Now : 
							  <span>01780500809</span>
						   </div>
						 </div>
						</div>
						<div class="live_chat">
						  <p>
						   <a href="contact.php">
						   <i class="fa fa-phone"></i>
						   Contact</a>
						  </p>
						  <p>
						    <a href="">
						    <i class="fa fa-angle-right"></i>
						    How to shop on smado?</a>
						  </p>
						   <p>
						  <a href="">
						    <i class="fa fa-angle-right"></i>
						    Live chat</a>
						  </p>
						</div>
						<div class="divider"></div>
					  </li>
					</ul> 
			    </li>
 	  			<li class="dropdown need-help">
 	  				<a href="javascript:avoid(0)" class="help">Account</a>
					<ul class="dropdown-menu dropdown-left dropdown-primay dropdown-need-help show-need-help">
					  <li class="menu-content">
					    <div class="dropdown-header">
						 <div class="call_us_now">
							
						   <div class="phone-icon">
						    <i class="fa fa-user"></i>
						    <span clas="font_17">
							<?php 
                              $c_name= Session::get("c_name");
							  if($c_name){
							     echo $c_name;
							  }else{
                                  echo "Welcome Guest";
							   } ?>
						    </span>
						   </div>	
						 </div>
						</div>
						<div class="User_info">
						<?php
                         if(isset($_GET['cid'])){
                          $cmrId= base64_decode($_GET['cid']);
                          $delData=$ct->delCustomerCart($cmrId);
                          $delchkorderdata=$ct->delchkorderdata($cmrId);
                          $delpendorder=$ct->delpendorder($cmrId);
                          Session::destroy();
                         }
						?>
						<?php
						$login= Session::get("custlogin");
						if ($login==false) {?>
						  <p>
						   <a href="login.php">
						   <i class="fa fa-user"></i>
						   Login</a>
						  </p>
						  <?php }else{?>
							<p>
						   <a href="?cid=<?= base64_encode(Session::get("cmrId")) ?>">
						   <i class="fa fa-sign-out"></i>
						   Log Out</a>
						  </p>
						  <?php }?>
						  <p>
						    <a href="cmst_register.php">
						    <i class="fa fa-edit"></i>
						    Registration</a>
						  </p>
						<?php
						 $login= Session::get("custlogin");
						 if ($login==TRUE) {?>
						   <p>
						   	<p>
						    <a href="my_account.php?savlist">
						       <i class="fa fa-heart-o mr-1"></i>
							   Savelist
							   <?php
							     $cmrId=Session::get('cmrId');
							 	 $getsavelist_count=$pd->getsavelist_count($cmrId);
							     if (isset($getsavelist_count)) {
							        echo "$getsavelist_count";
							        }
							 	?>
						   </a>
						  </p>
						   <p>
						  <a href="cart.php">
						    <i class="fa fa-shopping-cart"></i>
							Your Cart
							(<?php $chkCart=$ct->checkCartTable($cmrId);
					        if ($chkCart){
					            $sum =Session::get("sum");
					            $totalqty =Session::get("qty");
					            echo "$totalqty";
					            }else{
					              echo "0";
					            } ?>)
						  </a>
						  </p>
						  <p>
						  <a href="my_account.php?my_orders">
						    <i class="fa fa-bolt mr-1"></i>
						    Account</a>
						  </p>
						  <p>
						  <a href="my_account.php?Purchase">
						    <i class="fa fa-cart-plus mr-1"></i>
						    Purchase</a>
						  </p>
						  <?php } ?>
						</div>
						<div class="divider"></div>
					  </li>
					</ul> 
 	  			</li>
 	  			<li>
 	  				<a href="cart.php" class="cart_after">
					<span>Cart</span>
					 <i class="fa fa-shopping-cart font24"></i>
					  <span class="cart_qty">
						 <?php $chkCart=$ct->checkCartTable($cmrId);
							if ($chkCart){
								$sum      =Session::get("sum");
								$totalqty =Session::get("qty");
							echo "$totalqty";
							}else{
								echo "0";
							} ?>
					 </span>
					</a>
 	  			</li>
 	  		 </ul>
 	  	    </div>