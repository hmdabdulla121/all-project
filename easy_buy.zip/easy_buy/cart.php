	<!-- header script -->
	<?php  include"inc/script/headerScript.php"?>
	<!-- Page Preloder -->
	<?php include"inc/preloader.php";?>
	<!-- Header section -->
	<?php  include"inc/header_navigation.php"?>	
	<!-- Header section -->

	<!-- Header section -->
	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a> /
				<span>Cart</span>
			</div>
			<img src="assest/img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->
    <?php
	  if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['process'])){
		$cmrId=Session::get("cmrId");
	    $Shipping=$_POST['Shipping'];
	    $custlogin=Session::get("custlogin",true);
	    if ($custlogin==false) {
		echo "<script>window.open('login.php','_self')</script>";
        }else{
	    $chkorderInsert=$ct->chkorderInsert($cmrId,$Shipping);
	    $delData=$ct->delCustomerCart($cmrId);
	    echo "<script>window.open('checkout.php','_self')</script>";
	   }
	   }
	 ?>
     <?php
     if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['crt_dlbtn'])){
       $remove=$_POST['remove'];
       $cartUpdate=$ct->cartUpdate($remove);
       }
	 ?>
	<?php
	 if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['crt_upbtn'])){
	    $cartId  =base64_decode($_POST['cartId']);
	    $quantity=$_POST['quantity'];
	    $updateCart =$ct->CartUdateQuantity($cartId,$quantity);
	    if ($quantity<=0) {
	        $delCart =$ct->delProductByCart($cartId);
	     }
	   }
	 ?>

	<?php
	  if(!isset($_GET['shop'])){
	      echo "<meta http-equiv='refresh' content='0;URL=?shop=live_continue'/>";
	  }
	?>
	<!-- Page -->
	<div class="page-area contact-page js--service-section">
	<div class="page-area cart-page spad ">
	   <form action="" method="POST" enctype="multipart/form-data">
		<div class="container">
			<div class="cart-table">
				<table>
					<thead>
						<tr>
							<th class="product-th">Product</th>
							<th>Price</th>
							<th>Quantity</th>
							<th>Remove</th>
							<th class="total-th">Total</th>
						</tr>
					</thead>
					<tbody>
						<?php
	            $getPro=$ct->getCartProduct($cmrId);
	              if ($getPro){
	                  $i=0;
	                  $sum=0;
	                  $qty=0;
	               while ($result=$getPro->fetch_assoc()){
	                 $i++;
	           ?>
						<tr>
							<td class="product-col">
								<img src="admin/<?= $result['image'];?>" alt="" width="70" height="60">
								<div class="pc-title">
									<h4><?= $result['p_name'];?></h4>
									<a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>">Edit Product</a>
								</div>
							</td>
							<td class="price-col">Tk.<?= $result['price'];?></td>
							<td class="quy-col">
								<div class="quy-input">
									<span>Qty</span>
									<input type="hidden" name="cartId" class="cart_input" value="<?= base64_encode($result['cartId']) ;?>">
									<input type="number" name="quantity" value="<?= $result['quantity'] ?>">
								</div>
							</td>
							<td class="text-center"><input type="checkbox" name="remove[]" value="<?= $result['cartId']?>"></td>
							<td class="total-col">
							Tk.<?php
		              $total=$result['price'] * $result['quantity'];
		               echo $total;
		             ?>
		         </td>
						</tr>
						  <?php
		            $qty=$qty+$result['quantity'];
		            $sum=$sum+ $total;
		            Session::set("qty",$qty);
		            Session::set("sum",$sum);
		           ?>
					   <?php }} ?>
					</tbody>
				</table>
			</div>
			<div class="row cart-buttons">
				<div class="col-lg-5 col-md-5">
					<div class="site-btn btn-continue"><a href="index.php">Continue shooping</a></div>
				</div>
				<div class="col-lg-7 col-md-7 text-lg-right text-left">
					<div class="">
					<button type="submit" name="crt_dlbtn" class="site-btn btn-clear">Clear cart</button>
					<button type="submit" name="crt_upbtn" class="site-btn btn-line btn-update">Update Cart</button>
					</div>
				</div>
			</div>
		  </div>
		</form>
		<div class="card-warp">
			<form action="" method="POST">
			 <div class="container">
				<div class="row">
					<div class="col-lg-4">
						<div class="shipping-info">
							<h4>Shipping method</h4>
							<p>Select the one you want</p>
							<div class="shipping-chooes">
								<div class="sc-item">
									<input type="radio" name="Shipping" id="one" value="150">
									<label for="one">Next day delivery<span>Tk.
                    150</span></label>
								</div>
								<div class="sc-item">
									<input type="radio" name="Shipping" id="two" value="100">
									<label for="two">Standard delivery<span>Tk.100</span></label>
								</div>
								<div class="sc-item">
									<input type="radio" name="Shipping" id="three" value="0">
									<label for="three">Personal Pickup<span>Free</span></label>
								</div>
							</div>
							<h4>Cupon code</h4>
							<p>Enter your cupone code</p>
							<div class="cupon-input">
								<input type="text">
								<button class="site-btn">Apply</button>
							</div>
						</div>
					</div>
					<div class="offset-lg-2 col-lg-6">
						<div class="cart-total-details">
						   <?php
		                     $getData=$ct->checkCartTable($cmrId);
		                    if($getData){
		                   ?>
							<h4>Cart total</h4>
							<p>Final Info</p>
							<ul class="cart-total-card">
								<li>Subtotal<span>Tk.<?= $sum;?></span></li>
								<li>Vat<span>
							          <?php
					               $getVat=$cat->getallVat();
					               if ($getVat){
					                   $result=$getVat->fetch_assoc();
					                   $vat=$result['vatprcnt'];
					                   echo $vat;
					               }else{
                                   $msg="<div class='alert
                                         alert-danger text-center'>
									     Something went wrong
									    <i class='fa fa-exclamation-triangle font35'>
									    </i>
									</div>";
								    echo $msg;
					               }
					             ?>
								%</span></li>
								<li class="total">
								 Total
								  <span>
								  	Tk.
								  	 <?php
					                  $getVat=$cat->getallVat();
					                  if ($getVat){
					                	 $result=$getVat->fetch_assoc();
					                	 $vat=$result['vat'];
					                	 $vat=$sum * $vat;
			                             $Gtotal=ceil($sum+$vat);
			                             echo  $Gtotal;
					                	}else{
                                         $msg="<div class='alert
                                          alert-danger text-center'>
									       Something went wrong
									       <i class='fa fa-exclamation-triangle font35'>
									       </i>
									      </div>";
									    echo $msg;
					                  }
			                        ?>
			                      </span>
			                    </li>
							</ul>
							<button type="submit" name="process" class="site-btn btn-full">Proceed to checkout</button>
							<?php }else{
				              echo "<script>window.open('index.php','_self')</script>";
				             } ?>
						</div>
					</div>
				</div>
			</div>
			</form>
		</div>
	</div>
	<!-- Page end -->
	<!-- Footer top section -->
    <?php include"inc/footer.php"?>
    <?php include"inc/script/footerScript.php"?>
