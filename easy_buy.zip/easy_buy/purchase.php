             <div class="table-responsive tbl_scrolY_accnt">
               <table class="table table-striped table-hover">
		         <thead class="cart-text-color btnc cart-bg">
		 	      <?php
                   $cmrId=Session::get("cmrId");
		           $getall_purchase_list=$ct->getall_purchase_list($cmrId);
                   if ($getall_purchase_list){
                  ?>
		          <th>SL</th>
		          <th>Product</th>
		          <th>Price</th>
		          <th>Image</th>
		          <th>Date</th>
		          <th class="text-center">Action</th>
		         <?php } ?>
		         </thead>
		            <?php
		                $cmrId=Session::get("cmrId");
		                $getall_purchase_list=$ct->getall_purchase_list($cmrId);
		                if($getall_purchase_list){
		                  $i=0;
		                   while($result=$getall_purchase_list->fetch_assoc()){
		                  $i++;
		             ?>
		              <tr>
		                <th><?php echo $i;?></th>
		                <th class="text-bold"><?php echo $result['p_name'] ;?></th>
		                <th>$<?php echo $result['price'] ;?></th>
		                <th class="text-center">
		                  <img src="admin/<?php echo $result['image'];?>" width="60" height="50" alt="">
		                </th>
		                <th class="text-center"><?php echo $fm->formatDate($result['date']);?></th>
		                 <th class="text-center">
						 <a href="cust_order_view.php?view_orderId=<?= base64_encode($result['orderId']);?>">View Order</a> ||
						   <a href="productView.php?shop_proId=<?= base64_encode($result['productId']);?>">Buy Now</a> ||
						   <a href="purchasedel.php?delId=<?= base64_encode($result['orderId']);?>" onclick="return confirm('Are You Sure to delete!!')">
							 <i class="fa fa-trash-o btn btn-sm btn-danger"></i>
						   </a>
						 </th>
		              </tr>
		               <?php }}else{
                      $msg="<div class='alert alert-danger text-center'>
                              <p>No Purchase List Product Available right now!! <a href='index.php'>Please Continue shopping</a></p>
                              <i class='fa fa-exclamation-triangle font35'></i>
                          </div>";
                        echo $msg;
                      }?>
		           </table>
                </div>
