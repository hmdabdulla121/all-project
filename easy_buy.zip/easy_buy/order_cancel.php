<?php include"inc/script/headerScript.php";?>
<?php
if(isset($_GET['ord_dlId'])){
   $id    =base64_decode($_GET['ord_dlId']);
   $price =base64_decode($_GET['price']);
   $time  =base64_decode($_GET['time']);
   $OrderCancel=$ct->OrderCancel($id,$time,$price);
 }
 ?>
 <?php include 'inc/footer.php'; ?>
