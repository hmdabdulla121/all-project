<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/session.php');
    //Session::checklogin();
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
  class Adminlogin{
	 private $db;
	 private $fm;
     public function __construct(){
	   $this->db=new Database();
	   $this->fm=new Format();
   }
   public function addUserAdmin($data){
     $user_name=$this->fm->validation($data['user_name']);
     $user_name=mysqli_real_escape_string( $this->db->link,$data['user_name']);

     $user_email=$this->fm->validation($data['user_email']);
     $user_email=mysqli_real_escape_string( $this->db->link,$data['user_email']);

     $user_pass=$this->fm->validation(base64_encode($data['user_pass']));
     $user_pass=mysqli_real_escape_string($this->db->link,base64_encode($data['user_pass']));
     $user_role=$this->fm->validation($data['user_role']);
     $user_role=mysqli_real_escape_string( $this->db->link,base64_decode($data['user_role']));
     $country=$this->fm->validation($data['country']);
     $country=mysqli_real_escape_string($this->db->link,$data['country']);
     $city=$this->fm->validation($data['city']);
     $city=mysqli_real_escape_string( $this->db->link,$data['city']);
     $phone=$this->fm->validation($data['phone']);
     $phone=mysqli_real_escape_string( $this->db->link,$data['phone']);
     $adrs=$this->fm->validation($data['adrs']);
     $adrs=mysqli_real_escape_string($this->db->link,$data['adrs']);

    if(empty($user_name)||empty($user_email)||empty($user_pass)||empty($user_role)) {
           $msg ="<h6 class='alert alert-danger text-dark'>
                   <i class='fa fa-exclamation-triangle mr-1'>
                   </i> Field must not be empty!!
                 </h6>";
          return $msg;
    }else{
        $query="INSERT INTO tbl_admin(adminUser,adminEmail,adminPass,user_role,country,city,phone,adrs) VALUES('$user_name','$user_email','$user_pass','$user_role','$country','$city','$phone','$adrs')";
        $userInsert=$this->db->insert($query);
        if($userInsert) {
           $msg_success="<h4 class='text-success alert alert-success'>
                          <i class='fa fa-check-circle mr-1'>
                          </i> User Successfully Created!!
                       </h4>";
           return $msg_success;
        }else{
           $msg_error="<h4 class='alert alert-danger'>
                        <i class='fa fa-exclamation-triangle mr-1'>
                        </i> Your action not success please try again!!
                     </h4>";
           return $msg_error;
        }
       }
   }
   public function adminlogin($adminEmail,$adminPass){
       $adminEmail=$this->fm->validation($adminEmail);
       $adminPass=$this->fm->validation($adminPass);
       $adminEmail=mysqli_real_escape_string( $this->db->link, $adminEmail);
       $adminPass=mysqli_real_escape_string( $this->db->link,$adminPass);
       if(empty($adminEmail) || empty($adminPass)) {
       	  $loginerr_msg="<h6 class='alert alert-danger text-dark'>
                          <i class='fa fa-exclamation-triangle mr-1'>
                          </i> Field must not be empty!!
                         </h6>";
       	  return $loginerr_msg;
         }elseif(!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
            $loginerr_msg = "<h6 class='alert alert-danger text-dark'>
                                <i class='fa fa-exclamation-triangle mr-1'>
                                </i> Invalid Email!!
                              </h6>";
            return $loginerr_msg;
         }else{
       	  $query="SELECT* FROM tbl_admin WHERE adminEmail='$adminEmail' AND adminPass='$adminPass'";
       	  $value=$this->db->select($query);
       	   if($value!=false){
       	  	   $value= $value->fetch_assoc();
       	  	   Session::set("adminlogin",true);
       	  	   Session::set("adminId",$value['adminId']);
       	  	   Session::set("adminUser",$value['adminUser']);
       	  	   Session::set("adminEmail",$value['adminEmail']);
               Session::set("user_role",$value['user_role']);
               Session::set("status",$value['status']);
              if ($value['status'] == 0) {
                      header("location:index.php");
              }else{
                $err_msg="<h6 class='alert alert-danger text-dark'>
                         <i class='fa fa-exclamation-triangle mr-1'>
                         </i> something went wrong.please try again later!!
                        </h6>";
                return $err_msg;
              }
       	    }else{
       	  	   $loginerr_msg="<h6 class='alert alert-danger text-dark'>
                                 <i class='fa fa-exclamation-triangle mr-1'>
                                </i> Username and Password not match!!
                              </h6>";
       	      return $loginerr_msg;
       	  }
         }
       }
     public function getallUser(){
       $query="SELECT* FROM tbl_admin WHERE status='0' ORDER BY adminId DESC";
       $result=$this->db->select($query);
       return $result;
     }
      // get all User Count 
     public function getuser(){
       $query="SELECT* FROM tbl_admin WHERE status='0' ORDER BY adminId DESC";
       $result=$this->db->select($query);
          if ($result==true) {
             $count=mysqli_num_rows($result);
             return "(".$count.")";
         }else{
           echo "(empty)";
         }
      }
      public function getall_blockUser(){
       $query="SELECT* FROM tbl_admin  WHERE status='1' ORDER BY adminId DESC";
       $result=$this->db->select($query);
       return $result;
      }
       // get User by  id
      public function getUserById($id){
        $query="SELECT* FROM tbl_admin WHERE status='0' AND adminId='$id'";
        $result=$this->db->select($query);
        return $result;
      }
      public function getuserView_byId($id){
        $query="SELECT* FROM tbl_admin WHERE status='0' AND adminId='$id'";
        $result=$this->db->select($query);
        return $result;
      }
      public function updateUser($data,$id){
        $upuser_name=$this->fm->validation($data['upuser_name']);
        $upuser_name=mysqli_real_escape_string( $this->db->link,$data['upuser_name']);
        $up_User_email=$this->fm->validation($data['up_User_email']);
        $up_User_email=mysqli_real_escape_string( $this->db->link,$data['up_User_email']);
        $up_user_role=$this->fm->validation($data['up_user_role']);
        $up_user_role=mysqli_real_escape_string( $this->db->link,$data['up_user_role']);
        $up_User_pass=$this->fm->validation(base64_encode($data['up_User_pass']));
        $up_User_pass=mysqli_real_escape_string( $this->db->link,base64_encode($data['up_User_pass']));
        $up_date=$this->fm->validation($data['up_date']);
        $up_date=mysqli_real_escape_string($this->db->link,$data['up_date']);
        $country=$this->fm->validation($data['country']);
        $country=mysqli_real_escape_string($this->db->link,$data['country']);
        $city=$this->fm->validation($data['city']);
        $city=mysqli_real_escape_string($this->db->link,$data['city']);
        $phone=$this->fm->validation($data['phone']);
        $phone=mysqli_real_escape_string($this->db->link,$data['phone']);
        $adrs=$this->fm->validation($data['adrs']);
        $adrs=mysqli_real_escape_string($this->db->link,$data['adrs']);
        if($up_date=="") {
          $msg ="<h5 class='alert alert-danger'>Field must not be emty!!</h5>";
          return $msg;
        }else{
             $query="UPDATE tbl_admin
                     SET    adminUser ='$upuser_name',
                            adminEmail='$up_User_email',
                            adminPass ='$up_User_pass',
                            user_role ='$up_user_role',
                            country   ='$country',
                            city      ='$city',
                            phone     ='$phone',
                            adrs      ='$adrs'
                     WHERE  adminId   ='$id'";
             $Update_row =$this->db->update($query);
             if ($Update_row) {
                echo "<script>window.open('userControl.php?view_users','_self');</script>";
             }
          }
        }
        public function delUser($id){
          $query="DELETE FROM tbl_admin WHERE adminId='$id' AND status='0'";
          $deletedata=$this->db->delete($query);
         if ($deletedata){
             $msg_success="<h4 class='alert-success alert'>
                             User Removed Successfully!!
                           </h4>";
             return $msg_success;
           } else{
             $msg_invalid="<h4 class='alert-danger alert'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 User not Removed!!
                              </i>
                           </h4>";
             return $msg_invalid;
          }
        }
        public function userprofile_view($userId){
          $query="SELECT* FROM tbl_admin WHERE status='0' AND adminId='$userId'";
          $result=$this->db->select($query);
          return $result; 
        }
        public function updateUserProfile($data,$userId){
        $upuser_name=$this->fm->validation($data['upuser_name']);
        $upuser_name=mysqli_real_escape_string( $this->db->link,$data['upuser_name']);
        $up_User_email=$this->fm->validation($data['up_User_email']);
        $up_User_email=mysqli_real_escape_string( $this->db->link,$data['up_User_email']);
        $up_user_role=$this->fm->validation($data['up_user_role']);
        $up_user_role=mysqli_real_escape_string( $this->db->link,$data['up_user_role']);
        $up_User_pass=$this->fm->validation(base64_encode($data['up_User_pass']));
        $up_User_pass=mysqli_real_escape_string( $this->db->link,base64_encode($data['up_User_pass']));
        $up_date=$this->fm->validation($data['up_date']);
        $up_date=mysqli_real_escape_string($this->db->link,$data['up_date']);
        $country=$this->fm->validation($data['country']);
        $country=mysqli_real_escape_string($this->db->link,$data['country']);
        $city=$this->fm->validation($data['city']);
        $city=mysqli_real_escape_string($this->db->link,$data['city']);
        $phone=$this->fm->validation($data['phone']);
        $phone=mysqli_real_escape_string($this->db->link,$data['phone']);
        $adrs=$this->fm->validation($data['adrs']);
        $adrs=mysqli_real_escape_string($this->db->link,$data['adrs']);
        if($up_date=="") {
          $msg ="<h5 class='alert alert-danger'>Field must not be emty!!</h5>";
          return $msg;
        }else{
             $query="UPDATE tbl_admin
                     SET    adminUser ='$upuser_name',
                            adminEmail='$up_User_email',
                            adminPass ='$up_User_pass',
                            user_role ='$up_user_role',
                            country   ='$country',
                            city      ='$city',
                            phone     ='$phone',
                            adrs      ='$adrs'
                     WHERE  adminId   ='$userId'";
             $Update_row =$this->db->update($query);
             if ($Update_row) {
                echo "<script>window.open('userControl.php?view_users','_self');</script>";
             }
          }
        }
        public function delUser_prof($id){
          $query="DELETE FROM tbl_admin WHERE adminId='$id' AND status='0'";
          $deletedata=$this->db->delete($query);
         if ($deletedata){
             $msg_success="<h4 class='alert-success alert'>
                             User Removed Successfully!!
                           </h4>";
             return $msg_success;
           } else{
             $msg_invalid="<h4 class='alert-danger alert'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 User not Removed!!
                              </i>
                           </h4>";
             return $msg_invalid;
          }
        }
         // User activation  to access
        public function user_activation($user_bl_Id){
          $user_bl_Id=$this->fm->validation($user_bl_Id);
          $user_bl_Id=mysqli_real_escape_string( $this->db->link,$user_bl_Id);
          $query="UPDATE tbl_admin
                     SET 
                     status ='1' 
                     WHERE adminId='$user_bl_Id'";
            $activation=$this->db->update($query);
            return $activation;
        }
        // User activation  to access for inactive/block
        public function user_inactivation($user_unblk_Id){
          $user_unblk_Id=$this->fm->validation($user_unblk_Id);
          $user_unblk_Id=mysqli_real_escape_string( $this->db->link,$user_unblk_Id);
          $query="UPDATE tbl_admin
                  SET 
                  status ='0' 
                  WHERE adminId='$user_unblk_Id'";
          $Inactivation=$this->db->update($query);
          return $Inactivation;
        }
        public function get_block_user(){
           $query ="SELECT * FROM tbl_admin WHERE status='1' ORDER BY adminId DESC";
           $result=$this->db->select($query);
           if ($result==true) {
             $count=mysqli_num_rows($result);
             return "(".$count.")";
           }else{
           echo "(empty)";
          }
        }
    }
 ?>
