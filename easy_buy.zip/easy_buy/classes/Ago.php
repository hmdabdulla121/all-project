<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
 class  Ago{
   public function __construct(){
   $this->db =new Database();
   $this->fm =new Format();
  }
  public function convertToUnixTimestamp($value){
     date_default_timezone_set("Asia/Dhaka");

 	 list($date,$time)= explode(' ', $value);
 	 list($year,$month,$day)= explode('-', $date);
 	 list($hour,$minutes,$seconds)= explode(':', $time);

 	 $unit_timestamp=mktime($hour,$minutes,$seconds,$month,$day,$year);
 	 return $unit_timestamp;
    }

  public function convertToagoFormate($timestamp){
  	date_default_timezone_set("Asia/Dhaka");
     $dfrntbtnCrntTimeAndTimestamp=time()-$timestamp;
     $periodString=["sec","min","hr","day","week","month","year","deacde"];
     $periodNumber=["60","60","24","7","30","4.35","12","10"];
     for($i=0; $dfrntbtnCrntTimeAndTimestamp>=$periodNumber[$i]; $i++)
     $dfrntbtnCrntTimeAndTimestamp/=$periodNumber[$i];
     $dfrntbtnCrntTimeAndTimestamp=round($dfrntbtnCrntTimeAndTimestamp);

    if($dfrntbtnCrntTimeAndTimestamp !=1)$periodString[$i].="s";
       $outPut="$dfrntbtnCrntTimeAndTimestamp $periodString[$i]";//1 second
       return $outPut;
    }
   }
 ?>
