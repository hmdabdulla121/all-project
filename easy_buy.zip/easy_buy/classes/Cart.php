<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
class Cart{
     private $db;
	   private $fm;

      public function __construct(){
	      $this->db =new Database();
	      $this->fm =new Format();
      }
      public function addtoCart($quantity,$cs,$sc,$id,$cmrId){
        $quantity=$this->fm->validation($quantity);
        $quantity=mysqli_real_escape_string( $this->db->link,$quantity);
        $cs      =$this->fm->validation($cs);
        $cs      =mysqli_real_escape_string( $this->db->link,$cs);
        $sc      =$this->fm->validation($sc);
        $sc      =mysqli_real_escape_string( $this->db->link,$sc);
        $id      =mysqli_real_escape_string( $this->db->link,$id);
        $cmrId   =mysqli_real_escape_string( $this->db->link,$cmrId);
        //$sId     =session_id();
        if($quantity=="" || $cs==""|| $sc==""){
            $msg ="<h4 class='alert alert-danger'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Please select quantity or product size!!
                  </h4>";
            return $msg;
       }elseif($quantity<=0) {
           $msg ="<h4 class='alert alert-danger'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Please select valid quantity or product size!!
                  </h4>";
            return $msg;
       }else{
        $query  ="SELECT * FROM tbl_product WHERE productId ='$id'";
        $result =$this->db->select($query)->fetch_assoc();
        $p_name =$result['p_name'];
        $price  =$result['price'];
        $image  =$result['pro_imageL'];
        $chquery="SELECT * FROM tbl_cart WHERE productId ='$id' AND sId='$cmrId' ";
        $getPro =$this->db->select($chquery);
        if($getPro){
          $msg ="<h5 class='alert alert-danger'>
                    <i class='fa fa-exclamation-triangle mr-1'>
                    </i> Product already added!!!
                 </h5>";
          return $msg;
        }else{
            $query ="INSERT INTO tbl_cart(sId,productId,p_name,price,quantity,pro_size,color,image) VALUES('$cmrId','$id','$p_name','$price','$quantity','$sc','$cs','$image')";
            $cartInsert=$this->db->insert($query);
         	if($cartInsert){
       		    echo "<script>window.location='cart.php';</script>";
       	  }else{
           echo "<script>window.location='404.php';</script>";
       	 }
       }
      }
       }
      public function getCartProduct($cmrId){
     	$cmrId  =$this->fm->validation($cmrId);
        $cmrId  =mysqli_real_escape_string( $this->db->link,$cmrId);
     	$query  ="SELECT * FROM tbl_cart WHERE sId='$cmrId'";
        $result =$this->db->select($query);
        return $result;
      }
      public function CartUdateQuantity($cartId,$quantity){
        $cartId  =$this->fm->validation($cartId);
        $cartId  =mysqli_real_escape_string( $this->db->link,$cartId);
        $quantity=mysqli_real_escape_string( $this->db->link,$quantity);
        $query   ="UPDATE tbl_cart
                   SET quantity='$quantity'
                   WHERE cartId='$cartId'";
        $Update_quantity =$this->db->update($query);
          if($Update_quantity){
            echo "<script>window.location='cart.php';</script>";
      }else{
          $msg_invalid="<span class='text-danger text-bold ml-5'>
                         <i class='fas fa-exclamation-triangle'>
                            Product not Updated!!
                         </i>
                        </span>";
          return $msg_invalid;
        }
      }
      public function cartUpdate($remove){
        foreach ($remove as $removeId){
         $query ="DELETE FROM tbl_cart WHERE cartId='$removeId'";
         $delCart=$this->db->delete($query);
          if($delCart){
             echo "<script>window.open('cart.php','_self')</script>";
        }else{
          $msg_invalid="<span class='text-danger text-bold ml-5'>
                              Product not Deleted!!
                      </span>";
          return $msg_invalid;
        }
        }
      }
      public function checkCartTable($cmrId){
        //$sId   =session_id();
		$cmrId =$this->fm->validation($cmrId);
        $cmrId =mysqli_real_escape_string( $this->db->link,$cmrId);
        $query ="SELECT * FROM tbl_cart WHERE sId='$cmrId'";
        $result=$this->db->select($query);
        return $result;
      }
      public function delCustomerCart($cmrId){
		$cmrId=$this->fm->validation($cmrId);
        $cmrId=mysqli_real_escape_string( $this->db->link,$cmrId);
        $query ="DELETE FROM tbl_cart WHERE sId='$cmrId'";
        $result=$this->db->delete($query);
        return $result;
      }
      public function chkorderInsert($cmrId,$Shipping){
		$cmrId=$this->fm->validation($cmrId);
        $cmrId=mysqli_real_escape_string( $this->db->link,$cmrId);
        $ship_method=$this->fm->validation($Shipping);
        $ship_method=mysqli_real_escape_string( $this->db->link,$Shipping);
        $invoice_no=mt_rand();
        $status="Pending";
        $query="SELECT * FROM tbl_cart WHERE sId='$cmrId'";
        $getPro=$this->db->select($query);
        if($getPro){
          while($result = $getPro->fetch_assoc()){
                $productId = $result['productId'];
                $p_name = $result['p_name'];
                $quantity = $result['quantity'];
                $price = $result['price'];
                $pro_size = $result['pro_size'];
                $image = $result['image'];
          $chkorder_query="INSERT INTO tbl_curtorder(cmrId,productId,p_name,quantity,pro_size,price,ship_method,image,invoice_no) VALUES('$cmrId','$productId','$p_name','$quantity','$pro_size','$price','$ship_method','$image','$invoice_no')";
          $Insertorder=$this->db->insert($chkorder_query);
          }
        }
      }
      public function getcheckoutOrder($cmrId){
        $query ="SELECT * FROM tbl_curtorder WHERE cmrId='$cmrId'";
        $result=$this->db->select($query);
        return $result;
      }
      public function getallcheckoutOrder($cmrId){
        $query ="SELECT * FROM tbl_curtorder WHERE cmrId='$cmrId'";
        $result=$this->db->select($query)->fetch_assoc();
        return $result;
      }
      public function delchkorderdata($cmrId){
        //$sId   =session_id();
        $query ="DELETE FROM tbl_curtorder WHERE cmrId='$cmrId'";
        $result=$this->db->delete($query);
        return $result;
      }
      public function orderInsert($data,$cmrId){
        $status="Pending";
        $sId=session_id();
		$day  =Date('d');
        $month=Date('m');
        $year =Date('Y');
        $fname=$this->fm->validation($data['fname']);
        $fname=mysqli_real_escape_string($this->db->link,$data['fname']);
        $lname=$this->fm->validation($data['lname']);
        $lname=mysqli_real_escape_string($this->db->link,$data['lname']);
        $country=$this->fm->validation($data['country']);
        $country=mysqli_real_escape_string($this->db->link,$data['country']);
        $addrs=$this->fm->validation($data['addrs']);
        $addrs=mysqli_real_escape_string($this->db->link,$data['addrs']);
        $zip=$this->fm->validation($data['zip']);
        $zip=mysqli_real_escape_string($this->db->link,$data['zip']);
        $city=$this->fm->validation($data['city']);
        $city=mysqli_real_escape_string($this->db->link,$data['city']);
        $post=$this->fm->validation($data['post']);
        $post=mysqli_real_escape_string($this->db->link,$data['post']);
        $phone=$this->fm->validation($data['phone']);
        $phone=mysqli_real_escape_string($this->db->link,$data['phone']);
        $p_method=$this->fm->validation(base64_decode($data['pm']));
        $p_method=mysqli_real_escape_string($this->db->link,base64_decode($data['pm']));
        $bk_num=$this->fm->validation($data['bk_num']);
        $bk_num=mysqli_real_escape_string($this->db->link,$data['bk_num']);
        $bk_txrId=$this->fm->validation($data['bk_txrId']);
        $bk_txrId=mysqli_real_escape_string($this->db->link,$data['bk_txrId']);
        $rk_num=$this->fm->validation($data['rk_num']);
        $rk_num=mysqli_real_escape_string($this->db->link,$data['rk_num']);
        $rk_txrId=$this->fm->validation($data['rk_txrId']);
        $rk_txrId=mysqli_real_escape_string($this->db->link,$data['rk_txrId']);
        if ($fname==""||$lname==""||$country==""||$addrs==""||$zip==""||$city==""||$post==""||$phone==""||$p_method=="") {
            $msg ="<h6 class='alert alert-danger text-dark'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Field must not be empty!!
                  </h6>";
            return $msg;
        }else{
        $query="SELECT * FROM tbl_curtorder WHERE cmrId='$cmrId'";
        $getPro=$this->db->select($query);
        if($getPro){
          while($result=$getPro->fetch_assoc()){
                $productId  = $result['productId'];
                $p_name     = $result['p_name'];
                $quantity   = $result['quantity'];
                $ship_method= $result['ship_method'];
                $price      = $result['price'] * $quantity;
                $total      = $price + $ship_method;
                $pro_size   = $result['pro_size'];
                $invoice_no = $result['invoice_no'];
                $image = $result['image'];
          //order inserting
          $query="INSERT INTO tbl_order(cmrId,productId,p_name,quantity,pro_size,total,price,ship_method,invoice_no,fname,lname,country,addrs,zip,city,post,phone,p_method,bk_num,bk_txrId,rk_num,rk_txrId,image,day,month,year) VALUES('$cmrId','$productId','$p_name','$quantity','$pro_size','$total','$price','$ship_method','$invoice_no','$fname','$lname','$country','$addrs','$zip','$city','$post','$phone','$p_method','$bk_num','$bk_txrId','$rk_num','$rk_txrId','$image','$day','$month','$year')";
          $Insertorder=$this->db->insert($query);
		  
		  $Paymentquery="INSERT INTO tbl_payment(cmrId,productId,p_name,total,price,quantity,ship_method,invoice_no,fname,lname,country,addrs,zip,city,post,phone,p_method,bk_num,bk_txrId,rk_num,rk_txrId,image,day,month,year) VALUES('$cmrId','$productId','$p_name','$total','$price','$quantity','$ship_method','$invoice_no','$fname','$lname','$country','$addrs','$zip','$city','$post','$phone','$p_method','$bk_num','$bk_txrId','$rk_num','$rk_txrId','$image','$day','$month','$year')";
          $Insertorder=$this->db->insert($Paymentquery);

          $pending_query="INSERT INTO tbl_pend_order(cmrId,productId,p_name,quantity,pro_size,total,price,ship_method,invoice_no,fname,lname,country,addrs,zip,city,post,phone,p_method,bk_num,bk_txrId,rk_num,rk_txrId,image,day,month,year) VALUES('$cmrId','$productId','$p_name','$quantity','$pro_size','$total','$price','$ship_method','$invoice_no','$fname','$lname','$country','$addrs','$zip','$city','$post','$phone','$p_method','$bk_num','$bk_txrId','$rk_num','$rk_txrId','$image','$day','$month','$year')";
          $Insertorder=$this->db->insert($query);
          $Insertorder=$this->db->insert($pending_query);
          //delete cartorder data after order
          $query ="DELETE FROM tbl_curtorder WHERE cmrId='$cmrId'";
          $result=$this->db->delete($query);

          //retrive all order from order_tbl for payment redirect
          }
         }
        }
      }
      public function delpendorder($cmrId){
        $query ="DELETE FROM tbl_pend_order WHERE cmrId='$cmrId'";
        $result=$this->db->delete($query);
        return $result;
      }
      public function getpendorder($cmrId){
        $sId=session_id();
        $pending_query="SELECT * FROM tbl_pend_order WHERE cmrId='$cmrId'";
        $result=$this->db->select($pending_query);
        return $result;
      }
      public function getallorder($cmrId){
        $sId=session_id();
        $pending_query="SELECT * FROM tbl_order WHERE cmrId='$cmrId'  ORDER BY date DESC";
        $result=$this->db->select($pending_query);
        return $result;
      }
      public function getallorder_list(){
        $query ="SELECT * FROM tbl_order ORDER BY orderId DESC";
        $result=$this->db->select($query);
        return $result;
      }
	    public function getallorder_src_list($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_order WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR date like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
	    public function getall_order_src_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_order WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR date like '%$search%'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function getallorder_src_by_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_order WHERE date BETWEEN '$from_dt' AND '$to_dt' ORDER BY date";
         $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function getallorder_src_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_order WHERE date BETWEEN '$from_dt' AND '$to_dt' ORDER BY date";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
      public function getall_order_count(){
          $query ="SELECT * FROM tbl_order ORDER BY orderId ASC";
          $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function getall_pendorder_count_adm(){
          $query ="SELECT * FROM tbl_order WHERE status='0' ORDER BY orderId ASC ";
          $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function getall_pendorder_list_adm(){
        $query ="SELECT * FROM tbl_order WHERE status='0' ORDER BY orderId DESC";
        $result=$this->db->select($query);
        return $result;
     } 
     //all purchase method here admin area usages
     public function getall_Purchase_list_adm(){
        $query ="SELECT * FROM tbl_order WHERE status='1' ORDER BY orderId ASC";
       $result=$this->db->select($query);
       return $result;
     }
     public function get_purchase_byId($id){
         $query ="SELECT * FROM tbl_order WHERE orderId='$id' AND status='1'";
         $result=$this->db->select($query);
         return $result;
     }
     public function getall_purchase_count_adm(){
          $query ="SELECT * FROM tbl_order WHERE status='1' ORDER BY orderId ASC";
          $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
     }
     public function getall_Purchase_pendlist(){
        $query ="SELECT * FROM tbl_order WHERE status='0' ORDER BY orderId ASC";
       $result=$this->db->select($query);
       return $result;
     }
     public function get_pend_purchase_byId($id){
         $query ="SELECT * FROM tbl_order WHERE orderId='$id' AND status='0'";
         $result=$this->db->select($query);
         return $result;
     }
     public function getall_pendpurch_count_adm(){
          $query ="SELECT * FROM tbl_order WHERE status='0' ORDER BY orderId ASC";
          $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
     }  
     public function getall_purchase_adm(){
       $query ="SELECT * FROM tbl_payment ORDER BY payId ASC";
       $result=$this->db->select($query);
       return $result;
     } 
     
     public function getall_purchase_src($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_order WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR date like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function getall_purchase_src_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_order WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR date like '%$search%'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function src_purchase_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_order WHERE date BETWEEN '$from_dt' AND '$to_dt' ORDER BY date";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
      public function src_purchase_by_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_order WHERE date BETWEEN '$from_dt' AND '$to_dt' ORDER BY date";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(0)";
        }
    }
    public function src_pnd_purchase($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_order WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR date like '%$search%' OR status='0'";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function src_pnd_purchase_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_order WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR date like '%$search%' OR status='0'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function src_pnd_purchase_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_order WHERE date BETWEEN '$from_dt' AND '$to_dt' AND status='0' ORDER BY date";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
      public function src_pnd_purchby_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_order WHERE date BETWEEN '$from_dt' AND '$to_dt' AND status='0' ORDER BY date";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(0)";
        }
      }
      public function del_purchaseById_adm($id,$time,$price){
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);

        $query ="DELETE FROM tbl_order
                 WHERE orderId='$id' AND date='$time' AND price='$price'";
        $deletedata=$this->db->delete($query);
        if($deletedata){
            echo "<script>window.open('userControl.php?purchase','_self')</script>";
        }else{
         $msg_invalid="<span class='text-danger text-bold ml-5'>
                               <i class='fas fa-exclamation-triangle'>
                                 not deleted!!
                               </i>
                           </span>";
             return $msg_invalid;
      }
     }
//all purchase method here admin area usages end
//all payment method here admin area usages
     public function getall_sales_year(){
       $query ="SELECT year FROM tbl_payment GROUP BY year DESC";
       $result=$this->db->select($query);
       return $result;
     }
     public function getall_payment_sales(){
       $query ="SELECT * FROM tbl_payment ORDER BY payId DESC";
       $result=$this->db->select($query);
       return $result;
     }
      public function get_total_payment_sales(){
       $query ="SELECT SUM(price) as total, SUM(quantity) as qty, SUM(ship_method) as ship_chrg FROM tbl_payment";
       $result=$this->db->select($query);
       return $result;
     }
     public function get_sales_byId($id){
         $query ="SELECT * FROM tbl_payment WHERE payId='$id'";
         $result=$this->db->select($query);
         return $result;
     }
     public function del_sales_adm($id,$time,$price){
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);

        $query ="DELETE FROM tbl_payment
                 WHERE payId='$id' AND pay_dt='$time' AND price='$price'";
        $deletedata=$this->db->delete($query);
        if($deletedata){
            echo "<script>window.open('userControl.php?sales_reports','_self')</script>";
        }else{
         $msg_invalid="<span class='text-danger text-bold ml-5'>
                               <i class='fas fa-exclamation-triangle'>
                                 not deleted!!
                               </i>
                           </span>";
             return $msg_invalid;
      }
     }
     public function src_sales_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_payment WHERE pay_dt BETWEEN '$from_dt' AND '$to_dt' ORDER BY pay_dt";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function src_sales_by_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_payment WHERE pay_dt BETWEEN '$from_dt' AND '$to_dt' ORDER BY pay_dt";
         $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function getall_sales_src_list($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_payment WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR pay_dt like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function getall_sales_src_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_payment WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR pay_dt like '%$search%'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
     public function getall_payment_adm(){
       $query ="SELECT * FROM tbl_payment ORDER BY payId ASC";
       $result=$this->db->select($query);
       return $result;
     }
     public function get_payment_byId($id){
         $query ="SELECT * FROM tbl_payment WHERE payId='$id'";
         $result=$this->db->select($query);
         return $result;
     }
     public function getall_payment_count_adm(){
          $query ="SELECT * FROM tbl_payment ORDER BY payId ASC";
          $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
     }
     public function src_payment_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_payment WHERE pay_dt BETWEEN '$from_dt' AND '$to_dt' ORDER BY pay_dt";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function src_payment_by_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_payment WHERE pay_dt BETWEEN '$from_dt' AND '$to_dt' ORDER BY pay_dt";
         $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function getallpayment_src_list($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_payment WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR pay_dt like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
     public function getall_paymnt_src_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_payment WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR pay_dt like '%$search%'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }   
     public function del_payment_adm($id,$time,$price){
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);

        $query ="DELETE FROM tbl_payment
                 WHERE payId='$id' AND pay_dt='$time' AND price='$price'";
        $deletedata=$this->db->delete($query);
        if($deletedata){
            echo "<script>window.open('userControl.php?payments','_self')</script>";
        }else{
         $msg_invalid="<span class='text-danger text-bold ml-5'>
                               <i class='fas fa-exclamation-triangle'>
                                 not deleted!!
                               </i>
                           </span>";
             return $msg_invalid;
      }
     }
     public function getall_pendpayment_adm(){
        $query ="SELECT * FROM tbl_payment WHERE status='0' ORDER BY payId ASC ";
        $result=$this->db->select($query);
        return $result;
     }
     public function getall_pendpayment_count_adm(){
        $query ="SELECT * FROM tbl_payment WHERE status='0' ORDER BY payId ASC ";
        $result=$this->db->select($query);
          if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
        }else{
            echo "(0)";
        }
     }
     public function getall_refund_adm(){
       $query ="SELECT * FROM tbl_payment WHERE status='1'";
       $result=$this->db->select($query);
       return $result;
     }
     public function getall_refund_adm_byId($id){
       $query ="SELECT * FROM tbl_payment WHERE status='1' AND payId='$id'";
       $result=$this->db->select($query);
       return $result;
     }
     public function getall_refund_count_adm(){
          $query ="SELECT * FROM tbl_payment WHERE status='1' ORDER BY payId ASC ";
          $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
     }
     public function src_refund_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_payment WHERE pay_dt BETWEEN '$from_dt' AND '$to_dt' AND status='1' ORDER BY pay_dt";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function src_refund_by_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_payment WHERE pay_dt BETWEEN '$from_dt' AND '$to_dt' AND status='1' ORDER BY pay_dt";
         $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
     public function getall_refund_src_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_payment WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR pay_dt like '%$search%'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      } 
     public function getall_refund_src_list($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_payment WHERE p_name LIKE '%$search%' OR invoice_no like '%$search%' OR fname like '%$search%' OR lname like '%$search%'OR country like '%$search%' OR addrs like '%$search%' OR zip like '%$search%' OR city like '%$search%' OR post like '%$search%' OR phone like '%$search%' OR bk_num like '%$search%' OR bk_txrId like '%$search%' OR rk_num like '%$search%' OR rk_txrId like '%$search%' OR ship_method like '%$search%' OR pay_dt like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
     }
     public function refund_payment($id){
       $ref_date= date("Y-m-d");
       $User_Id=Session::get("adminId");
       $adminEmail=Session::get("adminEmail");
       $user_role=Session::get("user_role");
       $pm_accept=Session::get("adminUser");
       $id    =$this->fm->validation($id);
       $id    =mysqli_real_escape_string($this->db->link,$id);
       $query="SELECT pm.*,ct.email,ct.name
            FROM  tbl_payment as pm,tbl_customer as ct
            WHERE pm.cmrId=ct.cstmrId
            ORDER BY payId";
       $getCustomer=$this->db->select($query);
         $result=$getCustomer->fetch_assoc();
         $user=$result['name'];
         $email=$result['email'];
         $to=$email;
         $subject="Refund payment submition attachment";
         $message="Hi ".$user." ,Accept Your Payment refund submition.Thanks for your Pateince.Your Refund payment will be returned about 3 buisness day from now.";
         $headers="From:$adminEmail\r\n";
         $headers.="MIME-Version:1.0"."\r\n";
         $headers.="Content-type:text/html;charset=UTF-8"."\r\n";
         mail($to,$subject,$message,$headers);
         $query ="UPDATE tbl_payment
                 SET status='1',
                 name='$user',
                 email='$email',
                 pm_refBy='$pm_accept',
                 user_role='$user_role',
                 ref_dt   =now()
                 WHERE payId='$id'";
          $Update_row =$this->db->update($query);
          if($Update_row){
             $msg_success="<span class='text-success text-bold ml-5'>
                             <i class='fas fa-check-circle'>
                               Refunded Successfully!!
                             </i>
                           </span>";
             return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle'>
                                 not Refunded!!
                             </i>
                           </span>";
             return $msg_invalid;
         }
      }
     public function refund_accept($id){
        $ref_date= date("Y-m-d");
        $User_Id=Session::get("adminId");
        $user_role=Session::get("user_role");
        $pm_accept=Session::get("adminUser");
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $query="SELECT pm.*,ct.email,ct.name
            FROM  tbl_payment as pm,tbl_customer as ct
            WHERE pm.cmrId=ct.cstmrId
            ORDER BY payId";
       $getCustomer=$this->db->select($query);
         $result=$getCustomer->fetch_assoc();
         $email=$result['email'];
         $user=$result['name'];
         $to=$email;
         $subject="Withdraw Refund payment submition attachment";
         $message="Hi ".$user." Withdraw Payment refund submition Succesfully.Thanks for your Pateince.Have good day!!";
         $headers="From:$adminEmail\r\n";
         $headers.="MIME-Version:1.0"."\r\n";
         $headers.="Content-type:text/html;charset=UTF-8"."\r\n";
         mail($to,$subject,$message,$headers);
        $query ="UPDATE tbl_payment
                 SET status='0',
                  pm_refBy ='$pm_accept',
                  name     ='$user',
                  email    ='$email',
                  user_role='$user_role',
                  ref_dt   =now()
                 WHERE payId='$id'";
          $Update_row =$this->db->update($query);
          if($Update_row){
             $msg_success="<span class='text-success text-bold ml-5'>
                             <i class='fas fa-check-circle'>
                               Refunded Withdraw Successfully!!
                             </i>
                           </span>";
             return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle'>
                               Refunded not Withdraw!!
                             </i>
                           </span>";
             return $msg_invalid;
         }
      }
//all payment method here admin area usages end
//customer area usages purchases start
	   public function getall_purchase_list($cmrId){
		$cmrId =$this->fm->validation($cmrId);
		$cmrId =mysqli_real_escape_string($this->db->link,$cmrId);
        $query ="SELECT * FROM tbl_order WHERE cmrId='$cmrId' ORDER BY orderId DESC";
        $result=$this->db->select($query);
        return $result;
       }
     public function getall_purchase_count($cmrId){
        $cmrId =$this->fm->validation($cmrId);
		$cmrId =mysqli_real_escape_string($this->db->link,$cmrId);
        $query ="SELECT * FROM tbl_order WHERE cmrId='$cmrId' ORDER BY orderId DESC";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(empty)";
          }
       }
	   public function delPurchslist($id,$cmrId){
		   $query ="DELETE FROM tbl_order WHERE orderId='$id' AND cmrId='$cmrId'";
       $deletedata=$this->db->delete($query);
        if($deletedata){
          echo "<script>window.open('my_account.php?Purchase','_self')</script>";
        }else{
        $msg_invalid="<span class='text-danger text-bold ml-5'>
                               <i class='fas fa-exclamation-triangle'>
                                 not deleted!!
                               </i>
                           </span>";
          return $msg_invalid;
       }
	   }
     public function getcustomorder_byId($id){
         $query ="SELECT * FROM tbl_order WHERE orderId='$id'";
         $result=$this->db->select($query);
         return $result;
      }
	   public function get_cust_order_byId($id,$cmrId){
         $query ="SELECT * FROM tbl_order WHERE orderId='$id' AND cmrId='$cmrId'";
         $result=$this->db->select($query);
         return $result;
       }
//customer area usages purchases  end
      public function getOrderbyId($cmrId,$orderId){
        $query ="SELECT * FROM tbl_curtorder WHERE cmrId='$cmrId' AND orderId='$orderId'";
        $result=$this->db->select($query);
        return $result;
      }
      public function customerPayment($data,$orderId,$cmrId){
        $invoice_no=$this->fm->validation($data['invoice_no']);
        $invoice_no=mysqli_real_escape_string( $this->db->link,$data['invoice_no']);
        $amount    =$this->fm->validation($data['amount']);
        $amount    =mysqli_real_escape_string( $this->db->link,$data['amount']);
        $pay_mode  =$this->fm->validation($data['pay_mode']);
        $pay_mode  =mysqli_real_escape_string( $this->db->link,$data['pay_mode']);
        $ref_no    =$this->fm->validation($data['ref_no']);
        $ref_no    =mysqli_real_escape_string( $this->db->link,$data['ref_no']);
        $code_no   =$this->fm->validation($data['code_no']);
        $code_no   =mysqli_real_escape_string( $this->db->link,$data['code_no']);
        $pay_dt    =$this->fm->validation($data['pay_dt']);
        $pay_dt    =mysqli_real_escape_string( $this->db->link,$data['pay_dt']);
        //$sId=session_id();

        if($invoice_no==""||$amount==""||$pay_mode==""||$ref_no==""||$code_no==""||$pay_dt==""){
            $msg ="<h6 class='alert alert-danger text-light'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Please field must not be empty!!
                  </h6>";
            return $msg;
       }else{
          $chquery="SELECT * FROM tbl_payment WHERE invoice_no='$invoice_no' OR ref_no='$invoice_no' OR ref_no='$ref_no' OR code_no='$code_no' AND pay_status='0' LIMIT 1";
          $getOrder =$this->db->select($chquery);
        if($getOrder){
          $msg ="<h5 class='alert alert-danger'>
                    <i class='fa fa-exclamation-triangle mr-1'>
                    </i> Order Invoice already Submited.Please note this Transaction/Reference code  or code should be deferrent!!!.Please try another.
                 </h5>";
          return $msg;
       }
        $query="INSERT INTO tbl_payment(sId,invoice_no,amount,pay_mode,ref_no,code_no,pay_dt) VALUES('$cmrId','$invoice_no','$amount','$pay_mode','$ref_no','$code_no','$pay_dt')";
        $insertPayment=$this->db->insert($query);
        $query ="UPDATE tbl_order
                 SET    status='1'
                 WHERE  orderId='$orderId'";
        $Update_query =$this->db->update($query);
        $query ="UPDATE tbl_curtorder
                 SET    orer_status='1'
                 WHERE  orderId='$orderId'";
        $Update_pending =$this->db->update($query);
        $c_ip=$this->fm->getRealIpUser();
        $emailquery="SELECT * FROM tbl_customer WHERE customer_ip='$c_ip' AND   cstmrId='$cmrId'";
        $getCustomer=$this->db->select($emailquery);
        if($getCustomer){
           $result=$getCustomer->fetch_assoc();
           $email=$result['email'];
           //$s_email=session_email();
          //send Order comfimation email to customer email after confirm order
             $to=$email;
             $subject="Order From Aurora_shop.bd";
             $message="<a href='http://localhost/smad_shop/success.php?email=$email'>Your Order Submitted Successfuly.Click here to see details!!</a>";
             $headers="From:aurorakhan50@gmail.com\r\n";
             $headers.="MIME-Version:1.0"."\r\n";
             $headers.="Content-type:text/html;charset=UTF-8"."\r\n";
             mail($to, $subject,$message,$headers);
            }
        if($insertPayment){
             echo "<script>alert('Thanks for order submition process completion.An Email has been sent to your email,please store or save this email for shiftment.Thanks again for purchasing product from us.Your order will be completed within 3 works day.')</script>";
             echo "<script>window.open('my_account.php?my_orders','_self')</script>";
        }else{
          $msg_invalid="<span class='text-danger text-bold ml-5'>
                              Some ting went wrong please try again!!
                      </span>";
          return $msg_invalid;
        }
       }
      }
      public function paybleAmont($cmrId){
        $query ="SELECT * FROM tbl_order WHERE cmrId='$cmrId' AND date=now()";
        $result=$this->db->select($query);
        return $result;
      }
      public function getOrderProduct($cmrId){
        $query ="SELECT * FROM tbl_order WHERE cmrId='$cmrId' ORDER BY date DESC";
        $result=$this->db->select($query);
        return $result;
      }

      public function getPayment($cmrId){
        $query ="SELECT * FROM tbl_payment WHERE sId='$cmrId' ORDER BY pay_dt DESC";
        $result=$this->db->select($query);
        return $result;
      }
      public function checkOrder($cmrId){
        $query ="SELECT * FROM tbl_order WHERE cmrId='$cmrId'";
        $result=$this->db->select($query);
        return $result;
      }
      public function getAllOrderProduct(){
        $query ="SELECT * FROM tbl_order ORDER BY date DESC";
        $result=$this->db->select($query);
        return $result;
      }
//product/order shifted by admin then send a confirmation email to cudtomer 
	  public function productShifted($id,$price,$time){
		$User_Id=Session::get("adminId");
		$user_role=Session::get("user_role");
        $ordr_accept=Session::get("adminUser");
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);

        $query ="UPDATE tbl_order 
        SET User_Id ='$User_Id',
				   ordr_accept='$ordr_accept',
				   user_role='$user_role',
           pm_act_dt= now(),
				   status='1'
        WHERE orderId='$id' AND date='$time' AND price='$price'";
        $Update_row =$this->db->update($query);
        $c_ip=$this->fm->getRealIpUser();
        $sId=session_id();
        $emailquery="SELECT * FROM tbl_customer WHERE customer_ip='$c_ip' AND cstmrId='$sId'";
        $getCustomer=$this->db->select($emailquery);
        if($getCustomer){
           $result=$getCustomer->fetch_assoc();
           $email=$result['email'];
             //$s_email=session_email();
            //send Order comfimation email to customer email after confirm order
           $to=$email;
           $subject="Order Confirmation E-mail From smad_shop.bd.com";
           $message="<a href='http://localhost/smad_shop/success.php?email=$email'>Your Order Accepted Successfuly.Click here to see details!!</a>";
           $headers="From:aurorakhan50@gmail.com\r\n";
           $headers.="MIME-Version:1.0"."\r\n";
           $headers.="Content-type:text/html;charset=UTF-8"."\r\n";
            mail($to, $subject,$message,$headers);
          }
          if($Update_row){
             echo "<script>window.open('userControl.php?customer_order','_self')</script>";
          }else{
             $msg_invalid="<span class='alert alert-danger'>
                               <i class='fas fa-exclamation-triangle'>
                                Order not Accepted!!
                               </i>
                           </span>";
             return $msg_invalid;
         }
      }
//product/order shifted by admin then send a confirmation email to cudtomer 
      public function OrderRemove($id,$time,$price){
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);

        $query ="DELETE FROM tbl_order
                 WHERE orderId='$id' AND date='$time' AND price='$price'";
        $deletedata=$this->db->delete($query);
        if($deletedata){
            echo "<script>window.open('userControl.php?customer_order','_self')</script>";
        }else{
         $msg_invalid="<span class='text-danger text-bold ml-5'>
                               <i class='fas fa-exclamation-triangle'>
                                 not deleted!!
                               </i>
                           </span>";
             return $msg_invalid;
          }
      }
      public function OrderCancel($id,$time,$price){
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);

        $query ="DELETE FROM tbl_order
                 WHERE orderId='$id' AND date='$time' AND price='$price'";
        $deletedata=$this->db->delete($query);
        if($deletedata){
            echo "<script>window.open('my_account.php?my_orders','_self')</script>";
        }else{
         $msg_invalid="<span class='text-danger text-bold ml-5'>
                               <i class='fas fa-exclamation-triangle'>
                                 not deleted!!
                               </i>
                           </span>";
             return $msg_invalid;
          }
      }
      public function OrderconfirmByCustomer($id,$time,$price){
        $id    =$this->fm->validation($id);
        $id    =mysqli_real_escape_string( $this->db->link,$id);
        $time  =$this->fm->validation($time);
        $time  =mysqli_real_escape_string( $this->db->link,$time);
        $price =$this->fm->validation($price);
        $price =mysqli_real_escape_string( $this->db->link,$price);

        $query   ="UPDATE tbl_order
                   SET status='2'
                   WHERE cmrId='$id' AND date='$time' AND price='$price'";
          $Update_row =$this->db->update($query);
          if($Update_row){
             $msg_success="<span class='text-success text-bold ml-5'>
                             <i class='fas fa-check-circle'>
                               Updated Successfully!!
                             </i>
                           </span>";
             return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle'>
                                 not Updated!!
                             </i>
                           </span>";
             return $msg_invalid;
         }
      }
      public function activat_theme($data){
        $theme=$this->fm->validation(base64_decode($data['theme']));
        $theme=mysqli_real_escape_string( $this->db->link,base64_decode($data['theme']));
        $theme_ttl=$this->fm->validation($data['theme_ttl']);
        $theme_ttl=mysqli_real_escape_string( $this->db->link,$data['theme_ttl']);
        $query   ="UPDATE tbl_themes
                   SET theme='$theme',
                       theme_ttl='$theme_ttl',
                       status='0' 
                   WHERE themeId='1'";
        $Update_row =$this->db->update($query);
        if($Update_row){
           // $msg_success="<span class='text-success text-bold ml-5'>
           //                   <i class='fas fa-check-circle'>
           //                    Theme Changed Successfully!!
           //                   </i>
           //                 </span>";
           //   return $msg_success;
           echo "<script>window.open('userControl.php?theme','_self')</script>";
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle'>
                                 Theme not Changed!!
                             </i>
                           </span>";
             return $msg_invalid;
         }
      }
      public function get_theme(){
        $query ="SELECT * FROM tbl_themes WHERE themeId='1' ORDER BY themeId DESC";
        $result=$this->db->select($query);
        return $result;
      }
      public function activat_web_theme($data){
        $theme=$this->fm->validation(base64_decode($data['theme']));
        $theme=mysqli_real_escape_string( $this->db->link,base64_decode($data['theme']));
        $theme_ttl=$this->fm->validation($data['theme_ttl']);
        $theme_ttl=mysqli_real_escape_string( $this->db->link,$data['theme_ttl']);
        $query   ="UPDATE tbl_font_theme
                   SET theme='$theme',
                       theme_ttl='$theme_ttl',
                       status='0' 
                   WHERE thm_id='1'";
        $Update_row =$this->db->update($query);
        if($Update_row){
           // $msg_success="<span class='text-success text-bold ml-5'>
           //                   <i class='fas fa-check-circle'>
           //                    Theme Changed Successfully!!
           //                   </i>
           //                 </span>";
           //   return $msg_success;
           echo "<script>window.open('userControl.php?web_theme','_self')</script>";
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle'>
                                 Theme not Changed!!
                             </i>
                           </span>";
             return $msg_invalid;
         }
      }
      public function get_web_theme(){
        $query ="SELECT * FROM tbl_font_theme WHERE thm_id='1' ORDER BY thm_id DESC";
        $result=$this->db->select($query);
        return $result;
      }
    }
 ?>
