<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
class Customer{
     private $db;
     private $fm;

     public function __construct(){
       $this->db =new Database();
       $this->fm =new Format();
    }
   // CustomerRegistration  to access
    public function customerRegister($data,$file){
        $name    =$this->fm->validation($data['name']);
        $name    =mysqli_real_escape_string( $this->db->link,$data['name']);
        $email   =$this->fm->validation($data['email']);
        $email   =mysqli_real_escape_string( $this->db->link,$data['email']);
        $password=$this->fm->validation(md5($data['password']));
        $password=mysqli_real_escape_string( $this->db->link,md5($data['password']));
        $country =$this->fm->validation($data['country']);
        $country =mysqli_real_escape_string( $this->db->link,$data['country']);
        $city    =$this->fm->validation($data['city']);
        $city    =mysqli_real_escape_string( $this->db->link,$data['city']);
        $phone   =$this->fm->validation($data['phone']);
        $phone   =mysqli_real_escape_string( $this->db->link,$data['phone']);
        // $pro_pic =$this->fm->validation($data['pro_pic']);
        // $pro_pic =mysqli_real_escape_string( $this->db->link,$data['pro_pic']);
        $address =$this->fm->validation($data['address']);
        $address =mysqli_real_escape_string( $this->db->link,$data['address']);
        $c_ip    =$this->fm->getRealIpUser();
        $day     =Date('d');
        $month   =Date('m');
        $year    =Date('Y');
        $permited= array('jpg','jpeg','png','gif');
        $file_name   =$file['pro_pic']['name'];
        $file_size   =$file['pro_pic']['size'];
        $file_tmp    =$file['pro_pic']['tmp_name'];

        $div         =explode('.', $file_name);
        $file_txt    =strtolower(end($div));
        // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image  too}
        $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
        $upload_image="Uploads/".$unique_image;

        $vkey=md5(time().$name);
        $emailquery="SELECT * FROM tbl_customer WHERE email='$email'  LIMIT 1" ;
        $emailcheck=$this->db->select($emailquery);
        if($emailcheck !=false){
		   $Emailchk_msg="<h6 class='alert alert-danger' id='close_note'>
                    Account or Email already Exist!!Plaase try another times.
				    <i class='fa fa-close' id='close_tap'></i>
                  </h6>";
           return $Emailchk_msg;
        }
        if ($name=="" || $email=="" ||$password=="" ||$country=="" ||$city=="" || $phone=="" || $upload_image=="" || $address==""){
			$msg_invalid="<h6 class='alert alert-danger' id='close_note'>
                            Field must not be empty!!
						   <i class='fa fa-close pull-right' id='close_tap'></i>
                          </h6>";
            return $msg_invalid;
        }elseif($file_size>2048567){
		    $msg="<h6 class='alert alert-danger' id='close_note'>
                    Product Image too large!!
				    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
        }elseif(in_array($file_txt,$permited)==false){
          echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
        }else{
            move_uploaded_file($file_tmp,$upload_image);
            $query="INSERT INTO tbl_customer(name,email,password,country,city,phone,pro_pic,address,customer_ip,day,month,year) VALUES('$name','$email','$password','$country','$city','$phone','$upload_image','$address','$c_ip','$day','$month','$year')";
            $customerInsert=$this->db->insert($query);
        if ($customerInsert) {
             //send verify email
             // $to=$email;
             // $subject="Email veryfication";
             // $message="<a href='http://localhost/Realstate_project/verify.php?vkey=$vkey'>Click here to complete Registar account!!</a>";
             // $headers="From:onlineshop@gmasil.com\r\n";
             // $headers.="MIME-Version:1.0"."\r\n";
             // $headers.="Content-type:text/html;charset=UTF-8"."\r\n";

             // mail($to, $subject, $message,$headers);
            //  echo "<script>window.location='profile.php';</script>";
             // header("Location:thankyou.php");
			$msg="<h6 class='alert alert-success' id='close_note'>
                   You have Successfully Registered!!
				   <i class='fa fa-close pull-right' id='close_tap'></i>
                 </h6>";
            return $msg;
        }else{
			$msg="<h6 class='alert alert-danger' id='close_note'>
                     Your registration not success please try again!!
				    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
        }
       }
    }
    // CustomerLogin and controlling to access
    public function CustomerLogin($data){
       $query="SELECT * FROM tbl_customer ORDER BY cstmrId DESC";
       $result=$this->db->select($query)->fetch_assoc();
       if($result['status']==0){
       // if($result['verified']==1) {
       $email=$this->fm->validation($data['cms_email']);
       $email=mysqli_real_escape_string( $this->db->link,$data['cms_email']);
       $password=$this->fm->validation(md5($data['cms_pass']));
       $password=mysqli_real_escape_string( $this->db->link,md5($data['cms_pass']));
       $query="SELECT * FROM tbl_customer WHERE email='$email' AND password='$password'";
       $result=$this->db->select($query);
       if($email=="" || $password==""){
			    $msg="<h6 class='alert alert-danger' id='close_note'>
                     Feilds name must not be emty!!
				    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
             return $msg;
       }
       if($result!=false){
           $value=$result->fetch_assoc();
           Session::set("custlogin",true);
           Session::set("cmrId",$value['cstmrId']);
           Session::set("c_name",$value['name']);
           Session::set("c_email",$value['email']);
           Session::set("verified",$value['verified']);
           $date=$value['signUpdate'];
           $date=strtotime($date);
           $date=date('M d Y',$date);
           echo "<script>window.open('cart.php','_self')</script>";
       }elseif(!($result['password']==='$password')){
           $msg="<h6 class='alert alert-danger' id='close_note'>
                    Email or Password don't Mathched !!
                    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
            echo "<script>window.open('404.php?','_self')</script>";
       }elseif(empty($result['email'])){
           $msg="<h6 class='alert alert-danger' id='close_note'>
                    Email or Password don't Mathched !!
                    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
       }
       }else{
        $msg="<h6 class='alert alert-danger' id='close_note'
                <i class='fa fa-power-off mr-1'></i>
                    You can't Perform any action.Your account has been blocked!! Please Contact Support.
            <i class='fa fa-close pull-right' id='close_tap''></i>
                  </h6>";
        return $msg;
        }
      
      // }else{
        // $msg ="<P class='text-danger error mt-1'>
        //           <i class='fa fa-power-off mr-1'>
        //             You has not yet verified.Please verification completion an email was sent to $email on $date.
        //           </i>
        //         </P>";
        // return $msg;
       //}
     }// Customer data retrive from tbl_customer
     public function getCustonerInfo($id){
        $query ="SELECT * FROM tbl_customer WHERE cstmrId='$id'";
        $result=$this->db->select($query);
        return $result;
     }
     public function get_Cust_user_count(){
        $query ="SELECT * FROM tbl_customer ORDER BY cstmrId DESC";
        $result=$this->db->select($query);
        if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
     }
     // Customer information retrive from tbl_customer
     public function getCust_user(){
        $query ="SELECT * FROM tbl_customer ORDER BY cstmrId DESC";
        $result=$this->db->select($query);
        return $result;
     }
     public function get_custView_byId($id){
        $query ="SELECT * FROM tbl_customer WHERE cstmrId='$id'";
        $result=$this->db->select($query);
        return $result;
     }
     public function view_cusedit_byId($id){
        $query ="SELECT * FROM tbl_customer WHERE cstmrId='$id'";
        $result=$this->db->select($query);
        return $result;
     }
     public function update_customer_byadm($data,$file,$id){
        $name   =$this->fm->validation($data['name']);
        $name   =mysqli_real_escape_string( $this->db->link,$data['name']);
        $email  =$this->fm->validation($data['email']);
        $email  =mysqli_real_escape_string( $this->db->link,$data['email']);
        $country=$this->fm->validation($data['country']);
        $country=mysqli_real_escape_string( $this->db->link,$data['country']);
        $city   =$this->fm->validation($data['city']);
        $city   =mysqli_real_escape_string( $this->db->link,$data['city']);
        $phone  =$this->fm->validation($data['phone']);
        $phone  =mysqli_real_escape_string( $this->db->link,$data['phone']);
        $address=$this->fm->validation($data['address']);
        $address=mysqli_real_escape_string( $this->db->link,$data['address']); 
        $up_date=$this->fm->validation($data['up_date']);
        $up_date=mysqli_real_escape_string( $this->db->link,$data['up_date']);

        $permited= array('jpg' ,'jpeg','png','gif');
        $file_name   =$file['pro_pic']['name'];
        $file_size   =$file['pro_pic']['size'];
        $file_tmp    =$file['pro_pic']['tmp_name'];

        $div         =explode('.', $file_name);
        $file_txt    =strtolower(end($div));
        // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image  too}
        $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
        $upload_image="Uploads/".$unique_image;
        if($up_date==""){
          $msg="<h6 class='alert alert-danger' id='close_note'
                <i class='fa fa-power-off mr-1'></i>
                    feilds name must not be emty!!
            <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
       }else{
          if(!empty($file_name)){

             if($file_size>1048567){
              echo "<h5 class='text-danger'>Product not Inserted!!</h5>";
             }elseif (in_array($file_txt, $permited)==false){
              echo "<h5 class='alert alert-danger'>You can upload only:-".implode(',', $permited)."</h5>";
             }else{
              move_uploaded_file($file_tmp,$upload_image);
              $query="UPDATE tbl_customer
                     SET
                     name   ='$name',
                     email  ='$email',
                     country='$country',
                     city   ='$city',
                     phone  ='$phone',
                     address='$address',
                     pro_pic='$upload_image',
                     signUpdate='$up_date'
                     WHERE cstmrId='$id'";
             $customerUpdate=$this->db->update($query);
          if($customerUpdate){
             $msg_success="<h5 class='alert alert-success' id='close_note'
                           <i class='fa fa-exclamation-triangle mr-1'>
                            </i> Profile updated successfully!!
              <i class='fa fa-close pull-right' id='close_tap'></i>
                        </h5>";
             return $msg_success;
             }else{
             $msg="<h6 class='alert alert-danger' id='close_note'>
                <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Profile not Updated..!!
              <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
             return $msg;
            }
           }
           }else{
             $query="UPDATE tbl_customer
                     SET
                     name   ='$name',
                     email  ='$email',
                     country='$country',
                     city   ='$city',
                     phone  ='$phone',
                     address='$address',
                     signUpdate='$up_date'
                     WHERE cstmrId='$id'";
              $customerUpdate=$this->db->update($query);
              if($customerUpdate){
              $msg_success="<P class='alert alert-success' id='close_note'>
                           <i class='fa fa-exclamation-triangle mr-1'>
                            </i> Prfile updated successfully!!
              <i class='fa fa-close pull-right' id='close_tap'></i>
                        </P>";
              return $msg_success;
              }else{
              $msg ="<P class='alert alert-danger' id='close_note'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Product not Updated..!!
                     <i class='fa fa-close pull-right' id='close_tap'></i>
                   </P>";
              return $msg;
             }
          }
       }
     }
     public function remove_cust_byId($id){
        $query="DELETE FROM tbl_customer WHERE cstmrId='$id'";
        $delCustomer=$this->db->delete($query);
        if ($delCustomer) {
          echo "<script>window.open('userControl.php?customer','_self')</script>";
        }else{
          $msg ="<P class='alert alert-danger' id='close_note'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Somethng went wrong..!!
           <i class='fa fa-close pull-right' id='close_tap'></i>
                  </P>";
          return $msg;
        }
     }
     public function customer_activation($user_bl_Id){
      $user_bl_Id=$this->fm->validation($user_bl_Id);
      $user_bl_Id=mysqli_real_escape_string( $this->db->link,$user_bl_Id);
      $query="UPDATE tbl_customer
                     SET 
                     status ='1' 
                     WHERE cstmrId='$user_bl_Id'";
      $activation=$this->db->update($query);
      return $activation;
     }
      // User activation  to access for inactive/block
     public function cust_inactivation($user_unblk_Id){
          $user_unblk_Id=$this->fm->validation($user_unblk_Id);
          $user_unblk_Id=mysqli_real_escape_string( $this->db->link,$user_unblk_Id);
          $query="UPDATE tbl_customer
                  SET 
                  status ='0' 
                  WHERE cstmrId='$user_unblk_Id'";
          $Inactivation=$this->db->update($query);
          return $Inactivation;
        }
     public function get_block_cust(){
           $query ="SELECT * FROM tbl_customer WHERE status='1' ORDER BY cstmrId DESC";
           $result=$this->db->select($query);
           if ($result==true) {
             $count=mysqli_num_rows($result);
             return "(".$count.")";
           }else{
           echo "(empty)";
        }
      }
      public function get_cust_src_count($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_customer WHERE name LIKE '%$search%' OR   email like '%$search%' OR city like '%$search%' OR country like '%$search%'OR country like '%$search%' OR address like '%$search%' OR phone like '%$search%'";
        $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(0)";
        }
      }
      public function get_cust_src_list($search){
       $search=$this->fm->validation($search);
       $search=mysqli_real_escape_string( $this->db->link,$search);
       $sql="SELECT * FROM tbl_customer WHERE name LIKE '%$search%' OR   email like '%$search%' OR city like '%$search%' OR country like '%$search%'OR country like '%$search%' OR address like '%$search%' OR phone like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
      public function cust_src_countby_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_customer WHERE signUpdate BETWEEN '$from_dt' AND '$to_dt' ORDER BY signUpdate";
         $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function get_cust_src_by_date($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_customer WHERE signUpdate BETWEEN '$from_dt' AND '$to_dt' ORDER BY signUpdate";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
     // Customer data Update to tbl_customer
     public function customerUpdate($data,$file,$cmrId){
        $name   =$this->fm->validation($data['name']);
        $name   =mysqli_real_escape_string( $this->db->link,$data['name']);
        $email  =$this->fm->validation($data['email']);
        $email  =mysqli_real_escape_string( $this->db->link,$data['email']);
        $country=$this->fm->validation($data['country']);
        $country=mysqli_real_escape_string( $this->db->link,$data['country']);
        $city   =$this->fm->validation($data['city']);
        $city   =mysqli_real_escape_string( $this->db->link,$data['city']);
        $phone  =$this->fm->validation($data['phone']);
        $phone  =mysqli_real_escape_string( $this->db->link,$data['phone']);
        $address=$this->fm->validation($data['address']);
        $address=mysqli_real_escape_string( $this->db->link,$data['address']);

        $permited= array('jpg' ,'jpeg','png','gif');
        $file_name   =$file['pro_pic']['name'];
        $file_size   =$file['pro_pic']['size'];
        $file_tmp    =$file['pro_pic']['tmp_name'];

        $div         =explode('.', $file_name);
        $file_txt    =strtolower(end($div));
        // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image  too}
        $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
        $upload_image="Uploads/".$unique_image;
        if($name==""||$email==""||$country==""||$city==""||$phone==""||$address==""||
          $file_name==""){
			$msg="<h6 class='alert alert-danger' id='close_note'
		            <i class='fa fa-power-off mr-1'></i>
                    eilds name must not be emty!!
				    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
       }else{
          if(!empty($file_name)){

             if($file_size>1048567){
              echo "<h5 class='text-danger'>Product not Inserted!!</h5>";
             }elseif (in_array($file_txt, $permited)==false){
              echo "<h5 class='alert alert-danger'>You can upload only:-".implode(',', $permited)."</h5>";
             }else{
              move_uploaded_file($file_tmp,$upload_image);
              $query="UPDATE tbl_customer
                     SET
                     name   ='$name',
                     email  ='$email',
                     country='$country',
                     city   ='$city',
                     phone  ='$phone',
                     address='$address',
                     pro_pic='$upload_image'
                     WHERE cstmrId='$cmrId'";
             $customerUpdate=$this->db->update($query);
          if($customerUpdate){
             // echo "<script>window.location='edit_account.php';</script>";
          $msg_success="<h5 class='alert alert-success' id='close_note'
                           <i class='fa fa-exclamation-triangle mr-1'>
                            </i> Profile updated successfully!!
							<i class='fa fa-close pull-right' id='close_tap'></i>
                        </h5>";
          return $msg_success;
         }else{
		    $msg="<h6 class='alert alert-danger' id='close_note'>
		            <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Profile not Updated..!!
				    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
            return $msg;
          }
         }
        }else{
             $query="UPDATE tbl_customer
                     SET
                     name   ='$name',
                     email  ='$email',
                     country='$country',
                     city   ='$city',
                     phone  ='$phone',
                     address='$address'
                     WHERE cstmrId='$cmrId'";
              $customerUpdate=$this->db->update($query);
              if($customerUpdate){
              $msg_success="<P class='alert alert-success' id='close_note'>
                           <i class='fa fa-exclamation-triangle mr-1'>
                            </i> Prfile updated successfully!!
							<i class='fa fa-close pull-right' id='close_tap'></i>
                        </P>";
              return $msg_success;
             }else{
              $msg ="<P class='alert alert-danger' id='close_note'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Product not Updated..!!
					 <i class='fa fa-close pull-right' id='close_tap'></i>
                   </P>";
              return $msg;
             }
          }
       }
      }
      public function customerAccntDel($yes,$cmrId){
        $query="DELETE FROM tbl_customer WHERE cstmrId='$cmrId'";
        $delCustomer=$this->db->delete($query);
        if ($delCustomer) {
          echo "<script>window.open('my_account.php','_self')</script>";
        }else{
          $msg ="<P class='alert alert-danger' id='close_note'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Somethng went wrong..!!
					 <i class='fa fa-close pull-right' id='close_tap'></i>
                  </P>";
          return $msg;
        }
      }
      // User activation  to access
      public function activation($actId){
        $id=$this->fm->validation($actId);
        $query="UPDATE tbl_customer
                     SET
                     status ='1'
                     WHERE cstmrId='$id'";
            $activationUpdate=$this->db->update($query);
            return $activationUpdate;
     }
     // User activation  to access for inactive/block
      public function Inactivation($InactId){
        $id=$this->fm->validation($InactId);
        $query="UPDATE tbl_customer
                     SET
                     status ='0'
                     WHERE cstmrId='$id'";
            $InactivationUpdate=$this->db->update($query);
            return $InactivationUpdate;
     }
     //Delete delCustById method class
      public function delCustById($id){
        $query   ="SELECT * FROM tbl_customer WHERE cstmrId='$id'";
        $getData =$this->db->select($query);
        if($getData){
          $delquery   ="DELETE FROM tbl_customer WHERE cstmrId='$id'";
          $delProData =$this->db->delete($delquery);
       if($delProData){
                 $msg_success="<h5 class='text-success text-bold ml-5'>
                                  <i class='fas fa-check-circle mr-1'>
                                    Deleted Successfully!!
                                  </i>
                               </h5>";
          return $msg_success;
          }else{
            $msg_invalid="<h5 class='text-danger text-bold ml-5'>
                            <i class='fas fa-exclamation-triangle mr-1'>
                              not Deleted!!
                            </i>
                          </h5>";
           return $msg_invalid;
         }
        }
      }
      //customer ppassword change or update method start
      public function customerPassUpdate($data,$cmrId){
        //md5($data['password']))
        $old_pass=$this->fm->validation(md5($data['old_pass']));
        $old_pass=mysqli_real_escape_string($this->db->link,md5($data['old_pass']));
        $new_pass=$this->fm->validation($data['new_pass']);
        $new_pass=mysqli_real_escape_string($this->db->link,$data['new_pass']);
        $new_pass_agin=$this->fm->validation($data['new_pass_agin']);
        $new_pass_agin=mysqli_real_escape_string($this->db->link,$data['new_pass_agin']);
         if($old_pass==""||$new_pass==""||$new_pass_agin==""){
            $msg ="<h5 class='alert alert-danger'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Invalid Input Feilds!!
                  </h5>";
            return $msg;
          //echo "<script>alert('Feilds name must not be emty!!')<script>";
         }else{
           $query ="SELECT * FROM tbl_customer WHERE password='$old_pass' AND cstmrId='$cmrId'";
           $result=$this->db->select($query);//->fetch_assoc()
           if ($result==FALSE){
             $msg ="<h5 class='alert alert-danger'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Sorry old Password didn't mathced or invalid old password!!
                  </h5>";
            return $msg;
           }else{
             if($new_pass!==$new_pass_agin){
               //echo"<script>alert('Sorry your Current Password didn't mathced or invalid password!!)</script>";
              $msg ="<h5 class='alert alert-danger'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                     </i> Sorry your Current Password didn't mathced or invalid password!!
                  </h5>";
              return $msg;
             }else{
              $new_encpt_pass=$this->fm->validation(md5($data['new_pass']));
              $new_encpt_pass=mysqli_real_escape_string($this->db->link,md5($data['new_pass']));
              $query="UPDATE tbl_customer SET password ='$new_encpt_pass' WHERE cstmrId='$cmrId'";
              $Update_row =$this->db->update($query);
             if($Update_row){
               $msg_success="<h5 class='alert alert-success'>
                            <i class='fa fa-check-circle mr-1'>
                            </i> Your Pawssord Updated You can loggin Now!!
                          </h5>";
             return $msg_success;
             }else{
               $msg_invalid="<h5 class='alert alert-danger'>
                        <i class='fas fa-exclamation-triangle mr-1'>
                        </i> Something went wrong!!
                      </h5>";
               return $msg_invalid;
             }
           }
         }
        }
      }
       //customer ppassword change or update method end
      //customer verifiasction safter registrastion strat script
      public function verifyCustomer($vkey){
        $vkey=$this->fm->validation($vkey);
        $vkey =mysqli_real_escape_string( $this->db->link,$vkey);
        if($vkey!=false){
          $query ="SELECT verified,vkey FROM tbl_customer WHERE verified='0' AND vkey='$vkey' LIMIT 1";
          $result=$this->db->select($query);
          if ($result!==0) {
            $Updatequery="UPDATE tbl_customer SET verified ='1' WHERE vkey= '$vkey' LIMIT 1";
            $Update_row =$this->db->update($Updatequery);

            if ($Update_row) {
              $msg_invalid="<h5 class='text-info text-bold ml-5'>
                              <i class='fa fa-check-circle mr-1'>
                                Your account verified You can loggin Now!!
                              </i>
                            </h5>
                            <h5 class='text-info text-bold'>
                              <i class='fa fa-arrow-right mr-1'>
                                <a href='login.php'>Çlick here to loggin</a>
                              </i>
                            </h5>";
             return $msg_invalid;
            }else{
            $msg_invalid="<h5 class='text-danger text-bold ml-5'>
                            <i class='fa fa-exclamation-triangle mr-1'>
                               Error here Incomplet verification try again!!
                            </i>
                          </h5>";
             return $msg_invalid;
            }
          }else{
           $msg_invalid="<h5 class='text-danger text-bold ml-5'>
                            <i class='fa fa-exclamation-triangle mr-1'>
                               This account invalid or already verified!!
                            </i>
                          </h5>";
           return $msg_invalid;
          }
        }else{
          $msg_invalid="<h5 class='text-danger text-bold ml-5'>
                          <i class='fas fa-exclamation-triangle mr-1'>
                            Something went wrong!!
                          </i>
                        </h5>";
          return $msg_invalid;
        }
      }//customer verifiasction safter registrastion end
      public function getallmassage(){
        $query="SELECT * FROM  tbl_contact ORDER BY cstmId DESC";
        $result=$this->db->select($query);
        return $result;
      }
      public function getall_msg_report(){
        $query="SELECT * FROM  tbl_contact ORDER BY cstmId DESC";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function get_cust_src_msg($search){
        $query="SELECT * FROM tbl_contact WHERE cfname LIKE '%$search%' OR  clname like '%$search%' OR email like '%$search%' OR Subject like '%$search%' OR msg like '%$search%' OR date like '%$search%'";
        $result=$this->db->select($query);
        return $result;   
      }
      public function get_msg_src_count($search){
        $query="SELECT * FROM tbl_contact WHERE cfname LIKE '%$search%' OR  clname like '%$search%' OR email like '%$search%' OR Subject like '%$search%' OR msg like '%$search%' OR date like '%$search%'";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function get_msg_src_bydt($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $query="SELECT * FROM tbl_contact WHERE date BETWEEN '$from_dt' AND '$to_dt' ORDER BY date";
        $result=$this->db->select($query);
        return $result;
      }
      public function get_msg_src_by_date_count($from_dt,$to_dt){
        $from_dt=$this->fm->validation($from_dt);
        $from_dt=mysqli_real_escape_string($this->db->link,$from_dt);
        $to_dt=$this->fm->validation($to_dt);
        $to_dt=mysqli_real_escape_string($this->db->link,$to_dt);
        $sql="SELECT * FROM tbl_contact WHERE date BETWEEN '$from_dt' AND '$to_dt' ORDER BY date";
         $searchData = $this->db->select($sql);
         if ($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
      }
      public function getall_seen_msg(){
        $query="SELECT * FROM  tbl_contact WHERE status='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
        return $result;
      }
      public function get_seen_msg_count(){
        $query="SELECT * FROM  tbl_contact WHERE status='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function get_unseen_msg_count(){
        $query="SELECT * FROM  tbl_contact WHERE status='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
     public function getall_unseen_msg(){
        $query="SELECT * FROM  tbl_contact WHERE status='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
        return $result;
      }
      public function get_draft_msg(){
        $query="SELECT * FROM  tbl_contact WHERE save_sts='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
        return $result;
           
      }
      public function get_draft_msg_count(){
        $query="SELECT * FROM  tbl_contact WHERE save_sts='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function get_message_byId($id){
        $query="SELECT * FROM  tbl_contact WHERE  cstmId='$id'";
        $result=$this->db->select($query);
        return $result;
      }
      public function unseen_message_byId($id){
        $id=$this->fm->validation($id);
        $id =mysqli_real_escape_string( $this->db->link,$id);
        $query="UPDATE tbl_contact SET status='0' WHERE cstmId= '$id'";
        $Update_row =$this->db->update($query);
         if ($Update_row) {
           echo "<script>window.open('userControl.php?c_msg','_self')</script>";
         };
      }
      public function seen_message_byId($seenid){
        $seenid=$this->fm->validation($seenid);
        $seenid =mysqli_real_escape_string( $this->db->link,$seenid);
        $query="UPDATE tbl_contact SET status='1' WHERE cstmId= '$seenid'";
        $Update_row =$this->db->update($query);
         if ($Update_row) {
           echo "<script>window.open('userControl.php?c_msg','_self')</script>";
         };  
      }
      public function save_message_byId($id){
        $id=$this->fm->validation($id);
        $id =mysqli_real_escape_string( $this->db->link,$id);
        $query="UPDATE tbl_contact SET save_sts='1' WHERE cstmId= '$id'";
        $Update_row =$this->db->update($query);
         if ($Update_row) {
           echo "<script>window.open('userControl.php?c_msg','_self')</script>";
         };  
      }
      public function getSeenMassage(){
        $query="SELECT * FROM  tbl_contact WHERE status='1' ORDER BY cstmId DESC";
        $result=$this->db->select($query);
        return $result;
      }
      public function get_replied_msg_count($id){
        $query="SELECT * FROM  tbl_reply WHERE cmrId='$id' ORDER BY repId DESC";
        $result=$this->db->select($query);
           if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(0)";
          }
      }
      public function get_replied_msg($id){
        $query="SELECT * FROM  tbl_reply WHERE cmrId='$id' ORDER BY repId DESC";
        $result=$this->db->select($query);
         return $result; 
      }
      public function rep_del_msg($id){
        $id=$this->fm->validation($id);
        $id =mysqli_real_escape_string( $this->db->link,$id);
        $query ="DELETE FROM tbl_reply WHERE repId='$id'";
        $result=$this->db->delete($query);
        return $result;
      }
    }
 ?>
 <!-- fac211c352da9c8f199311ea34ac7bfd -->
