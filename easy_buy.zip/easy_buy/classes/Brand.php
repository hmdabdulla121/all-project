<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php 
 class Brand{
	 private $db;
	 private $fm;
 
    public function __construct(){ 
	   $this->db =new Database();
	   $this->fm =new Format();
   }
    public function brandInsert($brandName){
   	   $brandName=$this->fm->validation($brandName);
       $brandName=mysqli_real_escape_string( $this->db->link,$brandName);
       if (empty($brandName)){
       	 $msg ="<h4 class='alert alert-danger'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                        Field Must not empry!!
                     </i>
                   </h4>";
          return $msg;
        }else{
       	 $query ="INSERT INTO tbl_brand(brandName) VALUES('$brandName')";
       	 $insertBrand=$this->db->insert($query);
       	 if ($insertBrand) {
       		$msg_success="<h4 class='alert-success alert'>Brand Inserted Successfully!!</h4>";
       		return $msg_success;
       	}else{
          $msg ="<h4 class='alert-danger alert'>
                     <i class='fa fa-exclamation-triangle mr-1'>
                        Brand Name not Inserted!!
                     </i>
                   </h4>";
          return $msg;
       	}
      } 
   }
   public function getallbrand(){
     $query   ="SELECT * FROM tbl_brand ORDER BY brandId DESC";
     $result  =$this->db->select($query);
     return $result;
   }
   public function getbrandById($brandid){
     $query   ="SELECT * FROM tbl_brand WHERE brandId='$brandid'";
     $result  =$this->db->select($query);
     return $result;
   }
   public function updatebrand($up_brand,$up_date,$id){
     $up_brand=$this->fm->validation($up_brand);
     $up_brand=mysqli_real_escape_string( $this->db->link,$up_brand);
     $up_date =$this->fm->validation($up_date);
     $up_date =mysqli_real_escape_string( $this->db->link,$up_date);
     $id      =$this->fm->validation($id); 
     $id      =mysqli_real_escape_string( $this->db->link,$id);
       
       if (empty($up_brand) || empty($up_date)){
          $msg="<h4 class='alert alert-danger'>Field must not be emty!!</h4>";
          return $msg;
       }else{
         $query  ="UPDATE tbl_brand
                   SET brandName='$up_brand',
                       add_date ='$up_date'
                   WHERE brandId='$id'";
         $Update_row =$this->db->update($query);
          if ($Update_row) {
             $msg_success="<h4 class='alert alert-success'>
                             <i class='fa fa-check-circle'>
                              Brand Updated Successfully!!
                             </i>
                           </h4>";
          return $msg_success;
         }else{
             $msg_invalid="<h4 class='alert alert-danger'>
                              <i class='fa fa-exclamation-triangle mr-1'>
                                  Brand not Updated!!
                               </i>
                           </h4>";
             return $msg_invalid;
           }
         }
       }
     public function brandDel($id){
        $query   ="DELETE FROM tbl_brand WHERE brandId='$id'";
        $deleteBrand  =$this->db->delete($query);
      if ($deleteBrand){
             $msg_success="<h4 class='alert alert-success'>
                            <i class='fa fa-check-circle'>
                              Brand Deleted Successfully!!
                            </i> 
                           </h4>";
          return $msg_success;
         }else{
             $msg_invalid="<h4 class='alert alert-danger'>
                              <i class='fa fa-exclamation-triangle mr-1'>
                                  Brand not Deleted!!
                               </i>
                           </h4>";
             return $msg_invalid;
           }
       }
       public function search_brand($search){
         $search=$this->fm->validation($search);
         $search=mysqli_real_escape_string( $this->db->link,$search);
         $sql="SELECT * FROM tbl_brand WHERE brandName LIKE '%$search%' OR add_date like '%$search%'";
         $searchData = $this->db->select($sql);
         return $searchData;
       }
       public function gelAllBrands(){
           $query ="SELECT * FROM tbl_brand ORDER BY brandId DESC";
           $result=$this->db->select($query);
          if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
       }
       
    }
 ?>