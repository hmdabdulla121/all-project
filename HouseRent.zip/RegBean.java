package com.mamun.ice;

public class RegBean {
	
	private String firstName,laseName,countryName,areaName,blockName,houseName,roomNumber,contactNumber,subject;  
	  
	public String getfName() {  
	    return firstName;  
	}  
	public void setCode(String firstName) {  
	    this.firstName = firstName;  
	}  


	public String getlName() {  
	    return laseName;  
	}  
	public void setName(String laseName) {  
	    this.laseName = laseName;  
	}  
	
	public String getCountry() {  
	    return countryName;  
	}  
	public void setCountry(String countryName) {  
	    this.countryName = countryName;  
	}  
	
	
	public String getareaName() {  
	    return areaName;  
	}  
	public void setareaName(String areaName) {  
	    this.areaName = areaName;  
	}  
	
	public String getblockName() {  
	    return blockName;  
	}  
	public void setblockName(String blockName) {  
	    this.blockName = blockName;  
	}  
	
	public String gethouseName() {  
	    return houseName;  
	}  
	public void sethouseName(String houseName) {  
	    this.houseName = houseName;  
	}  
	
	public String getroomNumber() {  
	    return roomNumber;  
	}  
	public void setroomNumber(String roomNumber) {  
	    this.roomNumber = roomNumber;  
	}  
	
	public String getcontactNumber() {  
	    return contactNumber;  
	}  
	public void setcontactNumber(String contactNumber) {  
	    this.contactNumber = contactNumber;  
	}  
	
	public String getsubject() {  
	    return subject;  
	}  
	public void setsubject(String subject) {  
	    this.subject = subject;  
	}  
	
}
