package com.mamun.ice;

import java.sql.Connection;
import java.sql.Statement;

import com.mamun.ice.DBMS;

public class ProjectRelFun {
	
	
	public int insert(String firstName, String laseName, String countryName,String areaName,String blockName, String houseName,String roomNumber,String contactNumber,String subject) {
		
		int i=4;
		try {
			if(i==0) {
				Connection con = DBMS.getMySqlConnection();
	    		Statement stmt = con.createStatement();
	    		stmt.executeUpdate("use house_rent");
	    		i=stmt.executeUpdate("insert into postPage values('"+ firstName + "', '" + laseName + "', '" + countryName +"', '"+ areaName +"', '"+ blockName +"', '"+ houseName +"', '"+ roomNumber +"', '"+ contactNumber +"', '" + subject + "') ");  		 
			}if(i==1) {
				Connection con = DBMS.getMySqlConnection();
	    		Statement stmt = con.createStatement();
	    		stmt.executeUpdate("use house_rent");
	    		i=stmt.executeUpdate("insert into mess_post values('"+ firstName + "', '" + laseName + "', '" + countryName +"', '"+ areaName +"', '"+ blockName +"', '"+ houseName +"', '"+ roomNumber +"', '"+ contactNumber +"', '" + subject + "') ");  		 
			}if(i==2) {
				Connection con = DBMS.getMySqlConnection();
	    		Statement stmt = con.createStatement();
	    		stmt.executeUpdate("use house_rent");
	    		i=stmt.executeUpdate("insert into low_post values('"+ firstName + "', '" + laseName + "', '" + countryName +"', '"+ areaName +"', '"+ blockName +"', '"+ houseName +"', '"+ roomNumber +"', '"+ contactNumber +"', '" + subject + "') ");  		 
			}if(i==3) {
				Connection con = DBMS.getMySqlConnection();
	    		Statement stmt = con.createStatement();
	    		stmt.executeUpdate("use house_rent");
	    		i=stmt.executeUpdate("insert into medium_post values('"+ firstName + "', '" + laseName + "', '" + countryName +"', '"+ areaName +"', '"+ blockName +"', '"+ houseName +"', '"+ roomNumber +"', '"+ contactNumber +"', '" + subject + "') ");  		 
			}if(i==4) {
				Connection con = DBMS.getMySqlConnection();
	    		Statement stmt = con.createStatement();
	    		stmt.executeUpdate("use house_rent");
	    		i=stmt.executeUpdate("insert into high_post values('"+ firstName + "', '" + laseName + "', '" + countryName +"', '"+ areaName +"', '"+ blockName +"', '"+ houseName +"', '"+ roomNumber +"', '"+ contactNumber +"', '" + subject + "') ");  		 
			}
		
		  } catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} 		
		return i;
	}
	

	
/*	public int UpdateData(String code, String name, String price) {
		int i=0;
		try {
    		Connection con = DBMS.getMySqlConnection();
    		Statement stmt = con.createStatement();
    		stmt.executeUpdate("use company_product");
    		
			i=stmt.executeUpdate("update product set code='"+code +"', name='"+name +"', price='"+price+"' ");
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} 
		
		return i;
		
	}*/

}
