package com.mail;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.*;
import com.mamun.ice.DBMS;



@WebServlet("/mail")
public class mail extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public mail() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String message=request.getParameter("message");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		
		
		
		function fn=new function();
		int i=0;
		
		// For Insert Function
        if(message!=null && name!=null && email!=null) {
        i=fn.insert(message,name,email);
        	
        if(i>0){  
	            RequestDispatcher rd=request.getRequestDispatcher("home.jsp");  
	            rd.forward(request, response);  
	            }
	        else{  
	            RequestDispatcher rd=request.getRequestDispatcher("/contact_page.jsp");  
	            rd.forward(request, response);  
	        } 
        }
	}


public class function {
	public int insert(String message, String name, String email) {
		int i=0;
	   try {
		   if(i>0) {
			   Connection con=DBMS.getMySqlConnection();
			   Statement stmt=con.createStatement();
			   stmt.executeUpdate("use house_rent");
			   i=stmt.executeUpdate("insert into contuct_form values('"+message+"','"+name+"','"+email+"')");
		   }
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
		return i;
		
	}
}
	
}
