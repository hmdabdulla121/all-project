package com.mamun.ice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mamun.ice.ProjectRelFun;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.lang.*;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/RegServletController")
public class RegServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	   public RegServletController() {
	        super();
	        // TODO Auto-generated constructor stub
	    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();
        String firstName = request.getParameter("firstname");
		String laseName = request.getParameter("lastname");
		String countryName = request.getParameter("country");
		String areaName = request.getParameter("areaname");
		String blockName = request.getParameter("blockname");
		String houseName = request.getParameter("housename");
		String roomNumber = request.getParameter("roomnumber");
		String contactNumber = request.getParameter("contactnumber");
		String subject = request.getParameter("subject");
		

		
	       ProjectRelFun pr=new ProjectRelFun();   
	        int i=4;
	        
	     
			// For Insert Function
	        if(firstName !=null && areaName !=null && contactNumber !=null) {
	        i=pr.insert(firstName,laseName, countryName, areaName, blockName, houseName, roomNumber, contactNumber, subject);
	        	
	        if(i==0){  
		            RequestDispatcher rd=request.getRequestDispatcher("postPage.jsp");  
		            rd.forward(request, response);  
		           
		        }else if(i==1) {
		            RequestDispatcher rd=request.getRequestDispatcher("High_post.jsp");  
		            rd.forward(request, response);  
		        }else if(i==2) {
		            RequestDispatcher rd=request.getRequestDispatcher("Low_post.jsp");  
		            rd.forward(request, response);  
		        }else if(i==3) {
		            RequestDispatcher rd=request.getRequestDispatcher("Medium_post.jsp");  
		            rd.forward(request, response);  
		        }else if(i==4) {
		            RequestDispatcher rd=request.getRequestDispatcher("Mess_post.jsp");  
		            rd.forward(request, response);  
		        }
		        else{  
		            RequestDispatcher rd=request.getRequestDispatcher("/Add_Insert.jsp");  
		            rd.forward(request, response);  
		        } 
	        }
	        
	        

	        
	/*        // For Update Function
	        String code1=request.getParameter("code");
	        i=0;
	        if(code1!=null) {
	        i=pr.UpdateData(code,name,price);
	        if(i>0){  
	            RequestDispatcher rd=request.getRequestDispatcher("view.jsp");  
	            rd.forward(request, response);  
	        }  
	        else{  
	            RequestDispatcher rd=request.getRequestDispatcher("update.jsp");  
	            rd.forward(request, response);  
	            }
	        }*/
		}

}

