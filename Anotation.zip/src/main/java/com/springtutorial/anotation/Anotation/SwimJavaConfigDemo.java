package com.springtutorial.anotation.Anotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SwimJavaConfigDemo {

	public static void main(String[] args) {
		// load spring config file
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SportConfig.class);

		// retrieve bean from spring container
		SwimCoach theCoach = (SwimCoach) context.getBean("swimCoach");

		// Call the method
		System.out.println(theCoach.getDailyWork());
		// call a new Method
		System.out.println(theCoach.FortuneService());
		
		
		//call new method 
		
		System.out.println("emai:"+theCoach.getEmail());
		
		System.out.println("team:"+theCoach.getTeam());

		context.close();

	}

}
