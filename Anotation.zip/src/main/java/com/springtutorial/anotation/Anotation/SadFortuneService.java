package com.springtutorial.anotation.Anotation;

public class SadFortuneService implements FortuneService {

	public String getFortuneService() {
		// TODO Auto-generated method stub
		return "Today your sad day!";
	}

}
