package com.springtutorial.anotation.Anotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class App {
	public static void main(String[] args) {

		// load spring config file
		ApplicationContext context = new FileSystemXmlApplicationContext("beans.xml");

		// retrieve bean from spring container
		Coach theCoach = (Coach) context.getBean("thatSillyCoach");

		// Call the method
		System.out.println(theCoach.getDailyWork());
		// call a new Method
		System.out.println(theCoach.FortuneService());

		((AbstractApplicationContext) context).close();
	}
}
