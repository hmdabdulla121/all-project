package com.springtutorial.anotation.Anotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JavaConfigDemo {

	public static void main(String[] args) {
		// load spring config file
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SportConfig.class);

		// retrieve bean from spring container
		Coach theCoach = (Coach) context.getBean("thatSillyCoach");

		// Call the method
		System.out.println(theCoach.getDailyWork());
		// call a new Method
		System.out.println(theCoach.FortuneService());

		context.close();

	}

}
