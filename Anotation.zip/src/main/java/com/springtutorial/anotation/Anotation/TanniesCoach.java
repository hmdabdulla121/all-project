package com.springtutorial.anotation.Anotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("thatSillyCoach")
public class TanniesCoach implements Coach {
    
	@Autowired
	@Qualifier("randomFortuneService")
	private FortuneService fortuneService;
	
	/*
	 * @PostConstruct public void doMyStartup() {
	 * System.out.println(">>TanniesCoach: inside of doMyStartup()"); }
	 * 
	 * @PreDestroy public void doMyDestry() {
	 * System.out.println(">>TanniesCoach : inside of doMyDestroy()"); }
	 */
	

	// Autowired annotation for setter method
	
	/*
	
	@Autowired
	public void setFortuneService(FortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}
	*/
	
	// Autowired annotation for constructor
	/*
	 * @Autowired public TanniesCoach(FortuneService fortuneService) {
	 * this.fortuneService = fortuneService; }
	 */

	// Any method can use Autowired
	/*
	 * @Autowired public void MyDemoFunction(FortuneService fortuneService) {
	 * this.fortuneService = fortuneService; }
	 */
	
	public String getDailyWork() {

		return "HI, practice backhand volley";
	}

	public String FortuneService() {
		return fortuneService.getFortuneService();
	}

}
