package com.springtutorial.anotation.Anotation;

public interface FortuneService {
	
	public String getFortuneService();
	
}
