package com.springtutorial.anotation.Anotation;

public interface Coach{
	public String getDailyWork();
	public String FortuneService();

}
