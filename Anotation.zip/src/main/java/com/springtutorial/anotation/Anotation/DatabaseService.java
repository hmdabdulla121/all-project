package com.springtutorial.anotation.Anotation;

import org.springframework.stereotype.Component;

@Component
public class DatabaseService implements FortuneService {

	public String getFortuneService() {
		// TODO Auto-generated method stub
		return null;
	}

}
