<?php 
require('connection.inc.php');
require('function.inc.php');

$name = get_safe_value($con, $_POST['name']);
$email = get_safe_value($con, $_POST['email']);
$mobile = get_safe_value($con, $_POST['mobile']);
$password = get_safe_value($con, $_POST['password']);


$sql = mysqli_query($con,"SELECT * FROM users WHERE email='$email'");
$check_users = mysqli_num_rows($sql);
  if ($check_users>0) {
  	echo "already_exist";
  }else{
  	$added_on = date('Y-m-d h:i:s');
  	mysqli_query($con, "INSERT INTO users(name,email,mobile,password,added_on) VALUES('$name','$email','$mobile','$password','$added_on')");
  	echo "inserted";
  }

 ?>