<?php 
session_start();
$con = mysqli_connect("localhost","smflboyu_myEcom","Y%G@0UcW&;Vs","smflboyu_myecom");

define('SERVER_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
define('SITE_PATH', 'http://smflybuy.com/');

define('PRODUCT_IMAGE_SERVER_PATH', SERVER_PATH.'/media/product/');
define('PRODUCT_IMAGE_SITE_PATH', SITE_PATH.'/media/product/');
 ?>