<?php 
require('./connection.inc.php');
require('./function.inc.php');
$msg =  '';
if (isset($_POST['submit'])) {
	 $username = get_safe_value($con, $_POST['username']);
	 $password = get_safe_value($con,$_POST['password']);

    $sql ="SELECT * FROM admin_users WHERE username ='$username' and password = '$password'";
    $res = mysqli_query($con,$sql);
    $count = mysqli_num_rows($res);

    if ($count > 0) {
    	$row = mysqli_fetch_assoc($res);
    	if($row['status']=='0'){
           $msg = "Account Deactivated";
    	}else{
	    	$_SESSION['ADMIN_LOGIN'] = 'yes';
	    	$_SESSION['ADMIN_ID'] = $row['id'];
	    	$_SESSION['ADMIN_USERNAME'] = $username;
	    	$_SESSION['ADMIN_ROLE'] = $row['role'];
	    	header('location:categories.php');
	    	die();
        }
    }else{
    	$msg = "Please Enter correct information";
    }
}

 ?>

<style>
	*{
	padding: 0;
	margin:0;
}

p{
	font-weight: bold;
}
input{
	width: 300px;
	height: 30px;
}

.error{
	color: red;
}

/*Registration form design start*/
.login{
	width: 300PX;
	height: auto;
	margin: 5px auto;
	padding: 25px;
	border: 1px solid black;
	-webkit-border-radius :5px;
	-moz-border-radius :5px;
	-o-border-radius :5px;
    
}
.placeholder{
	width: 1px;
	height: 20px;
}
</style>

<div class="login">
		<div class="placeholder"></div>
		<h1>Login Form</h1>
		<div class="placeholder"></div>
	
	<form action="#" method="post">
		 

		 User Name:<input type="text" name="username" value=""   placeholder="Enter User Name" required>
		 <div class="placeholder"></div>

		 PASSWORD:<input type="password" name="password" value=""  placeholder ="Enter password"required>
		 <div class="placeholder"></div>


		 <input type="submit" name="submit" value="submit" style="display: inline-block; width: 100%; height: 30px; margin: 3px 0 2px 0px;">
		  <div class="error">
		  	<?php echo $msg; ?>
		  </div>
	</form>
</div>