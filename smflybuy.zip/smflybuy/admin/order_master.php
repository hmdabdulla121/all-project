<?php 
 require('top.inc.php');
 isAdmin();

$sql = "SELECT * FROM users ORDER BY id DESC";
$res = mysqli_query($con,$sql);

 ?>

  <div class="clearfix"></div>
        <!-- Orders -->
    <div class="orders">
     <div class="row">
      <div class="col-xl-12">
        <div class="card">
        <div class="card-body">
            <h4 class="box-title">Order Master</h4>
        </div>
        <div class="card-body--">
            <div class="table-stats order-table ov-h">
            <table class="table">
               <thead>
                 <tr>
                    <td class="product-name"><span class="nobr">Order Id</span></td>
                    <th class="product-name"><span class="nobr">Order Date</span></th>
                    <th class="product-price"><span class="nobr"> Address</span></th>
                    <th class="product-price"><span class="nobr"> Payment Type</span></th>
                    <th class="product-price"><span class="nobr"> Payment Status</span></th>
                    <th class="product-price"><span class="nobr"> Order Status</span></th>
                 </tr>
              </thead>
                    <tbody>
                    <?php 

                    $res = mysqli_query($con,"SELECT `order`.*,order_status_action.name AS order_status_str FROM `order`,order_status_action WHERE  order_status_action.id = `order`.order_status ORDER BY `order`.id desc");
                    while ($row = mysqli_fetch_assoc($res)) {
                         ?>
                        <tr>
                         <td class="product-add-to-cart">
                            <a href="order_master_detail.php?id=<?php echo $row['id']; ?>">
                                <?php echo $row['id']; ?>  
                            </a>
                         </td>
                          <td class="product-add-to-cart"><?php echo $row['added_on']; ?></td>
                          <td class="product-add-to-cart"><?php echo $row['address']; ?><br>
                            <?php echo $row['city']; ?><br>
                            <?php echo $row['pincode']; ?>
                              
                          </td>
                          <td class="product-add-to-cart"><?php echo $row['payment_type']; ?></td>
                          <td class="product-add-to-cart"><?php echo $row['payment_status']; ?></td>
                          <td class="product-add-to-cart"><?php echo $row['order_status_str']; ?></td>

                        </tr>
                     <?php } ?>
                    </tbody>
                </table>
            </div> <!-- /.table-stats -->
        </div>
     </div> <!-- /.card -->
    </div>  <!-- /.col-lg-8 -->
  </div>
 </div>

<?php 
 require('footer.inc.php');
 ?>