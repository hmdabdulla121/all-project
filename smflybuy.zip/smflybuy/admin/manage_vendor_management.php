<?php 
 ob_start();
 require('top.inc.php');
isAdmin();
$username = '';
$password = '';
$email = '';
$mobile = '';

$msg = '';

if (isset($_GET['id']) && $_GET['id'] != '') {
   $id = get_safe_value($con, $_GET['id']);
   $res = mysqli_query($con, "SELECT * FROM admin_users WHERE id='$id'");

   $check = mysqli_num_rows($res);
   if ($check > 0) {
     $row = mysqli_fetch_assoc($res);
     $username = $row['username'];
     $password = $row['password'];
     $email = $row['email'];
     $mobile = $row['mobile'];
    
   }else{
     header('location:vendor_management.php');
    die();
   }
  
}


if (isset($_POST['submit'])) {
      $username = get_safe_value($con, $_POST['username']);
      $password = get_safe_value($con, $_POST['password']);
      $email = get_safe_value($con, $_POST['email']);
      $mobile = get_safe_value($con, $_POST['mobile']);
   
$res = mysqli_query($con, "SELECT * FROM admin_users WHERE username='$username'");
   $check = mysqli_num_rows($res);
   if ($check >0) {
      if (isset($_GET['id']) && $_GET['id'] != ''){
         $getData = mysqli_fetch_assoc($res);
         if ($id == $getData['id']) {
           # code...
         }else{
          $msg = "Username already exist";
         }

      }else{
        $msg = "Username already exist";
      }

}

   if ($msg == '') {
        if (isset($_GET['id']) && $_GET['id'] != ''){
       
          $update_sql = "UPDATE admin_users SET username='$username',password='$password',email='$email',mobile='$mobile' WHERE id='$id'";
          mysqli_query($con,$update_sql);

       }else{
         
      mysqli_query($con,"INSERT INTO admin_users(username,password,email,mobile,role,status) VALUES('$username','$password','$email','$mobile',1,1)");
       }
       header('location:vendor_management.php');
       die();
   }
}


 ?>

<div class="content">
  <div class="animated fadeIn">
      <div class="row">
          <div class="col-lg-12">
              <div class="card">
                  <div class="card-header"><strong>Vendor Management</strong><small> Form</small></div>
                    <form method="POST">
                      <div class="card-body card-block">

                          <div class="form-group">
                           <label for="username" class=" form-control-label">Username</label><input type="text" name="username" placeholder="Enter username" class="form-control" required value="<?php echo($username) ?>">
                          </div>

                          <div class="form-group">
                           <label for="password" class=" form-control-label">Password</label><input type="text" name="password" placeholder="Enter password" class="form-control" required value="<?php echo($password) ?>">
                          </div>

                          <div class="form-group">
                           <label for="email" class=" form-control-label">Email</label><input type="email" name="email" placeholder="Enter email" class="form-control" required value="<?php echo($email) ?>">
                          </div>

                          <div class="form-group">
                           <label for="mobile" class=" form-control-label">Mobile</label><input type="text" name="mobile" placeholder="Enter mobile" class="form-control" required value="<?php echo($mobile) ?>">
                          </div>

                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block" name="submit">
                            <i class="fa fa-lock fa-lg"></i>&nbsp;
                            <span id="payment-button-amount">Save</span>
                            <span id="payment-button-sending" style="display:none;">Sending…</span>
                       </button>
                     </div>
                      <div class="error">
                        <?php echo $msg; ?>
                      </div>
                    </form>
              </div>
          </div>
      </div>
  </div>
</div><!-- .animated -->
<?php 
 require('footer.inc.php');
  ob_end_flush();
 ?>