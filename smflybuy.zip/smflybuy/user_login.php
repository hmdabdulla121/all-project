<?php 
require('connection.inc.php');
require('function.inc.php');

$email = get_safe_value($con, $_POST['email']);
$password = get_safe_value($con, $_POST['password']);

$sql = mysqli_query($con,"SELECT * FROM users WHERE email='$email' AND password='$password'");

$check_users = mysqli_num_rows($sql);
  if ($check_users>0) {
     $row = mysqli_fetch_assoc($sql);
     $_SESSION['USER_LOGIN']='yes';
     $_SESSION['USER_ID'] = $row['id'];
     $_SESSION['USER_NAME'] = $row['name'];
  	 echo "right";
  }else{
  	echo "wrong";
  }

 ?>