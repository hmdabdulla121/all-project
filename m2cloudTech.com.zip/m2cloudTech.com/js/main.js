// menu ber fixed on scrolling time.....
window.onscroll = function(){scrollFunction()};
var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function scrollFunction(){
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  }else{
    header.classList.remove("sticky");
  }
}

// slider slide....


/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
