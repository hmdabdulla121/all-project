<!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">

	<title> Home Page BAUET</title>
<link href="../font-awesome/css/font-awesome.css" rel="stylesheet" />

<link rel="stylesheet" href="../css/style.css" type="text/css">	

<style>

a:hover{ color:yellow}

</style>
</head>
<body>
	<div class="header">
		<div class="coverhead">
			<a href="../pages/index.html" id="logo"><img src="../images/library.jpg" alt="logo" height="58" width="50"></a>
			<div class="coverul">
				<div id="topbar"> 
  				   <ul>
  				 	
				 	<li><a href="#"><i class="fa fa-address-book-o fa-fw" aria-hidden="true"></i>Contact Us</a></li>	
					
       					<li><a href="../admin/admin_login.php"><i class="fa fa-user-circle-o fa-fw" aria-hidden="true"></i>Admin Login</a></li>
     				   </ul> 
  			
				</div>


				
				<ul class="selful">
					<li   class="selected">	<a href="index.html"><i class="fa fa-home fa-fw"></i>Home</a></li>
					<li><a href="facilities.html">Facilities</a></li>
					
					<li><a href="library.html">Library</a></li>
					<li><a href="timetable.html">Time Table</a></li>
					<li><a href="download.html">Downloads</a></li>
				
				
					
				</ul>
			</div>
		</div>
	</div>



	
	<div class="sidebar">	


				<ul >
					
					<li><a href="../admin/adminpanel.php"><i class="fa fa-ellipsis-v fa-fw "></i>Student Data Base</a></li>
					<li><a href="../managment/managmentpanel.php"><i class="fa fa-ellipsis-v fa-fw "></i></i>Staff Data Base</a></li>
					<li><a href="../fee/feepanel.php"><i class="fa fa-ellipsis-v fa-fw "></i>Fee Data Base</a></li>
					<li><a href="../datesheet/dspanel.php"><i class="fa fa-ellipsis-v fa-fw "></i>Manage Date Sheet</a></li>
					<li><a href="../accounts/accountpanel.php"><i class="fa fa-ellipsis-v fa-fw "></i> Accounts DataBase</a></li>
					<li><a href="../forum/form.php"><i class="fa fa-ellipsis-v fa-fw "></i>Discussion Forum</a></li>
				</ul>
	</div>


		<marquee id="marquee"  onmouseover="this.stop();" onmouseout="this.start();"> Admision Open. The classes will be started 1st sep. </marquee>

	
		<div>
			<div class="child1">
			<img src="../images/child1.jpg" alt="child1" width=550px;height=400px;/>
			</div>
		</div>
		

		<div>
			<div class="school2">
				
			<img src="../images/school2.jpg" alt="child1" width=550px;height=400px;/>
			</div>

		</div>
	
		<marquee id="marquee" onmouseover="this.stop();" onmouseout="this.start();"> BAUET any news any flash back here </marquee>


		<div>
			<div class="picbox">
				<div class="picbox1">
					<img src="../images/library.jpg" alt="library" width=300px;height=100px;/>
					<div><a href="library.html">Library</a></div>
			</div>
			
			<div class="picbox1">
				<img src="../images/canten.jpg" alt="canten" width=300px;height=100px;/>
					<div><a href="facilities.html">Facilities</a></div>
			</div>
			
		</div>


			<div class="resultsp">
				<div>
					
					<h1>Some Features..</h1>
						<div>	
							<i class="fa fa-graduation-cap fa-fw"></i>Education...........<br>
							<i class="fa fa-book fa-fw fa-fw "></i>Libraries...........<br>
							<i class="fa fa-bicycle fa-fw" aria-hidden="true"></i>Playgrounds.........<br>
							<i class="fa fa-cutlery fa-fw" aria-hidden="true"></i>Canteens............<br>
							
							<i class="fa fa-bus fa-fw"></i>BAUET Buses........<br>
						
						</div>
					
					
					<div class="button">
						<a href='download.html'>Prospectus<a>
						<p id="n"> click here to get detail about prospectus</p>
					</div>
					<div class="button">
						<a href="download.html">Fee Struct<a>
						<p id="n"> click here to get detail about fee</p>
					</div>
				</div>
	
			</div>	


		<div class="noticefull">
			<div class="noticehead"> Updated Events</div>
			<div class="noticebody">
				<marquee id="marquee2" direction="up" scrolldelay="150" onmouseover="this.stop();" onmouseout="this.start();">
	
					<img src="../images/new.gif"><a href="#">Mid term paper for BSC II classes will be held  22 Jan 2017</a>
					<br><br>
					<img src="../images/new.gif"><a href="#">Result is announced for BSC I </a>
					<br><br><br><br>
					<img src="../images/new.gif"><a href="#">Meeting for all staff at Assembly Hall at 22 dec</a>
					<br><br><br>
					<img src="../images/new.gif"><a href="#">Meeting for all staff at Assembly Hall at 22 dec</a>
					<br><br><br><br>
					<img src="../images/new.gif"><a href="#">Meeting for all staff at Assembly Hall at 22 dec</a>
	
				</marquee>
			
</div>
		<div id="noticedown"></div>
	   </div>
<div style="clear:both"><br></div>

		
<div class="footer">

	<div class="foot1">
		<img src="../images/worldmap.png" alt=""  >
         	 <a href="#"><i class="fa fa-fw"></i>Find Us With Google Maps&raquo; </a>
        

	</div>

	<div class="foot2">
		
		<p>Stay Update with us</p>
		<ul class="faico clear">
        	  <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        	  <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
        	  <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        	  <li><a class="faicon-flickr" href="#"><i class="fa fa-flickr"></i></a></li>
        	  <li><a class="faicon-rss" href="#"><i class="fa fa-rss"></i></a></li>
        	</ul>


	</div>
	<div class="foot3">
		
			<a class="f31" href="#">Administr</a>
			<a class="f32" href="#">Help Desk</a>
			<a class="f33" href="#">Feedback</a>
			<a class="f34" href="#">Complaints</a>
			
	
	</div>
	<div class="foot4">
		<div class="f41">
			<a href="index.html"><i class="fa fa-home fa-lg "></i></a>
			<a href="index.html"><i class="fa fa-info-circle fa-lg "></i></a>
			<a href="index.html"><i class="fa fa-address-book-o fa-lg "></i></a>
			<a href="../admin/logout.php"><i class="fa fa-sign-out fa-lg "></i></a>
		</div>
		<div class="f42">
			<br>
			<i class="fa fa-envelope fa-fw"></i>hmdabdulla121@gmail.com<br><br>
			<i class="fa fa-phone fa-fw"></i>01761112716
			
		</div>
	</div>

	
</div>

<!--------Update notice Updated date capture----->
<script>
var d = new Date();
document.getElementById("noticedown").innerHTML = d.toDateString();
</script>


</body>
</html>