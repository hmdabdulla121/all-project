<?php
// Variables

$User = "root";
$Password = "";
$Database = "fk";
$Host = "localhost";
$sqlDate = date('Y-m-d H:i:s'); 

		// 1. Create a database connection
$connection = mysqli_connect("localhost","root","");

if (!$connection) {
    error_log("Failed to connect to MySQL: " . mysqli_error($connection));
    die('Internal server error');
}

// 2. Select a database to use 
$db_select = mysqli_select_db($connection, 'fk');
if (!$db_select) {
    error_log("Database selection failed: " . mysqli_error($connection));
    die('Internal server error');
}
		
		$del_rec = $_GET['del'];
		
		$query = "DELETE FROM dcom WHERE sid='$del_rec'";
		
		if(mysqli_query($connection,$query)){
			echo "<script>window.open('dcomview.php?deleted=Record Deleted ','_self')</script>";
		}
		
		
		
		
		
?>
		