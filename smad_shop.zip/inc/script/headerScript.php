<?php
    include 'lib/session.php';
    Session::init();
    // include'lib/database.php';
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
    // include 'helpers/format.php';
    spl_autoload_register(function($class){
       include_once "classes/".$class.".php";
    });
    $db =new Database();
 	$fm =new Format();
   	$pd =new Product();
  	$ct =new Cart();
  	$cat=new category();
  	$bd =new Brand();
  	$cmr=new Customer();
    $ago= new Ago();
 ?>
<?php $url="http://localhost/smad_shop/"?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Smadobd shop</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="assest/img/favicon.ico" rel="shortcut icon"/>
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="assest/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assest/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="assest/css/owl.carousel.css"/>
	<!--<<link rel="stylesheet" href="assest/css/style.css"/>-->
	<!--<link rel="stylesheet" href="assest/css/animate.css"/> -->
   <?php 
    $get_theme=$ct->get_web_theme();
    if ($get_theme) {
        while($result=$get_theme->fetch_assoc()) {
   ?>
   <?php if ($result['theme']==1) { ?>
    <link rel="stylesheet" href="<?php echo $url?>assest/css/style.min.css"/>
   <?php }elseif ($result['theme']==2) { ?>
    <link rel="stylesheet" href="<?php echo $url?>assest/css/theme_deep_green.css"/>
   <?php }elseif ($result['theme']==3) {?>
    <link rel="stylesheet" href="<?php echo $url?>assest/css/theme_deep_sky.css"/>
   <?php } ?>
   <?php }} ?>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
</head>
<body>