 <section class="">
 	<nav class="navigation_bar" id="navbar">
 	  <div class="container-fluid">
	   <div class="row">
 	  	 <div class="logo col-lg-2 col-md-3 col-sm-3 col-xs-12">
		  <!-- togle_sub_cat_menu add -->
          <?php include"inc/menus/togle_sub_cat_menu.php"?>
          <!-- togle_sub_cat_menu add -->		  
		 </div>
 	  	 <div class="search_area col-lg-7 col-md-5 col-sm-3 col-xs-12">
 	  		<form action="search.php" method="GET">
 	  		  <input type="text" name="search" class="serach_box" placeholder="Search your product...">
 	  		  <button type="submit" class="search_btn btn btn-success">
			  <i class="fa fa-search"></i>
			  </button>
 	  	   </form>
 	  	 </div>
 	  	 <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
		   <!-- custom_menu add -->
		   <?php include"inc/menus/custom_menu.php"?> 
           <!-- custom_menu add -->		   
	     </div>
		 <!-- mobl_menu add -->
	     <?php include"inc/menus/mobl_menu.php"?>
		 <!-- mobl_menu add -->
	    </div>
	    </div>
	   </nav>
    </section>