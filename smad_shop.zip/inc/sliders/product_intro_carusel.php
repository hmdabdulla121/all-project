                <div class="row intro_slider owl-carousel">
				<?php 
			     $getallPro_typeBy_type1=$cat->getallPro_intro_slider_type1();
			     if(isset($getallPro_typeBy_type1)){ 
				   $result=$getallPro_typeBy_type1->fetch_assoc();
			    ?>
			       <div class="intro_item slide_pro">
						<a href="javascript:void(0)">
						 <figure>
							<img src="admin/<?= $result['slider_img1'];?>" class="proimg" alt="">
						 </figure>
						</a>
					</div>
					<div class="intro_item slide_pro">
						<a href="javscript:void(0)">
						 <figure>
							<img src="admin/<?= $result['slider_img2'];?>" class="proimg" alt="">
						 </figure>
						</a>
					</div>
					<div class="intro_item slide_pro">
						<a href="javscript:void(0)">
						 <figure>
							<img src="admin/<?= $result['slider_img3'];?>" class="proimg" alt="">
						 </figure>
						</a>
					</div>
					<?php }?>
			   </div>