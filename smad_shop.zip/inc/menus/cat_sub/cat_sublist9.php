            <div class="cat_sublist9" style="max-height:280px;">
			       <div class="cat_menubox">
				   <?php	
                        $type_count=$cat->getProcat_count_by_pro_type9();
					     if($type_count=10){?>
				    <div class="collumns four">
				      <ul> 
					   <li class="lnkHeading"></li>	 
					   <?php 
			            $getAllproCat=$cat->getProcat_type9_lm_0_10_by_catId();
			              if ($getAllproCat){
			                 while ($result=$getAllproCat->fetch_assoc()){   	
					   ?>
					    <a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
					   <?php }}?>					
					 </ul>
				   </div>
				   <?php }?>	
				   <?php	
                        $type_count=$cat->getProcat_count_by_pro_type9();
					     if($type_count>=10){?>
				   <div class="collumns four">
				     <ul> 
					 <li class="lnkHeading"></li>	 
					   <?php 
			            $getAllproCat=$cat->getProcat_type9_lm_10_20_by_catId();
			              if ($getAllproCat){
			                 while ($result=$getAllproCat->fetch_assoc()){    	
					   ?>
					    <a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
					  <?php }}?>					
					 </ul>
				   </div>
				   <?php }?>	
				   <?php	
                        $type_count=$cat->getProcat_count_by_pro_type9();
					     if($type_count>=20){?>
				   <div class="collumns four">
				     <ul> 
					 <li class="lnkHeading"></li>	 
					   <?php 
			            $getAllproCat=$cat->getProcat_type9_lm_20_30_by_catId();
			              if ($getAllproCat){
			                 while ($result=$getAllproCat->fetch_assoc()){   	
					   ?>
					    <a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
					  <?php }}?>					
					 </ul>
				   </div>
				   <?php }?>	
				   <?php	
                        $type_count=$cat->getProcat_count_by_pro_type9();
					     if($type_count>=30){?>
				   <div class="collumns four">
				     <ul> 
					 <li class="lnkHeading"></li>	 
					   <?php 
			            $getAllproCat=$cat->getProcat_type9_lm_30_40_by_catId();
			              if ($getAllproCat){
			                 while ($result=$getAllproCat->fetch_assoc()){    	
					   ?>
					    <a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
					  <?php }}?>					
					 </ul>
				   </div>
				   <?php }?>	
				 </div>
			   </div>