             <div class="togleShow ">
			   <a href="javascript:void(0)" class="togle_menu ">
			    <i class="fa fa-navicon" aria-hidden="true"></i>
			   </a>
			   <ul class="dropdown_menu dropdown_primay ">
			    <li class="menu-content">
				  <div class="left_part ">
				     <?php 
					  $getCat=$cat->getallPro_type();
					  if (isset($getCat)){
					  while($result=$getCat->fetch_assoc()) {
				     ?>
					  <div class="togle_menu_show" id="cat_<?= $result['pro_typeId']?>">
			            <a href="smado_cat.php?smado_type_shop=<?= base64_encode($result['pro_typeId'])?>"><?= $result['product_type'] ?>
			            <i class="fa fa-angle-right"></i>
			            </a>
					      <?php include"inc/menus/cat_sub/cat_sublist.php" ?>
						  <?php include"inc/menus/cat_sub/cat_sublist2.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist3.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist4.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist5.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist6.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist7.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist8.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist9.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist10.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist11.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist12.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist13.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist14.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist15.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist16.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist17.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist18.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist19.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist20.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist21.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist22.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist23.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist24.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist25.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist26.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist27.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist28.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist29.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist30.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist31.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist32.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist33.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist34.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist35.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist36.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist37.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist38.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist39.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist40.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist41.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist42.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist43.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist44.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist45.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist46.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist47.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist48.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist49.php"?>
						  <?php include"inc/menus/cat_sub/cat_sublist50.php"?>
						</div>
						<?php }}?>
		            </div>
			     </li>
			    </ul>
 	  		  <a href="index.php"><img class="ml-3" src="assest/img/logo.png" width="55" height="45" alt="logo"></a>
			  <span>All Categoey</span>
 	  	  </div>