             <div class="mobile_menu">
                <div class="menu_heding">
                <span onclick="openNav()">&#9776;</span>
                <a href="javasvript:void(0)" class="title">
                	Smadobd.com
                </a>
                <a href="login.php" class="user">
                  <i class="fa fa-user"></i>
                </a>
                <a href="cat.php" class="cart_mbl">
                	<i class="fa fa-shopping-cart"></i>
                	<span class="cart_qty_mbl">(0)</span>
                </a>
                <div class="overly" id="myNav">
                 <div class="search_area col-lg-12 col-md-12 col-sm-12 col-xs-12">
			 	   <form action="search.php" method="GET">
			 	  	<input type="text" name="search" class="serach_box" placeholder="Search your product...">
			 	     <button type="submit" class="search_btn btn btn-success"><i class="fa fa-search"></i></button>
			 	   </form>
			 	   </div>
                     <a href="javascript:void(0)" onclick="closeNav()" class="closenav">&times;</a>
                        <div class="overly_content">
						   <?php 
						    $getCat=$cat->getallPro_type();
						    if (isset($getCat)){
						    while($result=$getCat->fetch_assoc()){
						   ?>
						   <a href="javascript:void(0)" id="mbl_cat<?= $result['pro_typeId']?>" class="drop_open_prod"><?= $result['product_type'] ?></a>
                           <div class="sub_catM" id="show_mbl_cat<?= $result['pro_typeId']?>">
                            <?php 
			                $getAllproCat1=$cat->getProcat_type1_all_by_catId();
			                if ($getAllproCat1){
			                 while ($result=$getAllproCat1->fetch_assoc()){    	
					        ?>
							<a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
							<?php }}?>						   
                           <?php //include"inc/menus/mbl_menu/catlist_mbl1.php" ?>
                           <?php //include"inc/menus/mbl_menu/catlist_mbl2.php" ?>
                           <?php //include"inc/menus/mbl_menu/catlist_mbl3.php" ?>
						   </div>
						   <?php }}else{
						    $msg="<div class='alert alert-danger text-center'>
							       <p class='thank_msg'>No available data here to show in result!!</p>
							       <i class='fa fa-exclamation-triangle font35'></i
							     </div>";
						    echo $msg;
						   }?>
                    </div>
                 </div>
             </div>
	     </div>