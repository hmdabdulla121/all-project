                          
						  <div class="sub_catM" id="show_mbl_cat<?= $result['pro_typeId']?>">
						   <?php 
			                $getAllproCat2=$cat->getProcat_type2_all_by_catId();
			                if ($getAllproCat2){
			                 while ($result=$getAllproCat2->fetch_assoc()){    	
					       ?>
							<a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
							 <?php }}?>
						   </div>
						  