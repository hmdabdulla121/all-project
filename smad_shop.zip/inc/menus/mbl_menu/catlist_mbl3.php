                        
						   <?php 
			                $getAllproCat3=$cat->getProcat_type3_all_by_catId();
			                if ($getAllproCat3){
			                 while ($result=$getAllproCat3->fetch_assoc()){    	
					       ?>
							<a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
							 <?php }}?>
						  