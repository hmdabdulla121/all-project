
						  
						   <?php 
			                $getAllproCat1=$cat->getProcat_type1_all_by_catId();
			                if ($getAllproCat1){
			                 while ($result=$getAllproCat1->fetch_assoc()){    	
					       ?>
							<a href="pro_cat_listbyId.php?smado_cat_shop=<?= base64_encode($result['catproId'])?>"><?php echo $result['product'] ; ?></a>
							 <?php }}?>
						  
