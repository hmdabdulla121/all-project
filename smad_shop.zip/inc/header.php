 <section class="">
 	<nav class="navigation_bar" id="navbar">
 	  <div class="container-fluid">
	   <div class="row">
 	  	<div class="logo col-lg-2 col-md-2 col-sm-3 col-xs-12">
		  <div class="togleShow ">
			 <a href="" class="togle_menu ">
			  <i class="fa fa-navicon" aria-hidden="true"></i>
			 </a>
			 <ul class="dropdown_menu dropdown_primay ">
			   <li class="menu-content">
			   		<!--======== left_drop_menu========== start -->
				    <?php include"inc/menus/left_drop_menu.php" ?>
					<!--======== left_drop_menu========== start -->
			   </li>
			 </ul>
 	  		<img class="ml-3" src="assest/img/logo.png" width="55" height="45" alt="logo">
			<span>All Categoey</span>
 	  	</div>
		</div>
 	  	 <div class="search_area col-lg-7 col-md-6 col-sm-3 col-xs-12">
 	  		<form action="">
 	  		  <input type="text" name="search" class="serach_box" placeholder="Search your product...">
 	  		  <button class="search_btn btn btn-success"><i class="fa fa-search"></i></button>
 	  	   </form>
 	  	 </div>
 	  	 <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
 	  	    <!--======== custom_menu========== start -->
		    <?php include"custom_menu.php" ?>
		   	<!--======== custom_menu========== start -->
	     </div>
	     	<!--======== left_drop_menu========== start -->
	        <?php include"inc/menus/left_drop_menu.php" ?>
	      	<!--======== left_drop_menu========== start -->
	    </div>
	   </nav>
    </section>