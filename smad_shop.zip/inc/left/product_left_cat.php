          <div class="left_part">
			   <div class="offer_zone_title">
			     DISCOVER MEN'S FASHION
			   </div>
			   <?php 
			     $getProduct_catBy_type1=$cat->getProduct_catBy_type1();
			     if(isset($getProduct_catBy_type1)){ 
				 while ($result=$getProduct_catBy_type1->fetch_assoc()){
			    ?>
			    <div class="left_menu">
			    <a href="smado_cat.php?smado_type_shop=<?= base64_encode($result['pro_typeId'])?>">
				  <?php echo $result['product'] ; ?>
			     <i class="fa fa-angle-right"></i>
			   </a>
			  </div>
			  <?php }}?>
			  <a href="product_bytype.php">G0 to see all</a>
		 </div>