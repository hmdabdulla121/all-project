-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2020 at 11:37 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smad_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminUser` varchar(30) NOT NULL,
  `adminEmail` varchar(30) NOT NULL,
  `adminPass` varchar(32) NOT NULL,
  `user_role` tinyint(4) NOT NULL,
  `country` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `adrs` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminUser`, `adminEmail`, `adminPass`, `user_role`, `country`, `city`, `phone`, `adrs`, `status`, `add_date`) VALUES
(16, 'Al Mamun', 'almamun@gmail.com', 'YWxtYW11bjEyMzQ=', 1, 'Bangladesh', 'Natore', '01780500809', '                                                  ', 0, '2020-03-09 00:26:08'),
(18, 'Aurora_k', 'aurora@gmail.com', 'YXVyb3JhMTIzNA==', 1, 'Bangladesh', 'Natore', '01780500809', '				rajapur                ', 0, '2020-03-09 00:52:29'),
(19, 'Rabbi', 'rabbi@gmail.com', 'cmFiYmkxMjM0', 1, 'Bangladesh', 'Natore', '01780500809', 'Muladuli pabna', 0, '2020-03-09 09:45:31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(30) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`, `add_date`) VALUES
(9, 'BATA', '2020-01-01 18:00:00'),
(11, 'ARMANY', '2019-07-27 11:27:42'),
(12, 'KNIKE', '2019-07-31 19:50:07'),
(13, 'LOTTO', '2019-11-05 16:34:49'),
(15, 'APPEX', '2019-11-05 16:34:55'),
(16, 'POLO', '2020-01-01 18:00:00'),
(17, 'KNIKE', '2020-01-01 15:53:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `sId` int(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `pro_size` varchar(255) NOT NULL,
  `color` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartId`, `sId`, `productId`, `p_name`, `price`, `quantity`, `pro_size`, `color`, `image`) VALUES
(5, 17, 26, 'New Product from Panda', 1000.00, 1, 'l-size', 'black', 'Uploads/289949c6c5.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `Category`, `add_date`, `status`) VALUES
(1, 'MAN', '2020-02-02 23:22:40', 0),
(2, 'WOMEN', '2020-02-02 23:22:52', 0),
(3, 'BABY &amp; KIDS', '2020-02-02 23:23:16', 0),
(4, 'BIKING &amp; RIDING', '2020-02-02 23:23:42', 0),
(5, 'MOBILE', '2020-02-02 23:23:52', 0),
(6, 'ELECTRONICS', '2020-02-02 23:24:03', 0),
(7, 'HOME &amp; LIVING', '2020-02-02 23:24:28', 0),
(8, 'BOOK &amp; STATIONARY', '2020-02-02 23:24:56', 0),
(9, 'FOOD &amp; GROCERY', '2020-02-02 23:25:10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_compare`
--

CREATE TABLE `tbl_compare` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(30) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_compare`
--

INSERT INTO `tbl_compare` (`id`, `cmrId`, `productId`, `productName`, `price`, `image`) VALUES
(1, 4, 38, 'Pulsure150cc', 300.00, 'Uploads/060b2d39b6.jpg'),
(2, 4, 40, 'new prado car', 2000.00, 'Uploads/6a64efbc72.jpg'),
(3, 4, 39, 'suzuki Ziggar', 200.00, 'Uploads/c87b3005b2.jpg'),
(4, 5, 43, 'new prado car', 200.00, 'Uploads/9c36e9710d.jpg'),
(5, 4, 45, 'kawaski', 200.00, 'Uploads/6d931707af.png'),
(6, 5, 46, 'Latest colorfull car ', 200.00, 'Uploads/7cb42e1a7b.jpg'),
(7, 5, 42, 'suzuki Ziggar', 200.00, 'Uploads/9d3eda29ec.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `cstmId` int(11) NOT NULL,
  `cfname` varchar(11) NOT NULL,
  `clname` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Subject` varchar(40) NOT NULL,
  `msg` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `save_sts` tinyint(4) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`cstmId`, `cfname`, `clname`, `email`, `Subject`, `msg`, `status`, `save_sts`, `date`) VALUES
(16, 'arif', 'arif', 'arfan@gmail.com', 'We can\'t buy Product right now', 'We can\'t buy Product right now', 0, 1, '2020-01-31 18:07:22'),
(17, 'arif', 'arif', 'arfan@gmail.com', 'We can\'t buy Product right now', 'We can\'t buy Product right now', 0, 1, '2020-01-31 18:09:33'),
(18, 'arif', 'arif', 'arfan@gmail.com', 'We can\'t buy Product right now', 'dfvdrfdefced', 0, 0, '2020-01-31 18:09:46');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_curtorder`
--

CREATE TABLE `tbl_curtorder` (
  `orderId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `p_name` varchar(60) NOT NULL,
  `invoice_no` varchar(60) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` varchar(60) NOT NULL,
  `pro_size` varchar(100) NOT NULL,
  `price` float(10,2) NOT NULL,
  `ship_method` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `orer_status` tinyint(4) NOT NULL DEFAULT '0',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_curtorder`
--

INSERT INTO `tbl_curtorder` (`orderId`, `cmrId`, `p_name`, `invoice_no`, `productId`, `quantity`, `pro_size`, `price`, `ship_method`, `image`, `orer_status`, `order_date`) VALUES
(3, 17, 'BLACK SHOE Appex', '1795757364', 8, '1', 'l-size', 1000.00, '100', 'Uploads/97f3861266.jpg', 0, '2020-04-14 07:25:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `cstmrId` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pro_pic` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(40) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `customer_ip` varchar(100) NOT NULL,
  `day` varchar(31) NOT NULL,
  `month` varchar(60) NOT NULL,
  `year` varchar(255) NOT NULL,
  `signUpdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `verified` tinyint(5) NOT NULL DEFAULT '0',
  `vkey` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`cstmrId`, `name`, `email`, `pro_pic`, `city`, `country`, `address`, `phone`, `password`, `customer_ip`, `day`, `month`, `year`, `signUpdate`, `status`, `verified`, `vkey`) VALUES
(17, 'Arfan arif', 'arfan@gmail.com', 'Uploads/2811d6eeaa.png', 'Natore', 'Bangladesh', '                  Rajapur natore.                ', '01780500809', '7a606bfb920a093671e1104b5aeb7449', '::1', '', '', '', '2020-03-07 00:00:00', 0, 0, ''),
(18, 'simul', 'simul@gmail.com', 'Uploads/2b3076bcfd.jpg', 'Dhaka', 'Bangladesh', 'Dhanmundi-1200', '01780500809', '6257d926a63798c82184bb5541a5fdfa', '::1', '', '', '', '2020-03-17 15:07:50', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dlchrge`
--

CREATE TABLE `tbl_dlchrge` (
  `dlchrgId` int(11) NOT NULL,
  `dchrgname` varchar(40) NOT NULL,
  `dchamnt` varchar(60) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_dlchrge`
--

INSERT INTO `tbl_dlchrge` (`dlchrgId`, `dchrgname`, `dchamnt`, `add_date`, `status`) VALUES
(1, 'Next day delivery', '150', '2020-01-09 10:35:22', 0),
(4, 'Personal Pickup', 'Free', '2020-01-09 15:58:38', 0),
(5, 'Standard delivery', '100', '2020-01-15 09:59:42', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_font_theme`
--

CREATE TABLE `tbl_font_theme` (
  `thm_id` int(11) NOT NULL DEFAULT '1',
  `theme` varchar(30) NOT NULL,
  `theme_ttl` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_font_theme`
--

INSERT INTO `tbl_font_theme` (`thm_id`, `theme`, `theme_ttl`, `status`, `add_date`) VALUES
(1, '1', '', 0, '2020-03-10 16:37:30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_header_slider`
--

CREATE TABLE `tbl_header_slider` (
  `hdslId` int(11) NOT NULL,
  `slider_ttl` varchar(50) NOT NULL,
  `pro_typeId` varchar(50) NOT NULL,
  `slider_img` varchar(255) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_header_slider`
--

INSERT INTO `tbl_header_slider` (`hdslId`, `slider_ttl`, `pro_typeId`, `slider_img`, `add_date`, `status`) VALUES
(2, 'Choose the best And get the best Praesenting an ex', '1', 'Uploads/8d4d1a0e0b.png', '2020-06-01 00:00:00', 0),
(3, 'Choose the best And get the best Praesenting an ex', '1', 'Uploads/64f75c29c0.jpg', '2020-06-01 00:00:00', 0),
(4, 'Choose the best And get the best Praesenting an ex', '2', 'Uploads/797a305d78.jpg', '2020-06-01 00:00:00', 0),
(5, 'We are the Largest E-Shopper BD Get More and Save ', '1', 'Uploads/3a856fe8e6.jpg', '2020-06-01 03:56:06', 0),
(6, 'We are the Largest E-Shopper BD Get More and Save ', '1', 'Uploads/dd8bbabedf.jpg', '2020-06-01 03:57:01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `orderId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `User_Id` int(11) NOT NULL DEFAULT '0',
  `ordr_accept` varchar(50) NOT NULL,
  `user_role` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `pro_size` varchar(60) NOT NULL,
  `total` float(10,2) NOT NULL,
  `price` float(10,2) NOT NULL,
  `ship_method` float(10,2) NOT NULL,
  `invoice_no` varchar(60) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `country` varchar(40) NOT NULL,
  `addrs` text NOT NULL,
  `zip` varchar(32) NOT NULL,
  `city` varchar(30) NOT NULL,
  `post` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `p_method` varchar(50) NOT NULL,
  `bk_num` int(12) NOT NULL,
  `bk_txrId` varchar(18) NOT NULL,
  `rk_num` int(12) NOT NULL,
  `rk_txrId` varchar(18) NOT NULL,
  `image` varchar(255) NOT NULL,
  `day` varchar(31) NOT NULL,
  `month` varchar(60) NOT NULL,
  `year` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pm_act_dt` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`orderId`, `cmrId`, `productId`, `User_Id`, `ordr_accept`, `user_role`, `p_name`, `quantity`, `pro_size`, `total`, `price`, `ship_method`, `invoice_no`, `fname`, `lname`, `country`, `addrs`, `zip`, `city`, `post`, `phone`, `p_method`, `bk_num`, `bk_txrId`, `rk_num`, `rk_txrId`, `image`, `day`, `month`, `year`, `date`, `pm_act_dt`, `status`) VALUES
(16, 18, 3, 18, 'Aurora_k', 1, 'BLACK SHOE', 1, 'l-size', 2100.00, 2000.00, 100.00, '1013270125', 'arfan', 'arif', 'BANGLADESH', '343', 'er4r', 'Natore', 'r324', '01780500809', '1', 1780500809, '28926962w', 0, '', 'Uploads/b03999b48d.jpg', '', '', '', '2020-03-17 16:08:06', '2020-04-21 23:03:35', 1),
(17, 17, 22, 18, 'Aurora_k', 1, 'New Plazo for young lady', 1, 'l-size', 800.00, 700.00, 100.00, '1956521123', 'arfan', 'arif', 'BANGLADESH', 'Rajapur,Natore.', '6623', 'Natore', '6623', '01780500809', '1', 1780500809, '0986rbk354220021', 0, '', 'Uploads/a3aebdea53.jpg', '', '', '', '2020-03-31 17:05:36', '2020-03-31 17:15:03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `p_name` varchar(40) NOT NULL,
  `total` float(10,0) NOT NULL,
  `price` float(10,0) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `ship_method` varchar(40) NOT NULL,
  `invoice_no` varchar(80) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `country` varchar(30) NOT NULL,
  `addrs` text NOT NULL,
  `zip` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `post` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `p_method` varchar(60) NOT NULL,
  `bk_num` varchar(15) NOT NULL,
  `bk_txrId` varchar(50) NOT NULL,
  `rk_num` varchar(15) NOT NULL,
  `rk_txrId` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `day` varchar(31) NOT NULL,
  `month` varchar(60) NOT NULL,
  `year` varchar(255) NOT NULL,
  `user_role` varchar(30) NOT NULL,
  `pm_refBy` varchar(30) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `pay_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pm_act_dt` varchar(255) NOT NULL,
  `ref_dt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payId`, `cmrId`, `name`, `email`, `productId`, `p_name`, `total`, `price`, `quantity`, `ship_method`, `invoice_no`, `fname`, `lname`, `country`, `addrs`, `zip`, `city`, `post`, `phone`, `p_method`, `bk_num`, `bk_txrId`, `rk_num`, `rk_txrId`, `image`, `day`, `month`, `year`, `user_role`, `pm_refBy`, `status`, `pay_dt`, `pm_act_dt`, `ref_dt`) VALUES
(1, 16, 'simul', 'simul@gmail.com', 16, 'New gents coats', 2300, 2200, '1', '100', '1717975556', 'Kajol', 'Ahmed', 'BANGLADESH', 'Khulna,Dhaka', '5566', 'Dhaka', '3344', '01780500809', '1', '01780500809', '11223344567890', '', '', 'Uploads/b46b9682a8.jpg', '', '', '2020', '1', 'Aurora_k', 0, '2020-03-05 11:45:34', '2020-03-10 14:53:05', '2020-05-10 15:09:18'),
(2, 18, 'Rabbi', 'rabbi@gmail.com', 9, 'BLACK Bags', 2100, 2000, '2', '100', '632436591', 'rabbi', 'islam', 'BANGLADESH', 'mulduli', '33444', 'Natore', '4455', '01780500809', '1', '018099887788', 'ffgfrferfrf', '', '', 'Uploads/1c6cf0f434.jpg', '', '', '2020', '1', 'Al Mamun', 0, '2020-03-09 11:24:22', '2020-03-10 14:46:20', '2020-03-11 16:04:06'),
(3, 18, 'Rabbi', 'rabbi@gmail.com', 16, 'New gents coats', 2300, 2200, '1', '100', '1625133919', 'Rabbi', 'Ahoshan', 'BANGLADESH', 'Muladuli Ishurdi Pabna.', '8899', 'Dhaka', '9900', '01987113836', '2', '', '', '01987113836', '763662378', 'Uploads/b46b9682a8.jpg', '', '', '2019', '1', 'Aurora_k', 0, '2020-03-10 01:00:27', '2020-03-10 14:54:16', '2020-03-10 14:54:16'),
(4, 17, '', '', 17, 'New gents coats', 1150, 1000, '1', '150', '1002744496', 'arfan', 'arif', 'BANGLADESH', 'rajapur natore', '5566', 'Natore', '7788', '01780500809', '1', '01780500809', '01484984974', '', '', 'Uploads/292c5b5c14.jpg', '', '', '2018', '', '', 0, '2020-03-11 22:43:42', '', ''),
(5, 17, '', '', 25, 'New Product from Panda', 800, 700, '1', '100', '1040526286', 'arfan', 'arif', 'BANGLADESH', 'rajapur', '9900', 'Natore', '7788', '01780500809', '2', '', '', '01780500809', '01088775', 'Uploads/47dfc6b82c.png', '', '', '2017', '', '', 0, '2020-03-11 23:39:26', '', ''),
(6, 17, '', '', 15, 'New gents coats', 2300, 2200, '1', '100', '476393301', 'arfan', 'arif', 'BANGLADESH', 'Rajapur', '5566', 'Dhaka', '8899', '01780500809', '1', '01780500809', '3974983648364', '', '', 'Uploads/e691c6e15e.jpg', '', '', '2019', '', '', 0, '2020-03-11 23:49:56', '', ''),
(7, 18, '', '', 23, 'New watch from casio', 650, 500, '1', '150', '88352119', 'simul', 'khan', 'BANGLADESH', 'Dhaka', '3344', 'Dhaka', '5566', '01780500809', '1', '01780500809', '292364753854', '', '', 'Uploads/973a0100a7.jpg', '', '', '2018', '', '', 0, '2020-03-17 15:41:34', '', ''),
(8, 18, '', '', 3, 'BLACK SHOE', 2100, 2000, '1', '100', '1013270125', 'arfan', 'arif', 'BANGLADESH', '343', 'er4r', 'Natore', 'r324', '01780500809', '1', '01780500809', '28926962w', '', '', 'Uploads/b03999b48d.jpg', '', '', '2017', '', '', 0, '2020-03-17 16:08:06', '', ''),
(9, 17, '', '', 22, 'New Plazo for young lady', 800, 700, '1', '100', '1956521123', 'arfan', 'arif', 'BANGLADESH', 'Rajapur,Natore.', '6623', 'Natore', '6623', '01780500809', '1', '01780500809', '0986rbk354220021', '', '', 'Uploads/a3aebdea53.jpg', '', '', '2020', '', '', 0, '2020-03-31 17:05:36', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pend_order`
--

CREATE TABLE `tbl_pend_order` (
  `orderId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `quantity` int(255) NOT NULL,
  `pro_size` varchar(30) NOT NULL,
  `total` float(10,2) NOT NULL,
  `price` float(10,2) NOT NULL,
  `ship_method` float(10,2) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `addrs` text NOT NULL,
  `zip` varchar(20) NOT NULL,
  `city` varchar(30) NOT NULL,
  `post` varchar(20) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `p_method` varchar(30) NOT NULL,
  `bk_num` int(12) NOT NULL,
  `bk_txrId` varchar(18) NOT NULL,
  `rk_num` int(12) NOT NULL,
  `rk_txrId` varchar(18) NOT NULL,
  `image` varchar(255) NOT NULL,
  `day` varchar(31) NOT NULL,
  `month` varchar(60) NOT NULL,
  `year` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `catproId` int(11) NOT NULL,
  `body` text NOT NULL,
  `price` float(10,2) NOT NULL,
  `pro_imageL` varchar(255) NOT NULL,
  `pro_imageM` varchar(255) NOT NULL,
  `pro_imageS` varchar(255) NOT NULL,
  `prd_type` tinyint(4) NOT NULL,
  `pbl_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(255) NOT NULL DEFAULT '0',
  `pro_delikey` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `p_name`, `catId`, `brandId`, `catproId`, `body`, `price`, `pro_imageL`, `pro_imageM`, `pro_imageS`, `prd_type`, `pbl_dt`, `status`, `pro_delikey`) VALUES
(2, 'BLACK SHOE Appex', 5, 15, 3, '                     This is nice shoes                     ', 400.00, 'Uploads/e32b115238.jpg', 'Uploads/e32b1152387.jpg', 'Uploads/e32b1152387b.jpg', 1, '2020-05-31 18:00:00', 0, 'cc6af3e3214a6d87ede11e15c6088ef3'),
(3, 'BLACK SHOE', 9, 17, 3, '                     This Latest kids shoes                     ', 2000.00, 'Uploads/fed06cbb50.jpg', 'Uploads/fed06cbb50d.jpg', 'Uploads/fed06cbb50d0.jpg', 1, '2020-05-31 18:00:00', 0, '18759b874c0c219dd8360774fe10fce8'),
(4, 'New Baby bag from Polo', 4, 16, 14, '                     New Baby bag from Polo                     ', 500.00, 'Uploads/8fa582d940.jpg', 'Uploads/8fa582d9400.jpg', 'Uploads/8fa582d9400f.jpg', 2, '2020-06-01 18:00:00', 0, '0ec51b39fbd36ea8b8164be1b3506840'),
(5, 'New Baby bag ', 2, 12, 14, '                                                                                    New Baby bag                                                                                     ', 750.00, 'Uploads/b26472f0fd.jpg', 'Uploads/b26472f0fd0.jpg', 'Uploads/b26472f0fd05.jpg', 5, '2020-05-31 18:00:00', 0, '4e0d0424645188f942cb88a76a8b4c9a'),
(7, 'BLACK SHOE Appex', 2, 9, 3, '                     BLACK SHOE Appex                     ', 1000.00, 'Uploads/d7744a3acb.jpg', 'Uploads/d7744a3acb3.jpg', 'Uploads/d7744a3acb35.jpg', 2, '2020-05-31 18:00:00', 0, 'e2618960b9bf97ac1c096ec4540d6940'),
(8, 'BLACK SHOE Appex', 1, 9, 3, '                     BLACK SHOE Appex                     ', 1000.00, 'Uploads/551a6b027d.jpg', 'Uploads/551a6b027d7.jpg', 'Uploads/551a6b027d77.jpg', 2, '2020-06-01 18:00:00', 0, '05d02f5366953c70acd28c84f0959f98'),
(11, 'BLACK SHOE Appex', 4, 15, 3, '                     BLACK SHOE AppexBLACK SHOE AppexBLACK SHOE AppexBLACK SHOE Appex                     ', 1000.00, 'Uploads/71f3994604.jpg', 'Uploads/71f39946048.jpg', 'Uploads/71f39946048c.jpg', 1, '2020-05-31 18:00:00', 0, 'e6f303659b963096094b73c03104718f'),
(12, 'New Baby Shoes', 9, 12, 13, '                     New Baby ShoesNew Baby ShoesNew Baby ShoesNew Baby ShoesNew Baby Shoes                     ', 900.00, 'Uploads/b1b0329f0f.jpg', 'Uploads/b1b0329f0fb.jpg', 'Uploads/b1b0329f0fb0.jpg', 2, '2020-05-31 18:00:00', 0, 'fd565b586923e396a1e1f754b5be8524'),
(14, 'BLACK SHOE', 10, 9, 3, 'BLACK SHOEBLACK SHOEBLACK SHOEBLACK SHOEBLACK SHOEBLACK SHOE', 1000.00, 'Uploads/f1feab4176.jpg', 'Uploads/f1feab4176f.jpg', 'Uploads/f1feab4176fc.jpg', 1, '2020-01-09 18:00:00', 0, 'c618773a8c75d3e1227bd9a2c6a2b091'),
(22, 'New Plazo for young lady', 2, 11, 5, '                                          New Plazo for young lady                                          ', 700.00, 'Uploads/b68e281505.jpg', 'Uploads/b68e2815053.jpg', 'Uploads/b68e2815053a.jpg', 2, '2020-05-31 18:00:00', 0, '7929a3ac52aad8f21d3d89cb7136cc33'),
(27, 'New Lehenga', 2, 11, 30, 'New black and red or blue lehenga from india 2020.Thsi the latest Collection this year.', 1050.00, 'Uploads/dc42eaa6c3.jpg', 'Uploads/dc42eaa6c3e.jpg', 'Uploads/dc42eaa6c3e6.jpg', 2, '2020-06-01 18:00:00', 0, 'a50ea42e29270ff8e538738bd83f79be'),
(28, 'New Rose color Lehenga', 2, 11, 30, 'This is latset summer collection for sweet ladies.This gorgius lahenga for your weeding function and got bueaty on your body and prasticse.', 2050.00, 'Uploads/839cd6ee24.jpg', 'Uploads/839cd6ee241.jpg', 'Uploads/839cd6ee241a.jpg', 2, '2020-06-01 18:00:00', 0, 'dcca7e3233acd2b3ccf57cfd6a39c29c'),
(29, 'New latest side bag for ladies', 2, 16, 31, 'This is new collection for bag.This is unique and hot collection for yung and all ages ladies.', 750.00, 'Uploads/5ca9ac22c8.jpg', 'Uploads/5ca9ac22c88.jpg', 'Uploads/5ca9ac22c889.jpg', 2, '2020-05-31 18:00:00', 0, '68d435ea0a252b9bdea2a4cc0d6fcff4'),
(30, 'New T-shir for man', 1, 13, 21, 'This new t-shirt for man', 1250.00, 'Uploads/7aac8adffd.jpg', 'Uploads/7aac8adffd5.jpg', 'Uploads/7aac8adffd5e.jpg', 1, '2020-05-31 18:00:00', 0, '23f3d527503bd61161f31e889ee50a94'),
(31, 'Latest Ladies bag Offer', 2, 12, 31, 'This is new and stylish bag for women offer 2020.', 601.00, 'Uploads/4db71fe16b.jpg', 'Uploads/4db71fe16b5.png', 'Uploads/4db71fe16b5f.jpg', 9, '2020-06-04 18:00:00', 0, '6df37e6d270beb8cf64843833ff28543'),
(32, 'New shirt for man and offered', 1, 16, 18, 'Newt shirt for man and offer limited 2020', 700.00, 'Uploads/a49a2fe737.jpg', 'Uploads/a49a2fe7375.jpg', 'Uploads/a49a2fe7375b.jpg', 9, '2020-06-04 18:00:00', 0, '4ce0d2258c4e8d39f30df3d14d7624bd'),
(33, 'New t-shir for man and offered', 1, 11, 18, 'New t-shir for man and offer limited 2020', 1500.00, 'Uploads/8c67205ce8.jpg', 'Uploads/8c67205ce80.jpg', 'Uploads/8c67205ce801.jpg', 9, '2020-06-05 18:00:00', 0, 'e6d66127f115adf17708120c3fd74ea5'),
(34, 'New t-shir for man and offer l', 1, 12, 21, 'New t-shir for man and offer limited 2020', 1800.00, 'Uploads/4171bec9bc.jpg', 'Uploads/4171bec9bc0.jpg', 'Uploads/4171bec9bc0a.jpg', 9, '2020-06-11 18:00:00', 0, 'cbeb31323e11f3b8818e706543a59b72'),
(35, 'New shirt for man and offered', 1, 17, 18, 'New t-shir for man and offer limited 2020', 3000.00, 'Uploads/29138004bd.jpg', 'Uploads/29138004bd4.jpg', 'Uploads/29138004bd42.jpg', 1, '2020-06-04 18:00:00', 0, '81ddf0fbae86caee447d051febd0c250'),
(36, 'New t-shir for man and offer l', 1, 13, 18, 'New t-shir for man and offer limited 2020', 1500.00, 'Uploads/916fe71d9c.jpg', 'Uploads/916fe71d9cc.jpg', 'Uploads/916fe71d9ccd.jpg', 1, '2020-06-04 18:00:00', 0, '77e3bd90dbd173cbaaa1cbb62fe9a076'),
(37, 'New t-shir for man and offerli', 1, 17, 18, 'New t-shir for man and offer limited 2020', 1000.00, 'Uploads/545ed3452c.jpg', 'Uploads/545ed3452cb.jpg', 'Uploads/545ed3452cbd.jpg', 1, '2020-06-04 18:00:00', 0, 'c8b18839ae485e35d4c9dfbfb2023e74');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pro_category`
--

CREATE TABLE `tbl_pro_category` (
  `catproId` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `pro_typeId` int(60) NOT NULL,
  `catId` varchar(40) NOT NULL,
  `procatAdd_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pro_category`
--

INSERT INTO `tbl_pro_category` (`catproId`, `product`, `pro_typeId`, `catId`, `procatAdd_dt`, `status`) VALUES
(1, 'MAN', 1, '4', '2020-02-22 00:00:00', 0),
(2, 'WOMEN', 2, '1', '2020-02-01 14:56:37', 0),
(3, 'BIKING & RIDING', 4, '2', '2020-02-01 14:56:43', 0),
(4, 'ELECTRONICS', 5, '4', '2020-02-01 14:56:57', 0),
(5, 'HOME & LIVING', 6, '5', '2020-02-01 14:57:25', 0),
(6, 'BOOK & STATIONARY', 7, '6', '2020-02-01 14:57:32', 0),
(7, 'FOOD & GROCERY', 8, '6', '2020-02-01 14:57:40', 0),
(8, 'New Yar carnival', 9, '7', '2020-02-02 00:00:00', 0),
(9, 'MOBILE', 10, '8', '2020-02-01 14:58:03', 0),
(10, 'BAYBY & KIDS', 3, '9', '2020-02-01 15:14:15', 0),
(11, 'JACKETS', 1, '3', '2020-02-01 15:25:22', 0),
(12, 'SHOES', 11, '3', '2020-02-14 00:00:00', 0),
(13, 'COATS', 11, '2', '2020-02-15 00:00:00', 0),
(14, 'T-SHIRT', 11, '3', '2020-02-06 00:00:00', 0),
(15, 'PANT', 1, '7', '2020-02-14 00:00:00', 0),
(16, 'PANJABI', 1, '8', '2020-02-02 00:00:00', 0),
(17, 'COATS', 1, '1', '2020-02-03 21:39:00', 0),
(18, 'T-SHIRT', 1, '1', '2020-02-03 21:39:30', 0),
(19, 'SHOES', 1, '1', '2020-02-03 21:39:44', 0),
(20, 'COATS', 2, '2', '2020-02-03 21:41:07', 0),
(21, 'T-SHIRT', 2, '2', '2020-02-03 21:41:14', 0),
(22, 'SHOES', 2, '2', '2020-02-03 21:41:23', 0),
(23, 'PANJABI', 1, '1', '2020-02-03 21:41:56', 0),
(24, 'PANT', 1, '1', '2020-02-03 21:42:39', 0),
(25, 'NOKIA', 10, '5', '2020-02-03 21:49:52', 0),
(26, 'NOKIA', 10, '5', '2020-02-27 23:12:40', 0),
(27, 'CAPT', 1, '1', '2020-02-28 01:46:09', 0),
(28, 'WATCH', 1, '1', '2020-02-28 01:46:30', 0),
(29, 'GLASSES', 1, '1', '2020-02-28 01:54:51', 0),
(30, 'Lehenga', 2, '2', '2020-06-01 04:38:52', 0),
(31, 'Bag', 2, '2', '2020-06-01 04:45:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pro_intro_slider`
--

CREATE TABLE `tbl_pro_intro_slider` (
  `intro_slId` int(11) NOT NULL,
  `slider_ttl` varchar(30) NOT NULL,
  `pro_typeId` varchar(50) NOT NULL,
  `slider_img1` varchar(255) NOT NULL,
  `slider_img2` varchar(255) NOT NULL,
  `slider_img3` varchar(255) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pro_intro_slider`
--

INSERT INTO `tbl_pro_intro_slider` (`intro_slId`, `slider_ttl`, `pro_typeId`, `slider_img1`, `slider_img2`, `slider_img3`, `add_date`, `status`) VALUES
(2, 'We are the Largest E-Shopper B', '1', 'Uploads/4f6a172bab.jpg', 'Uploads/4f6a172babd.jpg', 'Uploads/4f6a172babd0.jpg', '2020-06-01 00:00:00', 0),
(3, 'We are the Largest E-Shopper B', '2', 'Uploads/54e52b3159.png', 'Uploads/54e52b3159a.png', 'Uploads/54e52b3159a7.png', '2020-06-01 00:00:00', 0),
(4, 'We are the Largest E-Shopper B', '3', 'Uploads/d6b04ccd67.jpg', 'Uploads/d6b04ccd678.jpg', 'Uploads/d6b04ccd678e.jpg', '2020-02-05 00:00:00', 0),
(5, 'We are the Largest E-Shopper B', '7', 'Uploads/1cf31acbf0.jpg', 'Uploads/1cf31acbf02.jpg', 'Uploads/1cf31acbf025.jpg', '2020-06-01 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pro_type`
--

CREATE TABLE `tbl_pro_type` (
  `pro_typeId` int(11) NOT NULL,
  `product_type` varchar(30) NOT NULL,
  `product_type_tle` varchar(50) NOT NULL,
  `product_section_tle` text NOT NULL,
  `pro_bannerImg` varchar(255) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pro_type`
--

INSERT INTO `tbl_pro_type` (`pro_typeId`, `product_type`, `product_type_tle`, `product_section_tle`, `pro_bannerImg`, `add_date`, `status`) VALUES
(1, 'MAN', 'DISCOVER MEN\'S FASHION', 'IT\'S TIME TO MAN\'Z WORLD										  										  										  										  										  ', 'Uploads/0ddc3dfc98.jpg', '2020-06-01 00:00:00', 0),
(2, 'WOMEN', 'EXPLORE WOMEN\'S FASHION', 'IT\'S TIME TO WOMEN\'S WORLD										  										  										  										  ', 'Uploads/dd3d4bf851.jpg', '2020-06-01 00:00:00', 0),
(3, 'BABY & KIDS', ' BAYBY & KIDS', 'GOLAS OF BAYBY & KIDS', 'Uploads/675ea52241.jpg', '2020-02-01 14:45:14', 0),
(4, 'BIKING & RIDING', 'BIKING & RIDING ', 'BIKING & RIDING  ERA										  ', 'Uploads/70b93580ed.jpg', '2020-02-22 00:00:00', 0),
(5, 'ELECTRONICS', 'ELECTRONICE ERA EXPLORATION', 'ELECTRONICE ERA EXPLORATION', 'Uploads/781d947355.jpg', '2020-02-28 00:00:00', 0),
(6, 'HOME & LIVING', 'HOME & LIVING', 'HOME & LIVING', 'Uploads/22af01eb94.jpg', '2020-02-01 14:48:28', 0),
(7, 'BOOK & STATIONARY', 'BOOK & STATIONARY', 'BOOK & STATIONARY ERA										  ', 'Uploads/636a565bd9.png', '2020-06-01 00:00:00', 0),
(8, 'FOOD & GROCERY', 'FOOD & GROCERY', 'FOOD & GROCERY										  ', 'Uploads/3849f15be3.jpg', '2020-02-22 00:00:00', 0),
(9, 'OFFER', 'OFFER ZONE', 'OFFER ZONE ERA', 'Uploads/ad81e1ca11.jpg', '2020-02-02 00:00:00', 0),
(10, 'MOBILE', 'INVENT YOUR MOBILE ', 'INVENT YOUR MOBILE ERA', 'Uploads/52f490c180.jpg', '2020-02-02 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reply`
--

CREATE TABLE `tbl_reply` (
  `repId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `to_email` varchar(40) NOT NULL,
  `from_email` varchar(40) NOT NULL,
  `msg` text NOT NULL,
  `rep_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reply`
--

INSERT INTO `tbl_reply` (`repId`, `cmrId`, `name`, `to_email`, `from_email`, `msg`, `rep_date`) VALUES
(5, 18, 'arif arif', 'arfan@gmail.com', 'aurora@gmail.com', 'hi', '2020-03-08 13:59:51'),
(6, 18, 'arif arif', 'arfan@gmail.com', 'aurora@gmail.com', 'hi', '2020-03-08 14:00:21'),
(7, 18, 'arif arif', 'arfan@gmail.com', 'aurora@gmail.com', 'hello', '2020-03-08 17:39:45'),
(10, 16, 'arif arif', 'arfan@gmail.com', 'almamun@gmail.com', 'hi', '2020-03-08 22:05:27'),
(11, 18, 'arif arif', 'arfan@gmail.com', 'aurora@gmail.com', 'hi', '2020-03-19 17:13:15'),
(12, 18, 'arif arif', 'arfan@gmail.com', 'aurora@gmail.com', 'hello', '2020-05-08 15:46:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `sldId` int(11) NOT NULL,
  `slideImage` varchar(255) NOT NULL,
  `slide_text` text NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`sldId`, `slideImage`, `slide_text`, `add_date`) VALUES
(7, 'Uploads/e8b793db0e.png', 'Slider Image-10', '2019-11-06 08:57:27'),
(9, 'Uploads/8b4548f4b9.jpg', 'Slider Image-13', '2019-11-06 09:08:10'),
(12, 'Uploads/af9c990691.jpg', 'Slider Image-16', '2019-11-06 17:52:58'),
(13, 'Uploads/7994e0d214.jpg', 'Slider Image-5', '2019-11-06 17:57:46'),
(14, 'Uploads/0ae8933b21.png', 'Slider Image-5', '2019-11-06 18:25:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_themes`
--

CREATE TABLE `tbl_themes` (
  `themeId` int(11) NOT NULL DEFAULT '1',
  `theme` varchar(50) NOT NULL,
  `theme_ttl` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_themes`
--

INSERT INTO `tbl_themes` (`themeId`, `theme`, `theme_ttl`, `status`, `date`) VALUES
(1, '1', '', 0, '2020-03-04 00:25:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vat`
--

CREATE TABLE `tbl_vat` (
  `vatId` int(11) NOT NULL,
  `vatname` varchar(40) NOT NULL,
  `vat` float(10,2) NOT NULL,
  `vatprcnt` float(10,2) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vat`
--

INSERT INTO `tbl_vat` (`vatId`, `vatname`, `vat`, `vatprcnt`, `add_date`, `status`) VALUES
(2, 'govt. Tax', 0.05, 5.00, '2020-01-09 18:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wlist`
--

CREATE TABLE `tbl_wlist` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_wlist`
--

INSERT INTO `tbl_wlist` (`id`, `cmrId`, `productId`, `p_name`, `price`, `image`, `date`) VALUES
(1, 4, 39, 'suzuki Ziggar', 200, 'Uploads/c87b3005b2.jpg', '2019-08-02 16:47:50'),
(2, 4, 38, 'Pulsure150cc', 300, 'Uploads/060b2d39b6.jpg', '2019-08-02 22:58:12'),
(3, 4, 40, 'new prado car', 2000, 'Uploads/6a64efbc72.jpg', '2019-08-03 01:06:42'),
(4, 5, 43, 'new prado car', 200, 'Uploads/9c36e9710d.jpg', '2019-08-04 14:32:22'),
(5, 4, 45, 'kawaski', 200, 'Uploads/6d931707af.png', '2019-08-07 23:42:59'),
(6, 5, 46, 'Latest colorfull car ', 200, 'Uploads/7cb42e1a7b.jpg', '2019-08-19 00:26:38'),
(9, 1, 15, '', 2200, 'Uploads/e15a06cbfc.jpg', '2020-01-13 23:42:28'),
(10, 0, 15, '', 2200, 'Uploads/e15a06cbfc.jpg', '2020-01-13 23:45:56'),
(11, 15, 9, '', 1000, 'Uploads/1c6cf0f434.jpg', '2020-01-14 00:29:54'),
(12, 16, 16, '', 2200, 'Uploads/b46b9682a8.jpg', '2020-02-23 13:43:00'),
(13, 16, 12, 'New Baby Shoes', 900, 'Uploads/84b7c3d9f0.jpg', '2020-02-23 13:51:57'),
(14, 16, 3, 'BLACK SHOE', 2000, 'Uploads/b03999b48d.jpg', '2020-02-23 14:10:27'),
(15, 16, 21, 'Kitchen Appliances Starts From', 900, 'Uploads/70d105ada9.jpg', '2020-02-23 14:12:03'),
(16, 16, 5, 'New Baby bag ', 750, 'Uploads/80dfea4e40.jpg', '2020-02-23 14:14:06'),
(17, 16, 17, 'New gents coats', 1000, 'Uploads/292c5b5c14.jpg', '2020-02-25 12:24:11'),
(18, 16, 7, 'BLACK SHOE Appex', 1000, 'Uploads/9237eec0a1.jpg', '2020-02-25 12:49:50'),
(19, 17, 15, 'New gents coats', 2200, 'Uploads/e691c6e15e.jpg', '2020-03-11 23:48:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`cstmId`);

--
-- Indexes for table `tbl_curtorder`
--
ALTER TABLE `tbl_curtorder`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`cstmrId`);

--
-- Indexes for table `tbl_dlchrge`
--
ALTER TABLE `tbl_dlchrge`
  ADD PRIMARY KEY (`dlchrgId`);

--
-- Indexes for table `tbl_font_theme`
--
ALTER TABLE `tbl_font_theme`
  ADD PRIMARY KEY (`thm_id`);

--
-- Indexes for table `tbl_header_slider`
--
ALTER TABLE `tbl_header_slider`
  ADD PRIMARY KEY (`hdslId`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payId`);

--
-- Indexes for table `tbl_pend_order`
--
ALTER TABLE `tbl_pend_order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `tbl_pro_category`
--
ALTER TABLE `tbl_pro_category`
  ADD PRIMARY KEY (`catproId`);

--
-- Indexes for table `tbl_pro_intro_slider`
--
ALTER TABLE `tbl_pro_intro_slider`
  ADD PRIMARY KEY (`intro_slId`);

--
-- Indexes for table `tbl_pro_type`
--
ALTER TABLE `tbl_pro_type`
  ADD PRIMARY KEY (`pro_typeId`);

--
-- Indexes for table `tbl_reply`
--
ALTER TABLE `tbl_reply`
  ADD PRIMARY KEY (`repId`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`sldId`);

--
-- Indexes for table `tbl_vat`
--
ALTER TABLE `tbl_vat`
  ADD PRIMARY KEY (`vatId`);

--
-- Indexes for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `cstmId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_curtorder`
--
ALTER TABLE `tbl_curtorder`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `cstmrId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_dlchrge`
--
ALTER TABLE `tbl_dlchrge`
  MODIFY `dlchrgId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_header_slider`
--
ALTER TABLE `tbl_header_slider`
  MODIFY `hdslId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_pend_order`
--
ALTER TABLE `tbl_pend_order`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_pro_category`
--
ALTER TABLE `tbl_pro_category`
  MODIFY `catproId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_pro_intro_slider`
--
ALTER TABLE `tbl_pro_intro_slider`
  MODIFY `intro_slId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_pro_type`
--
ALTER TABLE `tbl_pro_type`
  MODIFY `pro_typeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_reply`
--
ALTER TABLE `tbl_reply`
  MODIFY `repId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `sldId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_vat`
--
ALTER TABLE `tbl_vat`
  MODIFY `vatId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
