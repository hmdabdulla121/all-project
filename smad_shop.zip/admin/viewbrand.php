          <div class="content">
 			<h1 class="text-primary"><i class="fa fa-dashboard"></i> Brand <small>statstics OverView</small>
 				<span>Total:<?php 
 				   $getBrands=$bd->gelAllBrands();
                  if (isset($getBrands)) {
                  	echo "$getBrands";
                  }
 				 ?></span>
             <a href="userControl.php?my_brands" class="btn btn-primary btn-sm"> <i class="fas fa-plus"></i> Add</a>
 			</h1>
 			<ol class="breadcrumb">
			  	<form action="searchband.php" method="GET">
			  	  <input type="text" class="form-control serch_input" name="search" placeholder="Search Brand">
			  	  <button type="submit" class="btn btn-md btn-primary"><i class="fa fa-search"></i></button>
			  	</form>
			</ol>
			 <form action="" method="POST" enctype="multipart/form-data">
				<div class="table-responsive">
				 <table class="table table-hover table-bordered table-striped">
					<thead>
					  <tr>
						<th>sL:</th>
						<th>Brand</th>
						<th>Date</th>
					    <th>Action</th>
					  </tr>
					</thead>
					<tbody>
						<?php 
			            $getallbrand=$bd->getallbrand();
			              if ($getallbrand){
			                $i=0;
			                 while ($result=$getallbrand->fetch_assoc()){
			                $i++;     	
			           ?>
					  <tr>
						<td><?php echo $i; ?></td>
						<td><?php echo $result['brandName'] ; ?></td>
						<td><?php echo $fm->formatDate($result['add_date'])?></td>
						<td>
						  <a href="editbrand.php?brandId=<?= base64_encode($result['brandId']);?>" class="btn btn-sm btn-primary">Edit</a>
						  <a href="delbrand.php?delbrandId=<?php echo base64_encode($result['brandId'])?>" onclick="return confirm('Are You Sure to delete!!')"" class="btn btn-sm btn_dlt"><i class="fa fa-trash-o"></i>Del</a>
					    </td>
					  </tr>
					 <?php }}else{
						  $msg="<div class='alert alert-danger text-center'>
			                 <p class='thank_msg'>No available data here to show in result!!</p>
				             <i class='fa fa-exclamation-triangle font35'></i
				           </div>";
		                  echo $msg;
	                    }?>				
					 </tbody>	
					</table>
					</div>
				  </form>
				</div>