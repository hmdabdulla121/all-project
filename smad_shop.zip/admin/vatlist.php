        <div class="content">
 			<h1 class="text-primary"><i class="fa fa-dashboard"></i> Product Vat <small>statistics OverView</small>
 				<span>Total:<?php
 				   $getvat=$cat->getvats();
                  if (isset($getvat)) {
                  	echo "$getvat";
                  }
 				 ?></span>
             <a href="userControl.php?my_Vat" class="btn btn-primary btn-sm"> <i class="fas fa-plus"></i> Add</a>
 			</h1>
 			<ol class="breadcrumb">
			  <!-- <li class="active"><a href="index.php">Dashboard</a></li> -->
			    <form action="vatsearch.php" method="GET">
			  	  <input type="text" id="smado-tbl" data-action="filter" data-filters="#smado-tbl" name="search" class="form-control serch_input" name="" placeholder="Search Product">
			  	  <button type="submit" class="btn btn-md btn-primary"><i class="fa fa-search"></i></button>
			  	</form>
			</ol>
			 <form action="" method="POST" enctype="multipart/form-data">
				 <div class="table-responsive">
				  <table class="table table-hover table-bordered table-striped">
					<thead>
					  <tr>
						<th>sL:</th>
						<th>Vat Name</th>
						<th>Vat</th>
						<th>Vat Percent</th>
						<th>Date</th>
					    <th>Action</th>
					  </tr>
					</thead>
					<tbody>
						<?php
			                $getVat =$cat->getallVat();
			                if ($getVat){
			                	$i=0;
			                	 while ($result=$getVat->fetch_assoc()){
			                	$i++;
			          	 ?>
					   <tr id="smado-tbl">
						 <td><?= $i; ?></td>
						 <td><?= $result['vatname'] ; ?></td>
						 <td><?= $result['vat'] ; ?></td>
						 <td><?= $result['vatprcnt'];?>%</td>
						 <td><?php echo $fm->formatDate($result['add_date'])?></td>
						 <td>
						  <a href="vatedit.php?vatid=<?= base64_encode($result['vatId'])?>" class="btn btn-sm btn-primary">Edit</a>
						  <a href="delvat.php?delvat=<?= base64_encode($result['vatId'])?>" onclick="return confirm('Are You Sure to delete!!')" class="btn btn-sm btn_dlt">Del</a>
					     </td>
					   </tr>
					  <?php }}else{
						  $msg="<div class='alert alert-danger text-center'>
			                 <p class='thank_msg'>No available data here to show in result!!</p>
				             <i class='fa fa-exclamation-triangle font35'></i
				           </div>";
		                  echo $msg;
	                    }?>
					  </tbody>
					 </table>
					</div>
				  </form>
				</div>
