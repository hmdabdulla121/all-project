<?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <?php include 'inc/left_part.php'; ?>
      </div>
         <div class="col-sm-12 col-lg-9 col-md-9 col-xs-12" id="bg_light">
          <div class="content box">
            <h1 class="text-primary"><i class="fa fa-dashboard"></i> Customer Meaasge <small>statistics OverView</small>
             <a href="userControl.php?c_msg" class="btn btn-sm btn-primary">BACK TO VIEW</a>
			 <a href="userControl.php?c_msg" class="btn btn-sm btn-info"> <i class="fa fa-print"></i> Print</a>
            </h1>
            <hr>
           <?php
            if(!isset($_GET['msg_viewId']) || $_GET['msg_viewId']==NULL) {
               echo "<script>window.location='userControl.php?c_msg';</script>";
           }else{
              $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['msg_viewId']);
              $id= base64_decode($_GET['msg_viewId']);
              $get_message_byId =$cmr->get_message_byId($id);
             }
              if($_SERVER['REQUEST_METHOD']=='POST') {
                echo "<script>window.location='userControl.php?c_msg';</script>";
              }
           ?>
    		  <?php
            $get_message_byId =$cmr->get_message_byId($id);
            if($get_message_byId){
              while($result=$get_message_byId->fetch_assoc()){
          ?>
	       <form action="" method="post">
           <div class="table-responsive  tbl_scrolY_msg_view">
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> Message Details
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
               <tr>
                  <td class="text-bold text-primary">Name</td>
                  <td class="text-bold text-primary">
                    <?= $result['cfname'];?> <?= $result['clname']; ?>
                  </td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">EMAIL</td>
                 <td class="text-bold text-primary"><?= $result['email'];?></td>
                </tr>
               <tr>
                <td class="text-bold text-primary">MESSAGE</td>
                <td class="text-bold text-primary">
                  <textarea name="" id="" class="form-control  text-primary" cols="30" rows="5">
                    <?= $result['msg'];?>
                  </textarea>
                </td>
               </tr>
             </table>
            </div>
            <div class=" mt-5 mb-3">
              <button type="submit" class="btn btn-md btn-primary" name="button">Ok</button>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No Order Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>

   </div>
   </div>
</section>
<?php include 'inc/footer.php'; ?>
