<?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <?php include 'inc/left_part.php'; ?>
       </div>
         <div class="col-sm-12 col-lg-9 col-md-9 col-xs-12" id="bg_light">
          <div class="content box">
            <h1 class="text-primary"><i class="fa fa-dashboard"></i> User Information View <small>statistics OverView</small>
             <a href="userControl.php?view_prdct_type" class="btn btn-sm btn-primary">BACK TO VIEW</a>
            </h1>
            <hr>
           <?php
             if(!isset($_GET['view_typeId']) || $_GET['view_typeId']==NULL) {
               echo "<script>window.location='userControl.php?view_prdct_type';</script>";
             }else{
              $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['view_typeId']);
              $id= base64_decode($_GET['view_typeId']);
              $get_pro_type_View_byId=$cat->getproduct_type_byId($id);
             }
              if($_SERVER['REQUEST_METHOD']=='POST') {
                echo "<script>window.location='userControl.php?view_prdct_type';</script>";
              }
           ?>
           <?php
               $getproduct_type_byId =$cat->getproduct_type_byId($id);
                 if($getproduct_type_byId){
                    while($result=$getproduct_type_byId->fetch_assoc()){
                        $add_date=$result['add_date'];
            ?>
	       <form action="" class="" method="post">
           <div class="table-responsive tbl_scrolY_proslider">
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> Product Type View Details
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
        	  	  <tr>
                 <td class="text-bold text-primary">PRODUCT TYPE</td>
                 <td class="text-bold text-primary">
                   <?= $result['product_type'];?>
                 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT TYPE TITLE</td>
                <td class="text-bold text-primary"><?php echo $result['product_type_tle'];?></td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">PRODUCT SECTION TITLE</td>
                 <td class="text-bold text-primary"><?php echo $result['product_section_tle'];?></td>
                </tr>
               <tr>
                <td class="text-bold text-primary">PRODUCT TYPE ADD STATUS</td>
                <td class="text-bold text-primary">
                  <?php  $unixTimastap=$ago->convertToUnixTimestamp($add_date); ?>
                  <?= "Created ".$ago->convertToagoFormate($unixTimastap)." ago ";?>
                </td>
               </tr>
             </table>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <img src="<?php echo $result['pro_bannerImg'];?>" style="margin:10px 4px;border:2px solid #ccc;border-radius: 3px;" width="100%" height="100%" alt="Product Image">
            </div>
            </div>
            <div class=" mt-5 mb-3">
              <button type="submit" class="btn btn-md btn-primary" name="button">Ok</button>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No data Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>
      </div>
     </div>
     </div>
   </div>
</section>
<?php include 'inc/footer.php'; ?>
