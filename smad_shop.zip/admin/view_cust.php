<?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
   <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <?php include 'inc/left_part.php'; ?>
      </div>
         <div class="col-sm-12 col-lg-9 col-md-9 col-xs-12" id="bg_light">
          <div class="content box">
            <h1 class="text-primary"><i class="fa fa-user-md"></i> Customer Information View <small>statistics OverView</small>
             <a href="userControl.php?customer" class="btn btn-sm btn-primary">BACK TO VIEW</a>
            </h1>
            <hr>
           <?php
            if(!isset($_GET['custview_Id']) || $_GET['custview_Id']==NULL) {
               echo "<script>window.location='userControl.php?customer';</script>";
           }else{
              $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['custview_Id']);
              $id= base64_decode($_GET['custview_Id']);
              $get_custView_byId=$cmr->get_custView_byId($id);
             }
              if($_SERVER['REQUEST_METHOD']=='POST') {
                echo "<script>window.location='userControl.php?customer';</script>";
              }
           ?>
    		  <?php
            $get_custView_byId =$cmr->get_custView_byId($id);
            if($get_custView_byId){
              while($result=$get_custView_byId->fetch_assoc()){
                    $add_date=$result['signUpdate'];
          ?>
	       <form action="" method="post">
           <div class="table-responsive tbl_scrolY">
             <h3 class="text-primary">
              <i class="fa fa-dashboard"></i> Customer Individual Details
             </h3>
              <table class="table cstm_tbl table-bordered table-hover">
        	  	  <tr>
                 <td class="text-bold text-primary">CUSTOMER NAME</td>
                 <td class="text-bold text-primary">
                   <?= $result['name'];?>
                 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER E-MAIL</td>
                <td class="text-bold text-primary"><?php echo $result['email'];?></td>
               </tr>
               <tr>
                <tr>
                <td class="text-bold text-primary">CUSTOMER PROFILE</td>
                <td class="text-bold text-primary">
                  <img src="<?= $result['pro_pic'];?>" width="60" height="40" alt="No Preview to show">
                </td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">CUSTOMER STATUS</td>
                  <td class="text-bold text-primary">
                    <?php
                     if ($result['status']=='0') {
                       echo "<i class='fa fa-circle'></i>"." Active";
                     }elseif ($result['status']=='1') {
                       echo "<i class='fa fa-power-off'></i>"." Blocked";
                     }else{
                       echo "Removed";
                     }
                     ?>
                  </td>
               </tr>
               <tr>
                 <td class="text-bold text-primary">CUSTOMER PASSWORD</td>
                 <td class="text-bold text-primary">
      				  <?php echo md5($result['password']);?>
      				 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER JOINED STATUS</td>
                <td class="text-bold text-primary">
                  <?= "Joined ".$fm->formatDate($result['signUpdate'])?> (
                  <?php  $unixTimastap=$ago->convertToUnixTimestamp($add_date); ?>
                  <?= $ago->convertToagoFormate($unixTimastap)." ago ";?>
                  )
                </td>
               </tr>
             </table>
             <table class="table cstm_tbl table-bordered table-hover">
               <h3 class="text-primary">
                <i class="fa fa-dashboard"></i> CUSTOMER ADDITIONAL DETAILS
               </h3>
               <tr>
                <td class="text-bold text-primary">CUSTOMER COUNTRY</td>
                <td class="text-bold text-primary">
                   <?php echo $result['country'];?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER CITY</td>
                <td><?php echo $result['city'];?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER PHONE</td>
                <td><?php echo $result['phone'];?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">CUSTOMER IP</td>
                <td><?php echo $result['customer_ip'];?></td>
               </tr>
                <tr>
                <td class="text-bold text-primary">CUSTOMER RESIDENTIAL</td>
               <td>
                 <textarea class="form-control" cols="30" rows="5"><?php echo $result['address'];?></textarea>
               </td>
               </tr>
             </table>
            </div>
            <div class=" mt-5 mb-3">
              <button type="submit" class="btn btn-md btn-primary" name="button">Ok</button>
            </div>
        </form>
		   <?php } }else{
         $msg="<div class='alert alert-danger text-center'>
                 <p>No Order Available right now!!</p>
                 <i class='fa fa-exclamation-triangle font35'></i>
             </div>";
           echo $msg;
         }?>

   </div>
   </div>
</section>
<?php include 'inc/footer.php'; ?>
