 <?php include 'inc/header.php'; ?>
 <section class="dashboard_conent">
 	<div class="container-fluid">
 		<div class="row">
 	   <div class="col-xl-2 col-lg-3 col-md-3 col-sm-12 col-xs-12">
 		 <?php include 'inc/left_part.php'; ?>
 	   </div>
        <!--=====  full view content start======-->
 	   <div class="col-xl-10 col-lg-9 col-md-9 col-sm-12 col-xs-12" id="bg_light">
        <!--=====  Category include======-->
 		 <?php
            if (isset($_GET['my_cats'])) {
                include 'addcat.php';
            }
         ?>
          <!--=====  categorylist include======-->
         <?php
            if (isset($_GET['view_cats'])) {
                include 'categorylist.php';
            }
         ?>
          <!--=====  Product Category add include======-->
         <?php
            if (isset($_GET['my_prdct'])) {
                include 'addprod.php';
            }
         ?>
          <!--=====  Product Category view include======-->
         <?php
            if (isset($_GET['view_prdct'])) {
                include 'prodcat.php';
            }
         ?>
          <!--=====  addbrand include======-->
         <?php
            if (isset($_GET['my_brands'])) {
                include 'addbrand.php';
            }
         ?>
          <!--=====  viewbrand include======-->
         <?php
            if (isset($_GET['view_brands'])) {
                include 'viewbrand.php';
            }
         ?>
          <!--=====  addproduct include======-->
          <?php
            if (isset($_GET['my_product'])) {
                include 'addproduct.php';
            }
         ?>
          <!--=====  productview include======-->
          <?php
            if (isset($_GET['view_product'])) {
                include 'productview.php';
            }
         ?>
          <!--=====  vat include======-->
         <?php
            if (isset($_GET['my_Vat'])) {
                include 'addvat.php';
            }
         ?>
          <!--=====  vat view include======-->
         <?php
            if (isset($_GET['view_Vat'])) {
                include 'vatlist.php';
            }
         ?>
          <!--=====  delivery charge include======-->
         <?php
            if (isset($_GET['my_delvry'])) {
                include 'dchargeadd.php';
            }
         ?>
          <!--=====  delivery charge view include======-->
         <?php
            if (isset($_GET['view_delvry'])) {
                include 'dchargeview.php';
            }
         ?>
          <!--=====  orderlist include======-->
         <?php
            if (isset($_GET['customer_order'])) {
                include 'orderlist.php';
            }
         ?>
          <!--=====  pendorderlist include======-->
         <?php
            if (isset($_GET['pend_order'])) {
                include 'pendorderlist.php';
            }
         ?>
          <!--=====  deniedorderlist include ======-->
         <?php
            if (isset($_GET['denied_order'])) {
                include 'deniedorderlist.php';
            }
         ?>
         <?php
            if (isset($_GET['purchase'])) {
                include 'purchase.php';
            }
         ?>
         <?php
            if (isset($_GET['purchase_pend'])) {
                include 'purchase_pend.php';
            }
         ?>
         <?php
            if (isset($_GET['payments'])) {
                include 'paymentlist.php';
            }
         ?>
         <?php
            if (isset($_GET['payments_pend'])) {
                include 'payment_pend.php';
            }
         ?>
         <?php
            if (isset($_GET['payments_deny'])) {
                include 'payment_denied.php';
            }
         ?>
		 <?php
            if (isset($_GET['payments_refund'])) {
                include 'payment_refund.php';
            }
         ?>
         <?php
            if (isset($_GET['sales_reports'])) {
                include 'sales_reports.php';
            }
         ?>
         <?php
            if (isset($_GET['user'])) {
                include 'usercreate.php';
            }
         ?>
         <?php
            if (isset($_GET['view_users'])) {
                include 'users.php';
            }
         ?>
         <?php
            if (isset($_GET['block_users'])) {
                include 'block_list.php';
            }
         ?>
         <?php
            if (isset($_GET['profile_rollout'])) {
                include 'user_profile.php';
            }
         ?>
         <?php
            if (isset($_GET['userId'])) {
                include 'edit_prof.php';
            }
         ?>
        <?php
            if (isset($_GET['my_product_type'])) {
                include 'add_product_type.php';
            }
         ?>
         <?php
            if (isset($_GET['view_prdct_type'])) {
                include 'product_type_list.php';
            }
         ?>
		  <?php
            if (isset($_GET['header_slider_add'])) {
                include 'header_slider_add.php';
            }
         ?>
         <?php
            if (isset($_GET['view_header_slider'])) {
                include 'view_slider_head.php';
            }
         ?>
         <?php
            if (isset($_GET['my_slider_add'])) {
                include 'my_slider_add.php';
            }
         ?>
         <?php
            if (isset($_GET['view_slider'])) {
                include 'view_slider.php';
            }
         ?>
         <?php
            if (isset($_GET['customer'])) {
                include 'all_customer.php';
            }
         ?>
         <?php
            if (isset($_GET['c_msg'])) {
                include 'cust_msg_all.php';
            }
         ?>
          <?php
            if (isset($_GET['seen_msg'])) {
                include 'seen_msg_all.php';
            }
         ?>
          <?php
            if (isset($_GET['unseen_msg'])) {
                include 'unsen_msg.php';
            }
         ?>
         <?php
            if (isset($_GET['drft_msg'])) {
                include 'drtf_msg_all.php';
            }
         ?>
         <?php
            if (isset($_GET['theme'])) {
                include 'theme_add.php';
            }
         ?>
         <?php
            if (isset($_GET['theme_view'])) {
                include 'theme_view.php';
            }
         ?>
          <?php
            if (isset($_GET['visitor'])) {
                include 'vistors.php';
            }
         ?>
         <?php
            if (isset($_GET['web_theme'])) {
                include 'web_theme_change.php';
            }
         ?>
		  <?php
            if (isset($_GET['backup'])) {
                include 'backup.php';
            }
         ?>
 	 </div>
      <!--=====  full view content end======-->
    </div>
  </div>
 </section>
 <?php include 'inc/footer.php'; ?>
