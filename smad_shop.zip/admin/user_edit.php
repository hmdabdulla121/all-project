<?php include 'inc/header.php'; ?>
<section class="dashboard_conent">
 <div class="container-fluid">
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <?php include 'inc/left_part.php'; ?>
      </div>
      <div class="col-lg-9 col-md-9 col-sm-6 col-xs-12" id="bg_light">
    <div class="content box">
     <h1 class="text-primary"><i class="fa fa-edit"></i>Update users <small>statistics OverView</small>
            <a href="userControl.php?view_users" class="btn btn-primary btn-sm"> <i class="fas fa-eye"></i> Back to List</a>
     </h1>
     <ol class="breadcrumb">
       <li><a href="index.php">Dashboard</a></li>
       <li><a href="userControl.php?view_users"> All users</a></li>
       <li><span class="up_title"><i class="fa fa-edit"></i> Update users</span></li>
     </ol>
     <?php
	   error_reporting(0);
       if (!isset($_GET['userId']) || $_GET['userId']==NULL) {
            echo "<script>window.location='userControl.php?view_users';</script>";
       }else{
          $id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['userId']);
          $id=base64_decode($_GET['userId']);
       }
       if($_SERVER['REQUEST_METHOD']=='POST') {
          $updateUser=$al->updateUser($_POST,$id);
        }
      ?>
        <?php
           if(isset($updateUser)) {
           echo $updateUser;
         } ?>
      <form action="" method="POST" class="form" enctype="multipart/form-data">
        <div class="tbl_scrolY_usview">
		   <?php
              $getUserById =$al->getUserById($id);
              if($getUserById){
                while($result=$getUserById->fetch_assoc()){
           ?>
		     <table class="table cstm_tbl table-bordered table-hover">
        	   <tr>
                 <td class="text-bold text-primary">USER NAME</td>
                 <td class="text-bold text-primary">
                    <input type="text" name="upuser_name" class="form-control" value="<?= $result['adminUser'];?>">
                 </td>
                </tr>
               <tr>
                <td class="text-bold text-primary">USER E-MAIL</td>
                <td class="text-bold text-primary">
				<input type="email" name="up_User_email" class="form-control" value="<?= $result['adminEmail'];?>">
				</td>
               </tr>
			   <tr>
                 <td class="text-bold text-primary">USER PASSWORD</td>
                 <td class="text-bold text-primary">
				 <input type="text" name="up_User_pass" class="form-control" value="<?= base64_decode($result['adminPass']);?>">
				 </td>
               </tr>
               <tr>
                  <td class="text-bold text-primary">USER ROLE</td>
                  <td class="text-bold text-primary">
                   <select class="form-control" id="up_user_role" name="up_user_role">
                       <?php if($result['user_role']==1) {?>
 						    <option selected="selected" value="1">Admin</option>
 						    <option value="2">Moderator</option>
 						    <option value="3">Mentor</option>
 					   <?php }elseif ($result['user_role']==2) {?>
 					    	<option selected="selected" value="2">Moderator</option>
 					      <option value="1">Admin</option>
 						    <option value="3">Mentor</option>
 						 <?php }elseif ($result['user_role']==3) {?>
 					    	<option selected="selected" value="3">Mentor</option>
 						    <option value="1">Admin</option>
 						    <option value="2">Mentor</option>
 					   <?php } ?>
                  </select>
                  </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">UESER ADD STATUS</td>
                <td class="text-bold text-primary">
                   <?php
					  $getUserById =$al->getUserById($id);
					  if($getUserById){
						while($result=$getUserById->fetch_assoc()){
					?>
					<input type="date" name="up_date" class="form-control">
					<?php }} ?>
                </td>
               </tr>
             </table>
			  <?php }} ?>
			 <?php
              $getUserById =$al->getUserById($id);
              if($getUserById){
                while($result=$getUserById->fetch_assoc()){
             ?>
             <table class="table cstm_tbl table-bordered table-hover">
               <h3 class="text-primary">
                <i class="fa fa-dashboard"></i> User Additional Details
               </h3>
               <tr>
                <td class="text-bold text-primary">USER COUNTRY</td>
                <td class="text-bold text-primary">
                  <?php
                    if (!$result['country']==''){ ?>
                    <input type="text" name="country" class="form-control" value="<?= $result['country'];?>" />	   
                   <?php }else{
                    echo "N/A";
                  } ?>
                </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">USER CITY</td>
                <td  class="text-bold text-primary">
                  <?php
                    if (!$result['city']==''){ ?>
					<input type="text" name="city" class="form-control" value="<?= $result['city'];?>" />
                   <?php }else{
                    echo "N/A";
                  } ?></td>
               </tr>
               <tr>
                <td class="text-bold text-primary">USER PHONE</td>
                 <td class="text-bold text-primary">
                   <?php
                    if (!$result['phone']==''){ ?>
                     <input type="text" name="phone" class="form-control" value="<?= $result['phone'];?>" />  
                   <?php }else{
                    echo "N/A";
                  } ?>
                 </td>
               </tr>
               <tr>
                <td class="text-bold text-primary">USER ADDRESS</td>
                <td  class="text-bold text-primary">
                <textarea class="form-control text-primary" name="adrs" cols="30" rows="5" value="<?= $result['adrs'];?>">
                  <?= $result['adrs'];?>
                </textarea>
                </td>
               </tr>
             </table>
		    <?php }} ?>
         </div>
         <div class="catbtn">
           <button type="Submit" name="upuser" class="btn btn-primary btn-md"><i class="fa fa-paper-plane mr-2"></i> Update User</button>
         </div>
        </form>
      </div>
    </div>
  </div>
  </div>
</section>
<?php include 'inc/footer.php'; ?>
