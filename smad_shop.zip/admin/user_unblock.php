 <?php include 'inc/header.php'; ?>
 <?php 
    if(isset($_GET['user_unblk_Id'])){
     $user_unblk_Id=base64_decode($_GET['user_unblk_Id']);
     $user_inactivation=$al->user_inactivation($user_unblk_Id); 
     if(isset($user_inactivation)) {
	   echo "<script>window.location='userControl.php?view_users';</script>";  
	}     
  }
?>