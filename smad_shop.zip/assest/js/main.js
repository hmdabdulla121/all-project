$(document).ready(function () {
    //sticky menu
    $(".js--service-section").waypoint(function (direction) {
        if (direction == "down") {
            $("nav").addClass("sticky_menu");
            $("section.js--service-section").addClass("section_padding");
            $("div.left_part_menu").addClass("left_part_menu_remove");
            $("div.togleShow").addClass("togle_menuShow");
        } else {
            $("nav").removeClass("sticky_menu");
            $("section.js--service-section").removeClass("section_padding");
            $("div.left_part_menu").removeClass("left_part_menu_remove");
            $("div.togleShow").removeClass("togle_menuShow");
        }
    });
    // mobile view menu sub category open
    $('#mbl_cat1').on('click', function (event) {
        $('#show_mbl_cat1').slideToggle(200);
        event.preventDefault();
    });
    $('#mbl_cat2').on('click', function (event) {
        $('#show_mbl_cat2').slideToggle(200);
        event.preventDefault();
    });
    $('#mbl_cat3').on('click', function (event) {
        $('#show_mbl_cat3').slideToggle(200);
        event.preventDefault();
    });
    $('.drop_open_elprod').on('click', function (event) {
        $('.sub_catbel').slideToggle(200);
        event.preventDefault();
    });
    $('.drop_open_brprod').on('click', function (event) {
        $('.sub_catbr').slideToggle(200);
        event.preventDefault();
    });
    $('.drop_open_bsprod').on('click', function (event) {
        $('.sub_catbs').slideToggle(200);
        event.preventDefault();
    });
    $('.drop_open_fdprod').on('click', function (event) {
        $('.sub_catbfd').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open').on('click', function (event) {
        $('.left_part1').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open2').on('click', function (event) {
        $('.left_part2').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open3').on('click', function (event) {
        $('.left_part3').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open4').on('click', function (event) {
        $('.left_part4').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open5').on('click', function (event) {
        $('.left_part5').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open6').on('click', function (event) {
        $('.left_part6').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open7').on('click', function (event) {
        $('.left_part7').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open8').on('click', function (event) {
        $('.left_part8').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open9').on('click', function (event) {
        $('.left_part9').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open10').on('click', function (event) {
        $('.left_part10').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open11').on('click', function (event) {
        $('.left_part11').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open12').on('click', function (event) {
        $('.left_part12').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open13').on('click', function (event) {
        $('.left_part13').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open14').on('click', function (event) {
        $('.left_part14').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open15').on('click', function (event) {
        $('.left_part15').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open16').on('click', function (event) {
        $('.left_part16').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open17').on('click', function (event) {
        $('.left_part17').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open18').on('click', function (event) {
        $('.left_part18').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open19').on('click', function (event) {
        $('.left_part19').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open20').on('click', function (event) {
        $('.left_part20').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open21').on('click', function (event) {
        $('.left_part21').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open22').on('click', function (event) {
        $('.left_part22').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open23').on('click', function (event) {
        $('.left_part23').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open24').on('click', function (event) {
        $('.left_part24').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open25').on('click', function (event) {
        $('.left_part25').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open26').on('click', function (event) {
        $('.left_part26').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open27').on('click', function (event) {
        $('.left_part27').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open28').on('click', function (event) {
        $('.left_part28').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open29').on('click', function (event) {
        $('.left_part29').slideToggle(200);
        event.preventDefault();
    });
    $('.left_open30').on('click', function (event) {
        $('.left_part30').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open31').on('click', function (event) {
        $('.left_part32').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open32').on('click', function (event) {
        $('.left_part32').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open33').on('click', function (event) {
        $('.left_part33').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open34').on('click', function (event) {
        $('.left_part34').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open35').on('click', function (event) {
        $('.left_part35').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open36').on('click', function (event) {
        $('.left_part36').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open37').on('click', function (event) {
        $('.left_part37').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open38').on('click', function (event) {
        $('.left_part38').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open39').on('click', function (event) {
        $('.left_part39').slideToggle(200);
        event.preventDefault();
    });;
    $('.left_open40').on('click', function (event) {
        $('.left_part40').slideToggle(200);
        event.preventDefault();
    });
    // mobile view menu sub category open end
    $("#close_tap").click(function () {
        $("#close_note").css("display", "none", "5000");
    });
    $("#close_tap").click(function () {
        $("#close_note").css("display", "none", "5000");
    });
    // product slider/home slider
    $('.intro_slider').owlCarousel({
        loop: true,
        nav: false,
        //navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
        dots: true,
        mouseDrag: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items: 1,
        autoplay: true
    });
    /*------------------
		Product Slider
	--------------------*/
    $('.product-slider').owlCarousel({
        loop: true,
        nav: true,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        dots: true,
        mouseDrag: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items: 20,
        autoplay: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            600: {
                items: 3,
                nav: false
            },
            1000: {
                items: 4,
                nav: true
            },
            1300: {
                items: 5,
                nav: true
            }
        }
    });
    /*------------------
    	Preloder
    --------------------*/
    $(window).on('load', function () {
        $(".loader").fadeOut();
        $("#preloder").delay(100).fadeOut("slow");


        /*------------------
        	Product filter
        --------------------*/
        if ($('.aurora').length > 0) {
            var containerEl = document.querySelector('.aurora');
            var mixer = mixitup(containerEl);
        }
    });
    //navar active Link or li
    $("nav ul li").click(function () {
        $("nav ul li").removeClass("active");
        $(this).addClass("active");
    });
    //navar active Link or li when click on logo     
    $("nav a img.logo").click(function () {
        $("nav ul li").removeClass("active");
        $("nav ul li:nth-child(1)").addClass("active");
    });

    var mixer = mixitup('.aurora');

    //SMOOT SCROLL FOR IE/ EDGE/ SAFARI ALL BROWSER COMPABLIITY
    $("a").on('click', function (event) {
        if (this.hash !== "") {
            event.preventDefault();
            var hash = this.hash;

            $('html,body').animate({
                scrollTop: $(hash).offset().top
            }, 500, function () {
                window.location.hash = hash;
            });
        }
    });
    //scrollTop SCROLL animation we can also use $ institof jQuery
    $(window).on('scroll', function () {
        var utd = $(this).scrollTop();

        if (utd >= 200) {
            $('.scrollTop').fadeIn();
        } else {
            $('.scrollTop').fadeOut();
        }
    });
    $('.scrollTop').click(function () {
        $('html,body').animate({
            scrollTop: 0
        }, 200);
    });
    /*------------------
    	Navigation
    --------------------*/
    $('.nav-switch').on('click', function (event) {
        $('.main-menu').slideToggle(400);
        event.preventDefault();
    });

    /*------------------
    	drop down navitaion
    --------------------*/
    $('.drop_open').on('click', function (event) {
        $('.dropdown_option').slideToggle(400);
        event.preventDefault();
    });

    /*------------------
    	Background Set
    --------------------*/
    $('.set-bg').each(function () {
        var bg = $(this).data('setbg');
        $(this).css('background-image', 'url(' + bg + ')');
    });

    /*------------------
		Product Slider
	--------------------*/
    $('.product-slider').owlCarousel({
        loop: true,
        nav: true,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        dots: true,
        mouseDrag: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items: 20,
        autoplay: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 10,
                nav: true
            },
            600: {
                items: 3,
                nav: false
            },
            1000: {
                items: 4,
                nav: true
            },
            1300: {
                items: 5,
                nav: true
            }
        }
    });

    /*------------------
    	Intro Slider
    --------------------*/
    if ($('.intro-slider').length > 0) {
        var $scrollbar = $('.scrollbar');
        var $frame = $('.intro-slider');
        var sly = new Sly($frame, {
            horizontal: 1,
            itemNav: 'forceCentered',
            activateMiddle: 1,
            smart: 1,
            activateOn: 'click',
            //mouseDragging: 1,
            touchDragging: 1,
            releaseSwing: 1,
            startAt: 10,
            scrollBar: $scrollbar,
            //scrollBy: 1,
            activatePageOn: 'click',
            speed: 200,
            moveBy: 600,
            elasticBounds: 1,
            dragHandle: 1,
            dynamicHandle: 1,
            clickBar: 1,
        }).init();
    }

    /*------------------
    	ScrollBar
    --------------------*/
    $(".cart-table, .product-thumbs").niceScroll({
        cursorborder: "",
        cursorcolor: "#afafaf",
        boxzoom: false
    });

    /*------------------
    	ScrollBar
    --------------------*/
    $(".cart-table, .product-thumbs").niceScroll({
        cursorborder: "",
        cursorcolor: "#afafaf",
        boxzoom: false
    });



    /*------------------
    	Single Product
    --------------------*/
    $('.product-thumbs-track > .pt').on('click', function () {
        var imgurl = $(this).data('imgbigurl');
        var bigImg = $('.product-big-img').attr('src');
        if (imgurl != bigImg) {
            $('.product-big-img').attr({
                src: imgurl
            });
        }
    })
});
(function ($) {
    /*------------------
    	Navigation
    --------------------*/
    $('.nav-switch').on('click', function (event) {
        $('.main-menu').slideToggle(400);
        event.preventDefault();
    });
    /*------------------
    	drop down navitaion
    --------------------*/
    $('.drop_open').on('click', function (event) {
        $('.dropdown_option').slideToggle(400);
        event.preventDefault();
    });

    /*------------------
    	Background Set
    --------------------*/
    $('.set-bg').each(function () {
        var bg = $(this).data('setbg');
        $(this).css('background-image', 'url(' + bg + ')');
    });


    /*------------------
    	Hero Slider
    --------------------*/
    $('.hero-slider').owlCarousel({
        loop: true,
        nav: true,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        dots: true,
        mouseDrag: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items: 1,
        autoplay: true
    });
    /*------------------
		Product Slider
	--------------------*/
    $('.product-slider').owlCarousel({
        loop: true,
        nav: true,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        dots: true,
        mouseDrag: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items: 20,
        autoplay: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 3,
                nav: true
            },
            600: {
                items: 5,
                nav: false
            },
            1000: {
                items: 4,
                nav: true
            },
            1300: {
                items: 5,
                nav: true
            }
        }
    });

    /*------------------
    	Intro Slider
    --------------------*/
    if ($('.intro-slider').length > 0) {
        var $scrollbar = $('.scrollbar');
        var $frame = $('.intro-slider');
        var sly = new Sly($frame, {
            horizontal: 1,
            itemNav: 'forceCentered',
            activateMiddle: 1,
            smart: 1,
            activateOn: 'click',
            //mouseDragging: 1,
            touchDragging: 1,
            releaseSwing: 1,
            startAt: 10,
            scrollBar: $scrollbar,
            //scrollBy: 1,
            activatePageOn: 'click',
            speed: 200,
            moveBy: 600,
            elasticBounds: 1,
            dragHandle: 1,
            dynamicHandle: 1,
            clickBar: 1,
        }).init();
    }



    /*------------------
    	ScrollBar
    --------------------*/
    $(".cart-table, .product-thumbs").niceScroll({
        cursorborder: "",
        cursorcolor: "#afafaf",
        boxzoom: false
    });



    /*------------------
    	Single Product
    --------------------*/
    $('.product-thumbs-track > .pt').on('click', function () {
        var imgurl = $(this).data('imgbigurl');
        var bigImg = $('.product-big-img').attr('src');
        if (imgurl != bigImg) {
            $('.product-big-img').attr({
                src: imgurl
            });
        }
    })

})(jQuery);
//mobile menu creating script jQuery
function openNav() {
    document.getElementById("myNav").style.width = "85%";
}

function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}
