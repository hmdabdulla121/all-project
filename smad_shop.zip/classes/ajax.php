<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
class Ajax{
       private $db;
	   private $fm;

       public function __construct(){
	      $this->db =new Database();
	      $this->fm =new Format();
       }
       public function get_chart_data_by_year($year){
          $year=$this->fm->validation($year);
          $year=mysqli_real_escape_string( $this->db->link,$year);
          $query="SELECT * FROM tbl_payment";
		  if($year){
		  $query.=" WHERE year ='$year' ORDER BY payId ASC";
	      }
	      $result = $this->db->select($query);
		 //  foreach($result as $row){
		 //  $output[]=array(
		 //    'type'  =>'error',
         //    'total' => $row["total"],
         //    'year'  => floatval($row["year"])
		 //   );
		 //}
		 while($value = $result->fetch_assoc()) {
			   $output[] =array(
			   	'type'   =>'success',
			   	'massage'=>'Data selceted',
	            'total'  =>$value["total"],
	            'year'   =>floatval($value["year"])
            );
			//$data['year']=$value['year'];
			//$data['total']=$value['total'];
		   //}
           }
          return json_encode($output);  
      }
}
?>