<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
class category{
	 private $db;
	 private $fm;

     public function __construct(){
	   $this->db =new Database();
	   $this->fm =new Format();
   }
   //catInsert method class
   public function catInsert($Category){
       $Category=$this->fm->validation($Category);
       $Category=mysqli_real_escape_string( $this->db->link,$Category);
       if (empty($Category)){
          $msg ="<h4 class='alert alert-danger'>Category name must not be emty!!</h4>";
          return $msg;
       }else{
        $query ="INSERT INTO tbl_category(Category) VALUES('$Category')";
        $catinsert=$this->db->insert($query);
        if ($catinsert) {
          $msg_success="<h4 class='alert alert-success'>Category Inserted Successfully!!</h4>";
          return $msg_success;
        }else{
           $msg_error="<h4 class='alert alert-danger'>Category not Inserted!!</h4>";
          return $msg_error;
        }
      }
    }
    //getallcat method class
    public function getallcat(){
        $query   ="SELECT * FROM tbl_category ORDER BY catId ASC";
        $result  =$this->db->select($query);
        return $result;
    }

   //getCatById method class
   public function getCatById($id){
        $query   ="SELECT * FROM tbl_category WHERE catId='$id'";
        $result  =$this->db->select($query);
        return $result;
   }
   //catUpdate method class
   public function catUpdate($upct_name,$up_date,$id){
        $upct_name=$this->fm->validation($upct_name);
        $upct_name=mysqli_real_escape_string( $this->db->link,$upct_name);
        $up_date  =$this->fm->validation($up_date);
        $up_date  =mysqli_real_escape_string( $this->db->link,$up_date);
        $id       =mysqli_real_escape_string( $this->db->link,$id);
       if (empty($upct_name) || empty($up_date)){
          $msg="<h4 class='alert alert-danger'>Field name must not be emty!!</h4>";
          return $msg;
       }else{
          $query  ="UPDATE tbl_category
                    SET Category='$upct_name',
                        add_date='$up_date'
                    WHERE catId ='$id'";
          $Update_row =$this->db->update($query);
          if($Update_row){
             $msg_success="<h4 class='alert alert-success'>
                             <i class='fas fa-check-circle'>
                               Category Updated Successfully!!
                             </i>
                           </h4>";
          return $msg_success;
         }else{
             $msg_invalid="<h4 class='alert alert-danger'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Category not Updated!!
                              </i>
                           </h4>";
             return $msg_invalid;
           }
      }
   }
   //catDelete method class
   public function catDelete($id){
         $query   ="DELETE FROM tbl_category WHERE catId='$id'";
         $deletedata=$this->db->delete($query);
      if ($deletedata){
             $msg_success="<span class='text-success text-bold ml-5'>
                             Category Deleted Successfully!!
                           </span>";
             return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Category not Deleted!!
                              </i>
                           </span>";
             return $msg_invalid;
        }
    }
    public function getcats(){
        $query ="SELECT * FROM tbl_category ORDER BY catId ASC";
        $result=$this->db->select($query);
         if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
     }
      //category Seacrh method class
     public function search_cat($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_category WHERE Category LIKE '%$search%' OR add_date like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
   //Product category Insert method class
   public function InsertProCat($data){
       $product =$this->fm->validation($data['product']);
       $product =mysqli_real_escape_string( $this->db->link,$data['product']);
       $prd_type=$this->fm->validation(base64_decode($data['prd_type']));
       $prd_type=mysqli_real_escape_string( $this->db->link,base64_decode($data['prd_type']));
       $catId=$this->fm->validation(base64_decode($data['catId']));
       $catId=mysqli_real_escape_string( $this->db->link,base64_decode($data['catId']));
       if (empty($product) || empty($prd_type) || empty($catId)){
          $msg ="<h5 class='alert alert-danger'>Field must not be emty!!</h5>";
          return $msg;
        }else{
        $query ="INSERT INTO tbl_pro_category(product,pro_typeId,catId) VALUES('$product','$prd_type','$catId')";
        $Procatinsert=$this->db->insert($query);
        if ($Procatinsert) {
          $msg_success="<h4 class='alert alert-success'>Product Category Inserted Successfully!!</h4>";
          return $msg_success;
        }else{
           $msg_error="<h4 class='alert alert-danger'>Product Category not Inserted!!</h4>";
          return $msg_error;
        }
      }
    }
   //Product category Select method class
   public function getallProcat(){
        $query   ="SELECT * FROM tbl_pro_category ORDER BY catproId ASC";
        $result  =$this->db->select($query);
        return $result;
   }
   //getCatById method class
   public function getProcatById($id){
        $query   ="SELECT * FROM tbl_pro_category WHERE catproId='$id'";
        $result  =$this->db->select($query);
        return $result;
   }
   public function get_pro_cat_type_all(){
      $query="SELECT pc.*,pt.product_type,pt.product_section_tle,ct.Category
      FROM  tbl_pro_category as pc,tbl_pro_type as pt,tbl_category as ct
      WHERE pc.pro_typeId=pt.pro_typeId AND  pc.catId=ct.catId
      ORDER BY pc.catproId DESC";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type1(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='1' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type2(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='2' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type3(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='3' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type4(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='4' 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type5(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='5' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type6(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='6' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type7(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='7' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type8(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='8' 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type9(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='9' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type10(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='10' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProduct_catBy_type12(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='12' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type13(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='13' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type14(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='14' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type15(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='15' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type16(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='16' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type17(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='17' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type18(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='18' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type19(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='19' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type20(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='20' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type21(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='21' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type22(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='22' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type23(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='23' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type24(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='24' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type25(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='25' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type26(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='26' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type27(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='27' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type28(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='28' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type29(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='29' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type30(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='30' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type31(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='31' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type32(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='32' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type33(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='33' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type34(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='34' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type35(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='35' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type36(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='36' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type37(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='37' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type38(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='38' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type39(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='39' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type40(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='40' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type41(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='41' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type42(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='42' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type43(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='43' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type44(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='44' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type45(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='45' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type46(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='46' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type47(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='47' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type48(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='48' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type49(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='49' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProduct_catBy_type50(){
      $query="SELECT pc.*,pt.product_type,pt.product_type_tle,pt.product_section_tle,
      pt.pro_bannerImg
      FROM  tbl_pro_category as pc,tbl_pro_type as pt
      WHERE pc.pro_typeId=pt.pro_typeId AND pc.pro_typeId='50' LIMIT 12";
      $result  =$this->db->select($query);
      return $result;
    }
    //Product category Update method class
    public function updateProCat($upPrct_name,$pro_typeId,$catId,$up_date,$id){
      $upPrct_name=$this->fm->validation($upPrct_name);
      $upPrct_name=mysqli_real_escape_string( $this->db->link,$upPrct_name);
      $pro_typeId=$this->fm->validation($pro_typeId);
      $pro_typeId=mysqli_real_escape_string( $this->db->link,$pro_typeId);
      $catId=$this->fm->validation($catId);
      $catId=mysqli_real_escape_string( $this->db->link,$catId);
      $up_date=$this->fm->validation($up_date);
      $up_date =mysqli_real_escape_string( $this->db->link,$up_date);
      $id =mysqli_real_escape_string( $this->db->link,$id);
        if (empty($up_date)){
          $msg="<h4 class='alert alert-danger'>Filed must not be emty!!</h4>";
          return $msg;
        }else{
          $query ="UPDATE tbl_pro_category
                    SET product     ='$upPrct_name',
                        pro_typeId  ='$pro_typeId',
                        catId       ='$catId',
                        procatAdd_dt='$up_date'
                    WHERE catproId  ='$id'";
          $Update_row =$this->db->update($query);
          if($Update_row){
           echo "<script>window.open('userControl.php?view_prdct','_self');</script>";
        //      $msg_success="<span class='text-success text-bold ml-5'>
        //                      <i class='fas fa-check-circle'>
        //                        Category Updated Successfully!!
        //                      </i>
        //                    </span>";
        //   return $msg_success;
        //  }else{
             $msg_invalid="<h4 class='alert alert-danger'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Product Category not Updated!!
                              </i>
                           </h4>";
             return $msg_invalid;
           }
      }
    }
     //Product category Delete method class
    public function proCat_del($id){
       $query ="DELETE FROM tbl_pro_category WHERE catproId='$id'";
       $deletedata=$this->db->delete($query);
        if($deletedata){
            $msg_success="<span class='text-success text-bold ml-5'>
                             Product Category Deleted Successfully!!
                           </span>";
            return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                Product Category not Deleted!!
                              </i>
                           </span>";
             return $msg_invalid;
        }
     }
     public function getProcat(){
       $query ="SELECT * FROM tbl_pro_category ORDER BY catproId ASC";
       $result=$this->db->select($query);
        if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
     }
    //product category search method
    public function search_procat($search){
       $search=$this->fm->validation($search);
       $search=mysqli_real_escape_string( $this->db->link,$search);
       $sql="SELECT * FROM tbl_pro_category WHERE product LIKE '%$search%' OR procatAdd_dt like '%$search%'";
       $searchData = $this->db->select($sql);
       return $searchData;
    }
      //Product category Insert method class
    public function InsertPro_type($data,$file){
       $product_type=$this->fm->validation($data['product_type']);
       $product_type=mysqli_real_escape_string( $this->db->link,$data['product_type']);

       $product_type_tle=$this->fm->validation($data['product_type_tle']);
       $product_type_tle=mysqli_real_escape_string( $this->db->link,$data['product_type_tle']);
          
       $product_section_tle=$this->fm->validation($data['product_section_tle']);
       $product_section_tle=mysqli_real_escape_string( $this->db->link,$data['product_section_tle']);

       $permited= array('jpg' ,'jpeg','png','gif');
       $file_name=$file['pro_bannerImg']['name'];
       $file_size=$file['pro_bannerImg']['size'];
       $file_tmp =$file['pro_bannerImg']['tmp_name'];
         
       $div         =explode('.', $file_name);
       $file_txt   =strtolower(end($div));
       $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
       $upload_image="Uploads/".$unique_image;

       $query   ="SELECT * FROM tbl_pro_type ORDER BY pro_typeId";
       $result  =$this->db->select($query);
       $count=mysqli_num_rows($result);
       if($count<=50){

       if (empty($product_type) || empty($product_type_tle) || empty($product_section_tle) || empty($file_name)){
          $msg ="<h4 class='alert alert-danger'>Field must not be emty!!</h4>";
           return $msg;
        }elseif($file_size>1048567){
         echo "<h5 class='text-danger'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Product Image too large!!
                     </i>
                </h5>";
         }
         elseif(in_array($file_txt,$permited)==false){
            echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
         }else{
            move_uploaded_file($file_tmp, $upload_image);
            $query ="INSERT INTO tbl_pro_type(product_type,product_type_tle,product_section_tle,pro_bannerImg) VALUES('$product_type','$product_type_tle','$product_section_tle','$upload_image')";
            $Pro_type_insert=$this->db->insert($query);

          if($Pro_type_insert) {
             $msg_success="<h5 class='alert alert-success'>Product Type Inserted Successfully!!</h5>";
             return $msg_success;
             }else{
             $msg_error="<h5 class='alert alert-danger'>Product Type not Inserted!!</h5>";
             return $msg_error;
           }  
         } 
         }else{
          $msg_error="<h5 class='alert alert-danger'>Product Type is limited.You already finished your product type limitation.Please you can't make any more step at this time!!</h5>";
          return $msg_error; 
         }
    }
    public function getproduct_type_byId($id){
      $query  ="SELECT * FROM tbl_pro_type WHERE pro_typeId ='$id'";
      $result =$this->db->select($query);
      return $result;
    }
    public function product_type_update($data,$file,$id){
      $up_product_type =$this->fm->validation($data['up_product_type']);
      $up_product_type =mysqli_real_escape_string( $this->db->link,$data['up_product_type']);
      $up_product_type_tle   =$this->fm->validation($data['up_product_type_tle']);
      $up_product_type_tle   =mysqli_real_escape_string( $this->db->link,$data['up_product_type_tle']);
      $up_product_section_tle =$this->fm->validation($data['up_product_section_tle']);
      $up_product_section_tle =mysqli_real_escape_string( $this->db->link,$data['up_product_section_tle']);
      $up_add_date=$this->fm->validation($data['up_add_date']);
      $up_add_date=mysqli_real_escape_string( $this->db->link,$data['up_add_date']);
         
      $permited    = array('jpg' ,'jpeg','png','gif');
      $file_name   =$file['up_img']['name'];
      $file_size   =$file['up_img']['size'];
      $file_tmp    =$file['up_img']['tmp_name'];
  
      $div         =explode('.', $file_name);
      $file_txt    =strtolower(end($div));
      $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
      $upload_image="Uploads/".$unique_image;
  
      if ($up_add_date=="" ){
          $msg ="<h4 class='alert alert-danger'>
                       <i class='fas fa-exclamation-triangle mr-1'>
                         Field name must not empty!!
                       </i>
                     </h4>";
          return $msg;
      }else{
        if(!empty($file_name)){
            if($file_size>1048567){
             echo "<h5 class='alert alert-danger'>Product not Updated Diew to too much large file!!</h5>";
            }elseif (in_array($file_txt,$permited)==false){
              echo "<h3 class='alert alert-danger'>You can upload only:-".implode(',', $permited)."</h3>";
            }
            else{
             move_uploaded_file($file_tmp, $upload_image);
                $query="UPDATE tbl_pro_type
                    SET
                    product_type       ='$up_product_type',
                    product_type_tle   ='$up_product_type_tle',
                    product_section_tle='$up_product_section_tle',
                    pro_bannerImg      ='$upload_image',
                    add_date           ='$up_add_date'
                    WHERE pro_typeId='$id'";
               $Product_type_Update=$this->db->update($query);
  
            if($Product_type_Update){
            $msg_success="<h4 class='alert alert-success'>
                             <i class='fas fa-exclamation-triangle mr-1'>
                                  Product type updated successfully!!
                              </i>
                          </h4>";
            return $msg_success;
           }else{
            $msg ="<h4 class='alert alert-danger'>
                       <i class='fas fa-exclamation-triangle mr-1'>
                         Product type not Updated..!!
                       </i>
                     </h4>";
            return $msg;
           }
         }
        }
        else{
              $query="UPDATE tbl_pro_type
                       SET
                       product_type       ='$up_product_type',
                       product_type_tle   ='$up_product_type_tle',
                       product_section_tle='$up_product_section_tle',
                       add_date           ='$up_add_date'
                       WHERE pro_typeId='$id'";
                 $Product_type_Update=$this->db->update($query);
                 if($Product_type_Update){
                 $msg_success="<h4 class='alert alert-success'>
                                <i class='fas fa-check-circle mr-1'>
                                  Product type Updated Successfully!!
                                </i>
                              </h4>";
                 return $msg_success;
                 }else{
                 $msg ="<h4 class='alert alert-danger'>
                         <i class='fas fa-exclamation-triangle mr-1'>
                           Product type not Updated..!!
                         </i>
                       </h4>";
                 return $msg;
                }
              }
           }
        }
      //Product category Select method class
    public function getallPro_type(){
       $query   ="SELECT * FROM tbl_pro_type ORDER BY pro_typeId ASC";
       $result  =$this->db->select($query);
       return $result;
    }
	// start type wise product category countn for submenu  
	public function getProcat_count_by_pro_type1(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='1'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type2(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='2'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type3(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='3'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type4(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='4'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type5(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='5'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type6(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='6'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type7(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='7'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type8(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='8'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type9(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='9'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type10(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='10'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }public function getProcat_count_by_pro_type11(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='11'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type12(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='12'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type13(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='13'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type14(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='14'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type15(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='15'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type16(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='16'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type17(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='17'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type18(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='18'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type19(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='19'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type20(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='20'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type21(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='21'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type22(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='22'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type23(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='23'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type24(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='24'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type25(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='25'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type26(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='26'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type27(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='27'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type28(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='28'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type29(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='29'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type30(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='30'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type31(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='31'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type32(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='32'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type33(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='33'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type34(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='34'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type35(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='35'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type36(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='36'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type37(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='37'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type38(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='38'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type39(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='39'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type40(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='40'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type41(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='41'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type42(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='42'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type43(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='43'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type44(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='44'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type45(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='45'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type46(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='46'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type47(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='47'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type48(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='48'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type49(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='49'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	public function getProcat_count_by_pro_type50(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='50'";
       $result  =$this->db->select($query);
	   $count=mysqli_num_rows($result);
       return $count;
    }
	//type wise product category countn for submenu end 
	// =======The start retrive product category by protype_id limit50 for menu=========
	public function getProcat_type1_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='1' ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }	
	public function getProcat_type1_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='1' ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type1_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='1' ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type1_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='1' ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type2_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='2' ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type2_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='2' ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type2_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='2'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type2_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='2'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type3_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='3' ORDER BY rand() LIMIT 0,10 ";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type3_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='3' ORDER BY rand() LIMIT 10,20 ";
       $result  =$this->db->select($query);
       return $result;
    }public function getProcat_type3_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='3' ORDER BY rand() LIMIT 20,30 ";
       $result  =$this->db->select($query);
       return $result;
    }public function getProcat_type3_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='3' ORDER BY rand() LIMIT 30,40 ";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type4_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='4'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type4_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='4'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type4_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='4'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type4_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='4'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type5_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='5' ORDER BY rand() LIMIT 0,10 ";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type5_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='5'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type5_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='5' ORDER BY rand()  LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type5_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='5'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type6_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='6'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type6_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='6'  ORDER BY rand() LIMIT 10,20" ;
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type6_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='6'  ORDER BY rand() LIMIT 20,30" ;
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type6_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='6'  ORDER BY rand() LIMIT 30,40" ;
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type7_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='7'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type7_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='7' ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type7_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='7' ORDER BY rand()  LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }public function getProcat_type7_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='7'ORDER BY rand()  LIMIT 30,40 ";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type8_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='8'ORDER BY rand()  LIMIT 0,10 ";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type8_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='8'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type8_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='8'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type8_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='8'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type9_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='9' ORDER BY rand() LIMIT 0,10 ";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type9_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='9' ORDER BY rand()  LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }public function getProcat_type9_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='9'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }public function getProcat_type9_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='9'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type10_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='10' ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type10_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='10'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type10_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='10'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type10_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='10'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	
	public function getProcat_type11_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='11'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type11_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='11'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type11_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='11'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type11_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='11'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type12_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='12'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type12_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='12'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type12_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='12'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type12_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='12'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type13_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='13'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type13_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='13'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type13_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='13'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type13_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='13'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type14_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='14'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type14_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='14'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type14_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='14'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type14_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='14'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type15_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='15'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type15_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='15'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type15_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='15'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type15_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='15'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type16_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='16'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type16_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='16'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type16_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='16'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type16_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='16'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type17_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='17'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type17_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='17'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type17_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='17'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type17_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='17'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type18_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='18'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type18_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='18'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type18_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='18'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type18_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='18'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type19_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='19'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type19_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='19'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type19_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='19'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type19_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='19'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type20_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='20'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type20_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='20'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type20_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='20'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type20_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='20'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type21_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='21'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type21_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='21'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type21_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='21'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type21_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='21'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type22_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='22'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type22_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='22'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type22_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='22'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type22_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='22'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type23_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='23'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type23_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='23'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type23_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='23'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type23_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='23'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type24_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='24'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type24_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='24'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type24_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='24'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type24_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='24'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type25_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='25'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type25_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='25'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type25_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='25'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type25_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='25'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type26_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='26'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type26_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='26'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type26_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='26'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type26_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='26'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type27_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='27'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type27_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='27'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type27_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='27'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type27_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='27'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type28_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='28'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type28_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='28'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type28_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='28'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type28_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='28'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type29_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='29'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type29_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='29'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type29_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='29'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type29_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='29'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type30_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='30'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type30_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='30'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type30_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='30'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type30_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='30'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type31_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='31'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type31_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='31'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type31_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='31'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type31_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='31'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getProcat_type32_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='32'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type32_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='32'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type32_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='32'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type32_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='32'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type33_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='33'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type33_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='33'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type33_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='33'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type33_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='33'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type34_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='34'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type34_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='34'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type34_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='34'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type34_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='34'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type35_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='35'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type35_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='35'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type35_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='35'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type35_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='35'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type36_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='36'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type36_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='36'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type36_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='36'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type36_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='36'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type37_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='37'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type37_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='37'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type37_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='37'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type37_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='37'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type38_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='38'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type38_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='38'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type38_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='38'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type38_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='38'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type39_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='39'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type39_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='39'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type39_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='39'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type39_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='39'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type40_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='40'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type40_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='40'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type40_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='40'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type40_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='40'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type41_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='41'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type41_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='41'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type41_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='41'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type41_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='41'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type42_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='42'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type42_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='42'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type42_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='42'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type42_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='42'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type43_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='43'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type43_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='43'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type43_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='43'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type43_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='43'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type44_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='44'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type44_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='44'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type44_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='44'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type44_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='44'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type45_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='45'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type45_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='45'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type45_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='45'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type45_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='45'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type46_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='46'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type46_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='46'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type46_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='46'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type46_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='46'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type47_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='47'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type47_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='47'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type47_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='47'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type47_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='47'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type48_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='48'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type48_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='48'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type48_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='48'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type48_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='48'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type49_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='49'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type49_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='49'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type49_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='49'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type49_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='49'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type50_lm_0_10_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='50'  ORDER BY rand() LIMIT 0,10";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type50_lm_10_20_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='50'  ORDER BY rand() LIMIT 10,20";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type50_lm_20_30_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='50'  ORDER BY rand() LIMIT 20,30";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type50_lm_30_40_by_catId(){
       $query   ="SELECT * FROM  tbl_pro_category WHERE pro_typeId='50'  ORDER BY rand() LIMIT 30,40";
       $result  =$this->db->select($query);
       return $result;
    }
	// ==========The end retrive product category by protype_id limit50===========
	// ==========The start all retrive product category by protype_id limit50===========
	public function getProcat_type1_all_by_catId(){
       $query   ="SELECT * FROM tbl_pro_category WHERE pro_typeId='1'";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type2_all_by_catId(){
       $query   ="SELECT * FROM tbl_pro_category WHERE pro_typeId='2'";
       $result  =$this->db->select($query);
       return $result;
    }
	public function getProcat_type3_all_by_catId(){
       $query   ="SELECT * FROM tbl_pro_category WHERE pro_typeId='3'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getPro_type(){
       $query ="SELECT * FROM tbl_pro_type ORDER BY pro_typeId ASC";
       $result=$this->db->select($query);
       if ($result==true) {
           $count=mysqli_num_rows($result);
           return "(".$count.")";
       }else{
        echo "(empty)";
      }
    }
       //Product 50 Type List By Id method class start
    public function getallPro_typeBy_type1(){
       $query   ="SELECT * FROM tbl_pro_type WHERE 	pro_typeId='1'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type2(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='2'";
       $result  =$this->db->select($query);
       return $result;
    }
     public function getallPro_typeBy_type3(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='3'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type4(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='4'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type5(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='5'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type6(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='6'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type7(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='7'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type8(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='8'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type9(){
       $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='9'";
       $result  =$this->db->select($query);
       return $result;
    }
    public function getallPro_typeBy_type10(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='10'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type11(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='11'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type12(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='12'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type13(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='13'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type14(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='14'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type15(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='15'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type16(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='16'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type17(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='17'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type18(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='18'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type19(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='19'";
         $result  =$this->db->select($query);
         return $result;
        }
        public function getallPro_typeBy_type20(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='20'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type21(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='21'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type22(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='22'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type23(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='23'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type24(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='24'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type25(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='25'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type26(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='26'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type27(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='27'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type28(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='28'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type29(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='29'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type30(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='30'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type31(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='31'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type32(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='32'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type33(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='33'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type34(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='34'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type35(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='35'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type36(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='36'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type37(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='37'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type38(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='38'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type39(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='39'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type40(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='40'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type41(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='41'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type42(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='42'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type43(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='43'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type44(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='44'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type45(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='45'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type46(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='46'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type47(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='47'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type48(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='48'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type49(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='49'";
         $result  =$this->db->select($query);
         return $result;
        }
		public function getallPro_typeBy_type50(){
         $query   ="SELECT * FROM tbl_pro_type WHERE pro_typeId='50'";
         $result  =$this->db->select($query);
         return $result;
        }
         //Product 50 Type List By Id method class end
         //Product 50 Type List By Id count method class end
		public function getallPro_type_count1(){
         $query   ="SELECT * FROM tbl_pro_type ORDER BY pro_typeId ASC";
         $result  =$this->db->select($query);
	     $count=mysqli_num_rows($result);
         return $count;
        }
		//Product 50 Type List By Id count method class end
         //Product category Delete method class
        public function delPro_typeById($id){
         $query ="DELETE FROM tbl_pro_type WHERE pro_typeId='$id'";
         $deletedata=$this->db->delete($query);
         if ($deletedata){
               $msg_success="<span class='text-success text-bold ml-5'>
                              Product Type  Deleted Successfully!!
                              </span>";
               return $msg_success;
            }else{
               $msg_invalid="<span class='text-danger text-bold ml-5'>
                                 <i class='fas fa-exclamation-triangle mr-1'>
                                 Product Type not Deleted!!
                                 </i>
                              </span>";
               return $msg_invalid;
         }
      }
	   public function Insertheader_slider($data,$file){
        $slider_ttl=$this->fm->validation($data['slider_ttl']);
        $slider_ttl=mysqli_real_escape_string( $this->db->link,$data['slider_ttl']);

        $prd_type=$this->fm->validation(base64_decode($data['prd_type']));
        $prd_type=mysqli_real_escape_string( $this->db->link,base64_decode($data['prd_type']));

        $permited    = array('jpg' ,'jpeg','png','gif');
        $pro_image  =$file['slider_img']['name'];
        $slider_imgsz=$file['slider_img']['size'];
        $file_tmp   =$file['slider_img']['tmp_name'];

        $div         =explode('.', $pro_image);
        $file_txt   =strtolower(end($div));
       // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image too}
       $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
       $upload_image="Uploads/".$unique_image;
        if (empty($slider_ttl) || empty($prd_type) || empty($pro_image)){
           $msg ="<h4 class='alert alert-danger'>Field must not be emty!!</h4>";
           return $msg;
          }elseif($slider_imgsz>1048567){
          echo "<h5 class='text-danger'>
                    <i class='fas fa-exclamation-triangle mr-1'>
                      Product Image too large!!
                    </i>
               </h5>";
         }
          elseif(in_array($file_txt,$permited)==false){
           echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',$permited)."</h5>";
         }else{
            move_uploaded_file( $file_tmp, $upload_image);
           $query ="INSERT INTO tbl_header_slider(slider_ttl,pro_typeId,slider_img) VALUES('$slider_ttl','$prd_type','$upload_image')";
           $Pro_type_insert=$this->db->insert($query);
           if($Pro_type_insert) {
            $msg_success="<h5 class='alert alert-success'>Header Slider Inserted Successfully!!</h5>";
            return $msg_success;
            }else{
            $msg_error="<h5 class='alert alert-danger'>Header Slider not Inserted!!</h5>";
            return $msg_error;
          }  
        } 
       }
	   public function getall_header_slider(){
        $query   ="SELECT * FROM tbl_header_slider ORDER BY hdslId DESC ";
        $result  =$this->db->select($query);
        return $result;
       }
	   public function getall_header_slider_home(){
        $query   ="SELECT * FROM tbl_header_slider ORDER BY hdslId DESC LIMIT 0,1";
        $result  =$this->db->select($query);
        return $result;
       }
	   public function getall_header_slider_home1to6(){
        $query   ="SELECT * FROM tbl_header_slider ORDER BY hdslId DESC LIMIT 1,9";
        $result  =$this->db->select($query);
        return $result;
       }
	   public function get_header_slider_ById($id){
        $query  ="SELECT * FROM tbl_header_slider WHERE hdslId='$id'";
        $result =$this->db->select($query);
        return $result;
       }
	   public function update_header_slider($data,$file,$id){
        $up_slider_ttl=$this->fm->validation($data['up_slider_ttl']);
        $up_slider_ttl=mysqli_real_escape_string($this->db->link,$data['up_slider_ttl']);
        $pro_typeId  =$this->fm->validation($data['pro_typeId']);
        $pro_typeId  =mysqli_real_escape_string( $this->db->link,$data['pro_typeId']);
        $up_add_date =$this->fm->validation($data['up_add_date']);
        $up_add_date  =mysqli_real_escape_string($this->db->link,$data['up_add_date']);
 
        $permited    = array('jpg' ,'jpeg','png','gif');
        $slider_img  =$file['up_slider_img']['name'];
        $slider_imgsz=$file['up_slider_img']['size'];
        $file_tmp   =$file['up_slider_img']['tmp_name'];
        $div         =explode('.', $slider_img);
        $file_txt   =strtolower(end($div));
        $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
        $upload_image="Uploads/".$unique_image;
         if($up_add_date==""){
             $msg ="<h4 class='alert alert-danger'>
                      <i class='fas fa-exclamation-triangle mr-1'>
                        Field name must not empty!!
                      </i>
                    </h4>";
           return $msg;
         }else{
           if(!empty($slider_img)){
              if($slider_imgsz>1048567){
               echo "<h5 class='alert alert-danger'>Product not Updated Diew to too much large file!!</h5>";
              }elseif (in_array($file_txt,$permited)==false){
               echo "<h3 class='alert alert-danger'>You can upload only:-".implode(',', $permited)."</h3>";
              }else{
               move_uploaded_file( $file_tmp, $upload_image);
                $query="UPDATE tbl_header_slider
                       SET
                       slider_ttl='$up_slider_ttl',
                       pro_typeId='$pro_typeId',
                       slider_img='$upload_image',
                       add_date   ='$up_add_date'
                       WHERE hdslId='$id'";
                $ProductUpdate=$this->db->update($query);
                if($ProductUpdate){
                        $msg_success="<h4 class='alert alert-success'>
                            <i class='fas fa-exclamation-triangle mr-1'>
                                 Product updated successfully!!
                             </i>
                         </h4>";
                return $msg_success;
                }else{
                   $msg ="<h4 class='alert alert-danger'>
                      <i class='fas fa-exclamation-triangle mr-1'>
                        Product not Updated..!!
                      </i>
                    </h4>";
              return $msg;
             }
            }
           }else{
                $query="UPDATE tbl_header_slider
                      SET
                      slider_ttl='$up_slider_ttl',
                      pro_typeId='$pro_typeId',
                      add_date  ='$up_add_date'
                WHERE hdslId='$id'";
 
                $ProductUpdate=$this->db->update($query);
                if($ProductUpdate){
                $msg_success="<h4 class='alert alert-success'>
                               <i class='fas fa-check-circle mr-1'>
                                 Product Updated Successfully!!
                               </i>
                             </h4>";
                return $msg_success;
                }else{
                $msg ="<h4 class='alert alert-danger'>
                        <i class='fas fa-exclamation-triangle mr-1'>
                          Product not Updated..!!
                        </i>
                      </h4>";
                return $msg;
               }
             }
          }
       }
	   public function del_slider_head($id){
		$query="DELETE * FROM tbl_header_slider WHERE hdslId='$id'";
        $deletedata=$this->db->delete($query);
        if ($deletedata){
            $msg_success="<span class='text-success text-bold ml-5'>
                            Product header Slider Removed Successfully!!
                          </span>";
            return $msg_success;
        }else{
            $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle mr-1'>
                             Product header Slider not Removed!!
                             </i>
                          </span>";
            return $msg_invalid;
       }
	   }
       //Product category Insert method class
       public function InsertPro_intro_slider($data,$file){
        $slider_ttl=$this->fm->validation($data['slider_ttl']);
        $slider_ttl=mysqli_real_escape_string( $this->db->link,$data['slider_ttl']);
        $prd_type=$this->fm->validation(base64_decode($data['prd_type']));
        $prd_type=mysqli_real_escape_string( $this->db->link,base64_decode($data['prd_type']));

        $permited    = array('jpg','jpeg','png','gif','video');
        $pro_image1  =$file['slider_img1']['name'];
        $pro_image2  =$file['slider_img2']['name'];
        $pro_image3  =$file['slider_img3']['name'];

        $slider_imgsz1=$file['slider_img1']['size'];
        $slider_imgsz2=$file['slider_img2']['size'];
        $slider_imgsz3=$file['slider_img3']['size'];

        $file_tmp1   =$file['slider_img1']['tmp_name'];
        $file_tmp2   =$file['slider_img2']['tmp_name'];
        $file_tmp3   =$file['slider_img3']['tmp_name'];

        $div1         =explode('.', $pro_image1);
        $div2         =explode('.', $pro_image2);
        $div3         =explode('.', $pro_image3);
        $file_txt1   =strtolower(end($div1));
        $file_txt2   =strtolower(end($div2));
        $file_txt3   =strtolower(end($div3));
       // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image too}
       $unique_image1=substr(md5(time()),0,10).'.'.$file_txt1;
       $unique_image2=substr(md5(time()),0,11).'.'.$file_txt2;
       $unique_image3=substr(md5(time()),0,12).'.'.$file_txt3;
       $upload_image1="Uploads/".$unique_image1;
       $upload_image2="Uploads/".$unique_image2;
       $upload_image3="Uploads/".$unique_image3;
	   
       $checkquery="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='$prd_type'  LIMIT 1" ;
        $check=$this->db->select($checkquery);
        if($check !=false){
			$msg="<h6 class='alert alert-danger' id='close_note'>
                      Product Section all ready exist!!.
				    <i class='fa fa-close pull-right' id='close_tap'></i>
                  </h6>";
             return $msg;
        }
        if (empty($slider_ttl) || empty($prd_type) || empty($pro_image1)|| empty($pro_image2)|| empty($pro_image3)){
            $msg="<h6 class='alert alert-danger' id='close_note'>
                       Field must not be emty!!
				    <i class='fas fa-close pull-right' id='close_tap'></i>
                  </h6>";
             return $msg;
          }elseif($slider_imgsz1>1048567|| $slider_imgsz2>1048567 || $slider_imgsz3>1048567){
          echo "<h5 class='alert alert-danger' id='close_note'>
                    <i class='fas fa-exclamation-triangle mr-1' id='close_tap'>
                      Product Image too large!!
                    </i>
               </h5>";
         }
          elseif(in_array($file_txt1,$permited)==false){
           echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
          }
          elseif(in_array($file_txt2,$permited)==false){
           echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
          }
          elseif(in_array($file_txt3,$permited)==false){
           echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
           }else{
            move_uploaded_file( $file_tmp1, $upload_image1);
            move_uploaded_file( $file_tmp2, $upload_image2);
            move_uploaded_file( $file_tmp3, $upload_image3);
           $query ="INSERT INTO tbl_pro_intro_slider(slider_ttl,pro_typeId,slider_img1,slider_img2,slider_img3) VALUES('$slider_ttl','$prd_type','$upload_image1','$upload_image2','$upload_image3')";
           $Pro_type_insert=$this->db->insert($query);

           if($Pro_type_insert) {
            $msg_success="<h5 class='alert alert-success'>Product Intro Slider Inserted Successfully!!</h5>";
            return $msg_success;
            }else{
            $msg_error="<h5 class='alert alert-danger'>Product Intro Slider not Inserted!!</h5>";
            return $msg_error;
          }  
        } 
      }
      public function update_intro_slider($data,$file,$id){
        $up_slider_ttl=$this->fm->validation($data['up_slider_ttl']);
        $up_slider_ttl=mysqli_real_escape_string($this->db->link,$data['up_slider_ttl']);
        $pro_typeId  =$this->fm->validation($data['pro_typeId']);
        $pro_typeId  =mysqli_real_escape_string( $this->db->link,$data['pro_typeId']);
        $up_add_date =$this->fm->validation($data['up_add_date']);
        $up_add_date  =mysqli_real_escape_string($this->db->link,$data['up_add_date']);
 
        $permited    = array('jpg' ,'jpeg','png','gif');
        $slider_img1  =$file['up_slider_img1']['name'];
        $slider_img2  =$file['up_slider_img2']['name'];
        $slider_img3  =$file['up_slider_img3']['name'];
 
        $slider_imgsz1=$file['up_slider_img1']['size'];
        $slider_imgsz2=$file['up_slider_img2']['size'];
        $slider_imgsz3=$file['up_slider_img3']['size'];
 
        $file_tmp1   =$file['up_slider_img1']['tmp_name'];
        $file_tmp2   =$file['up_slider_img2']['tmp_name'];
        $file_tmp3   =$file['up_slider_img3']['tmp_name'];
 
        $div1         =explode('.', $slider_img1);
        $div2        =explode('.', $slider_img2);
        $div3        =explode('.', $slider_img3);
        $file_txt1   =strtolower(end($div1));
        $file_txt2   =strtolower(end($div2));
        $file_txt3   =strtolower(end($div3));
 
        $unique_image1=substr(md5(time()),0,10).'.'.$file_txt1;
        $unique_image2=substr(md5(time()),0,11).'.'.$file_txt2;
        $unique_image3=substr(md5(time()),0,12).'.'.$file_txt3;
        $upload_image1="Uploads/".$unique_image1;
        $upload_image2="Uploads/".$unique_image2;
        $upload_image3="Uploads/".$unique_image3;
 
        if ($up_add_date==""){
             $msg ="<h4 class='alert alert-danger'>
                      <i class='fas fa-exclamation-triangle mr-1'>
                        Field name must not empty!!
                      </i>
                    </h4>";
           return $msg;
        }else{
           if(!empty($slider_img1)|| !empty($slider_img2) || !empty($slider_img3)){
              if($slider_imgsz1>1048567|| $slider_imgsz2>1048567 || $slider_imgsz3>1048567){
               echo "<h5 class='alert alert-danger'>Product not Updated Diew to too much large file!!</h5>";
              }elseif (in_array($file_txt1,$permited)==false){
               echo "<h3 class='alert alert-danger'>You can upload only:-".implode(',', $permited)."</h3>";
              }elseif(in_array($file_txt2,$permited)==false){
                echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',$permited)."</h5>";
              }elseif(in_array($file_txt3,$permited)==false){
               echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',$permited)."</h5>";
              }
              else{
               move_uploaded_file( $file_tmp1, $upload_image1);
               move_uploaded_file( $file_tmp2, $upload_image2);
               move_uploaded_file( $file_tmp3, $upload_image3);
               $query="UPDATE tbl_pro_intro_slider
                      SET
                      slider_ttl='$up_slider_ttl',
                      pro_typeId='$pro_typeId',
                      slider_img1='$upload_image1',
                      slider_img2='$upload_image2',
                      slider_img3='$upload_image3',
                      add_date   ='$up_add_date'
                      WHERE intro_slId='$id'";
              $ProductUpdate=$this->db->update($query);
 
           if($ProductUpdate){
           $msg_success="<h4 class='alert alert-success'>
                            <i class='fas fa-exclamation-triangle mr-1'>
                                 Product updated successfully!!
                             </i>
                         </h4>";
           return $msg_success;
          }else{
           $msg ="<h4 class='alert alert-danger'>
                      <i class='fas fa-exclamation-triangle mr-1'>
                        Product not Updated..!!
                      </i>
                    </h4>";
           return $msg;
          }
        }
       }
       else{
             $query="UPDATE tbl_pro_intro_slider
                      SET
                      slider_ttl='$up_slider_ttl',
                      pro_typeId='$pro_typeId',
                      add_date  ='$up_add_date'
                WHERE intro_slId='$id'";
 
                $ProductUpdate=$this->db->update($query);
                if($ProductUpdate){
                $msg_success="<h4 class='alert alert-success'>
                               <i class='fas fa-check-circle mr-1'>
                                 Product Updated Successfully!!
                               </i>
                             </h4>";
                return $msg_success;
                }else{
                $msg ="<h4 class='alert alert-danger'>
                        <i class='fas fa-exclamation-triangle mr-1'>
                          Product not Updated..!!
                        </i>
                      </h4>";
                return $msg;
               }
             }
          }
       }
       public function del_slider_intro($id){
         $query="DELETE FROM tbl_pro_intro_slider WHERE intro_slId='$id'";
         $deletedata=$this->db->delete($query);
        if ($deletedata){
            $msg_success="<span class='text-success text-bold ml-5'>
                            Product Intro Slider Removed Successfully!!
                          </span>";
            return $msg_success;
        }else{
            $msg_invalid="<span class='text-danger text-bold ml-5'>
                             <i class='fas fa-exclamation-triangle mr-1'>
                             Product Intro Slider not Removed!!
                             </i>
                          </span>";
            return $msg_invalid;
       }
       }
      public function getallPro_intro_slider(){
        $query   ="SELECT * FROM tbl_pro_intro_slider ORDER BY pro_typeId DESC";
        $result  =$this->db->select($query);
        return $result;
      }
      public function getPro_intro_slider_ById($id){
        $query  ="SELECT * FROM tbl_pro_intro_slider WHERE 	intro_slId='$id'";
        $result =$this->db->select($query);
        return $result;
      }
      public function getPro_intro_slider_count(){
          $query ="SELECT * FROM tbl_pro_intro_slider ORDER BY pro_typeId ASC";
          $result=$this->db->select($query);
          if ($result==true) {
              $count=mysqli_num_rows($result);
              return "(".$count.")";
          }else{
            echo "(empty)";
          }
      }
	  public function getPro_intro_slide_count(){
         $query   ="SELECT * FROM tbl_pro_intro_slider ORDER BY pro_typeId ASC";
         $result  =$this->db->select($query);
	     $count=mysqli_num_rows($result);
         return $count;
      } 
	  //product slider  method class end
      public function getallPro_intro_slider_type1(){
      $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='1'";
      $result  =$this->db->select($query);
      return $result;
      }
      public function getallPro_intro_slider_type2(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='2'";
        $result  =$this->db->select($query);
        return $result;
      }
      public function getallPro_intro_slider_type3(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='3'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type4(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='4'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type5(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='5'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type6(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='6'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type7(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='7'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type8(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='8'";
        $result  =$this->db->select($query);
        return $result;
      }public function getallPro_intro_slider_type9(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='9'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type10(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='10'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type11(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='11'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type12(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='12'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type13(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='13'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type14(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='14'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type15(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='15'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type16(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='16'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type17(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='17'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type18(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='18'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type19(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='19'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type20(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='20'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type21(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='21'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type22(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='22'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type23(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='23'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type24(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='24'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type25(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='25'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type26(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='26'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type27(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='27'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type28(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='28'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type29(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='29'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type30(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='30'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type31(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='31'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type32(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='32'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type33(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='33'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type34(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='34'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type35(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='35'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type36(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='36'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type37(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='37'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type38(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='38'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type39(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='39'";
        $result  =$this->db->select($query);
        return $result;
      }
	  public function getallPro_intro_slider_type40(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='40'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type41(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='41'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type42(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='42'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type43(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='43'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type44(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='44'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type45(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='45'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type46(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='46'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type47(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='47'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type48(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='48'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type49(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='49'";
        $result  =$this->db->select($query);
        return $result;
      }
	   public function getallPro_intro_slider_type50(){
        $query   ="SELECT * FROM tbl_pro_intro_slider WHERE pro_typeId='50'";
        $result  =$this->db->select($query);
        return $result;
      }
      //product slider  method class end
      //category Seacrh method class
      public function search_proc_type($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_pro_type WHERE product_type LIKE '%$search%' OR product_type_tle like '%$search%' OR product_section_tle like '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
     //product vatInsert method
     public function vatInsert($vat,$vatname,$vatprcnt){
       $vat=$this->fm->validation($vat);
       $vat=mysqli_real_escape_string( $this->db->link,$vat);
       $vatprcnt=$this->fm->validation($vatprcnt);
       $vatprcnt=mysqli_real_escape_string( $this->db->link,$vatprcnt);
       $vatname=$this->fm->validation($vatname);
       $vatname=mysqli_real_escape_string( $this->db->link,$vatname);
       if (empty($vat)|| empty($vatname)|| empty($vatprcnt)){
          $msg ="<h4 class='alert alert-danger'>Vat name must not be emty!!</h4>";
          return $msg;
       }else{
        $query ="INSERT INTO tbl_vat(vatname,vat,vatprcnt) VALUES('$vatname','$vat','$vatprcnt')";
        $Vatinsert=$this->db->insert($query);
        if ($Vatinsert) {
          $msg_success="<h4 class='alert alert-success'>Vat Inserted Successfully!!</h4>";
          return $msg_success;
        }else{
           $msg_error="<h4 class='alert alert-danger'>Vat not Inserted!!</h4>";
          return $msg_error;
        }
      }
     }
      //get all product vat method
     public function getvats(){
        $query ="SELECT * FROM tbl_vat ORDER BY vatId ASC";
        $result=$this->db->select($query);
         if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
     }
     public function getallvat(){
        $query   ="SELECT * FROM tbl_vat ORDER BY vatId ASC";
        $result  =$this->db->select($query);
        return $result;
     }
     //getCatById method class
     public function getvatById($id){
        $query   ="SELECT * FROM tbl_vat WHERE vatId='$id'";
        $result  =$this->db->select($query);
        return $result;
     }
     public function vatDelete($id){
         $query   ="DELETE FROM tbl_vat WHERE vatId='$id'";
         $deletedata=$this->db->delete($query);
      if ($deletedata){
             $msg_success="<span class='text-success text-bold ml-5'>
                             Vat Deleted Successfully!!
                           </span>";
             return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Vat not Deleted!!
                              </i>
                           </span>";
             return $msg_invalid;
        }
      }
      public function search_vat($search){
        $search=$this->fm->validation($search);
        $search=mysqli_real_escape_string( $this->db->link,$search);
        $sql="SELECT * FROM tbl_vat WHERE vatname LIKE '%$search%' OR vat like '%$search%' OR vatprcnt LIKE '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
      //Product category Update method class
     public function vatUpdate($upvat_name,$up_vat,$up_prcnt,$up_date,$id){
        $upvat_name=$this->fm->validation($upvat_name);
        $upvat_name=mysqli_real_escape_string( $this->db->link,$upvat_name);
        $up_vat=$this->fm->validation($up_vat);
        $up_vat=mysqli_real_escape_string( $this->db->link,$up_vat);
        $up_prcnt=$this->fm->validation($up_prcnt);
        $up_prcnt=mysqli_real_escape_string( $this->db->link,$up_prcnt);
        $up_date=$this->fm->validation($up_date);
        $up_date=mysqli_real_escape_string( $this->db->link,$up_date);
        $id     =mysqli_real_escape_string( $this->db->link,$id);
       if (empty($upvat_name) || empty($up_vat)|| empty($up_prcnt)|| empty($up_date)){
          $msg="<h4 class='alert alert-danger'>Filed must not be emty!!</h4>";
          return $msg;
       }else{
          $query  ="UPDATE tbl_vat
                    SET vatname ='$upvat_name',
                        vat     ='$up_vat',
                        vatprcnt='$up_prcnt',
                        add_date='$up_date'
                    WHERE vatId ='$id'";
          $Update_row =$this->db->update($query);
          if($Update_row){
            echo "<script>window.open('userControl.php?view_Vat=on','_self');</script>";
         }else{
             $msg_invalid="<h4 class='alert alert-danger'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Vat not Updated!!
                              </i>
                           </h4>";
             return $msg_invalid;
           }
      }
     }
     public function insertdlcharge($dchrgname,$dchamnt){
       $dchrgname=$this->fm->validation($dchrgname);
       $dchrgname=mysqli_real_escape_string( $this->db->link,$dchrgname);
       $dchamnt=$this->fm->validation($dchamnt);
       $dchamnt=mysqli_real_escape_string( $this->db->link,$dchamnt);
       if (empty($dchrgname)|| empty($dchamnt)){
          $msg ="<h4 class='alert alert-danger'>Deliver Charge must not be emty!!</h4>";
          return $msg;
       }else{
        $query ="INSERT INTO tbl_dlchrge(dchrgname,dchamnt) VALUES('$dchrgname','$dchamnt')";
        $insertdlcharge=$this->db->insert($query);
        if ($insertdlcharge) {
          $msg_success="<h4 class='alert alert-success'>Deliver Charge Inserted Successfully!!</h4>";
          return $msg_success;
        }else{
           $msg_error="<h4 class='alert alert-danger'>Deliver Charge not Inserted!!</h4>";
          return $msg_error;
        }
      }
     }
     public function getalldlcharges(){
        $query ="SELECT * FROM tbl_dlchrge ORDER BY dlchrgId ASC";
        $result=$this->db->select($query);
         if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
     }
     public function getalldlcharge(){
        $query   ="SELECT * FROM tbl_dlchrge ORDER BY dlchrgId ASC";
        $result  =$this->db->select($query);
        return $result;
     }
     //getCatById method class
     public function getdlchargeById($id){
        $query   ="SELECT * FROM tbl_dlchrge WHERE dlchrgId='$id'";
        $result  =$this->db->select($query);
        return $result;
     }
      //Product category Update method class
     public function dlchargeUpdate($up_dchrgname,$up_dchamnt,$up_date,$id){
        $up_dchrgname=$this->fm->validation($up_dchrgname);
        $up_dchrgname=mysqli_real_escape_string( $this->db->link,$up_dchrgname);
        $up_dchamnt=$this->fm->validation($up_dchamnt);
        $up_dchamnt=mysqli_real_escape_string( $this->db->link,$up_dchamnt);
        $up_date=$this->fm->validation($up_date);
        $up_date=mysqli_real_escape_string( $this->db->link,$up_date);
        $id     =mysqli_real_escape_string( $this->db->link,$id);
       if (empty($up_dchrgname) || empty($up_dchamnt)|| empty($up_date)){
          $msg="<h4 class='alert alert-danger'>Delivery Charge Filed must not be emty!!</h4>";
          return $msg;
       }else{
          $query  ="UPDATE tbl_dlchrge
                    SET dchrgname='$up_dchrgname',
                        dchamnt  ='$up_dchamnt',
                        add_date ='$up_date'
                    WHERE dlchrgId ='$id'";
          $Update_row =$this->db->update($query);
          if($Update_row){
            echo "<script>window.open('userControl.php?view_delvry=on','_self');</script>";
         }else{
             $msg_invalid="<h4 class='alert alert-danger'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Delivery Charge not Updated!!
                              </i>
                           </h4>";
             return $msg_invalid;
           }
      }
     }
     public function deldlcgDelete($id){
         $query   ="DELETE FROM tbl_dlchrge WHERE dlchrgId='$id'";
         $deletedata=$this->db->delete($query);
      if ($deletedata){
             $msg_success="<span class='text-success text-bold ml-5'>
                             Deliver Charge Deleted Successfully!!
                           </span>";
             return $msg_success;
         }else{
             $msg_invalid="<span class='text-danger text-bold ml-5'>
                              <i class='fas fa-exclamation-triangle mr-1'>
                                 Deliver Charge not Deleted!!
                              </i>
                           </span>";
             return $msg_invalid;
        }
     }
     public function search_dlvch($search){
       $search=$this->fm->validation($search);
       $search=mysqli_real_escape_string( $this->db->link,$search);
       $sql="SELECT * FROM tbl_dlchrge WHERE dchrgname LIKE '%$search%' OR dchamnt like '%$search%' OR add_date LIKE '%$search%'";
        $searchData = $this->db->select($sql);
       return $searchData;
      }
     public function sliderImageInsert($data,$file){
      $slide_title=$this->fm->validation($data['slide_title']);
      $slide_title=mysqli_real_escape_string( $this->db->link,$data['slide_title']);

      $permited    = array('jpg' ,'jpeg','png','gif','pdf');
      $file_name   =$file['slide_image']['name'];
      $file_size   =$file['slide_image']['size'];
      $file_tmp    =$file['slide_image']['tmp_name'];

      $div         =explode('.', $file_name);
      $file_txt    =strtolower(end($div));
       // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image too}
       $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
       $upload_image="Uploads/".$unique_image;

       if($slide_title==""||$file_name==""){
          $msg ="<P class='text-danger error mt-1'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Field name must not empty!!
                     </i>
                   </P>";
          return $msg;
       }
       elseif($file_size>1048567){
          echo "<h5 class='text-danger'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Product Image too large!!
                     </i>
                </h5>";
        }
        elseif(in_array($file_txt,$permited)==false){
          echo "<h5 class='text-danger'>You can upload only:-".implode(',', $permited)."</h5>";
        }
        else{
            move_uploaded_file( $file_tmp, $upload_image);
            $query ="INSERT INTO  tbl_slider(slide_text,slideImage) VALUES('$slide_title','$upload_image')";
            $Productinsert=$this->db->insert($query);
        if ($Productinsert) {
          $msg_success="<h5 class='text-success'>
                            <i class='fas fa-check-circle mr-1'>
                               Slider Inserted Successfully!!
                            </i>
                        </h5>";
          return $msg_success;
        }else{
            $msg_error="<h5 class='text-danger'>
                           <i class='fas fa-exclamation-triangle mr-1'>
                                Slider not Inserted!!
                            </i>
                        </h5>";
          return $msg_error;
         }

       }
     }
     public function getAllslider(){
        $query ="SELECT * FROM tbl_slider ORDER BY sldId DESC";
        $result=$this->db->select($query);
        return $result;
     }
     public function getsliderById($id){
        $query   ="SELECT * FROM tbl_slider WHERE sldId='$id'";
        $result  =$this->db->select($query);
        return $result;
     }
     public function slider_update($data,$file,$id){
       $slide_text =$this->fm->validation($data['slide_text']);
       $slide_text =mysqli_real_escape_string( $this->db->link,$data['slide_text']);

       $permited    = array('jpg' ,'jpeg','png','gif');
       $file_name   =$file['slideImage']['name'];
       $file_size   =$file['slideImage']['size'];
       $file_tmp    =$file['slideImage']['tmp_name'];

       $div         =explode('.', $file_name);
       $file_txt    =strtolower(end($div));
       $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
       $upload_image="Uploads/".$unique_image;

       if ($slide_text==""||$upload_image=="" ){
            $msg ="<P class='text-danger error mt-1'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Field name must not empty!!
                     </i>
                   </P>";
          return $msg;
       }else{
          if(!empty($file_name)){

             if($file_size>1048567){
              echo "<h5 class='text-danger'>Slider not Inserted!!</h5>";
             }elseif (in_array($file_txt, $permited)==false){
              echo "<h3 class='text-danger'>You can upload only:-".implode(',', $permited)."</h3>";
             }else{
              move_uploaded_file( $file_tmp,$upload_image);
              $query="UPDATE tbl_slider
                     SET
                     slide_text='$slide_text',
                     slideImage='$upload_image'
                     WHERE sldId='$id'";
             $sliderUpdate=$this->db->update($query);
          if($sliderUpdate){
          $msg_success="<P class='text-success success mt-1'>
                           <i class='fas fa-exclamation-triangle mr-1'>
                            </i>Slider updated successfully!!
                        </P>";
          return $msg_success;
         }else{
          $msg ="<P class='text-danger error mt-1'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                     </i> Slider not Updated..!!
                   </P>";
          return $msg;
         }
       }
      }
      else{
            $query="UPDATE tbl_slider
                     SET
                     slide_text='$slide_text'
                     WHERE sldId='$id'";
            $sliderUpdate=$this->db->update($query);
            if($sliderUpdate){
            $msg_success="<P class='text-success success mt-1'>
                           <i class='fas fa-check-circle mr-1'>
                           </i> Slider Updated Successfully!!
                        </P>";
            return $msg_success;
            }else{
            $msg ="<P class='text-danger error mt-1'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                     </i> Slider not Updated..!!
                   </P>";
              return $msg;
             }
          }
       }
   }
  }
?>
