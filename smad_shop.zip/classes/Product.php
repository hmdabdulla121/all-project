<?php
    $filepath= realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
 ?>
<?php
class Product{
	 private $db;
	 private $fm;

     public function __construct(){
	   $this->db =new Database();
	   $this->fm =new Format();
   }//productInsert method class
   public function productInsert($data,$file){
   	   $p_name  =$this->fm->validation($data['p_name']);
       $p_name  =mysqli_real_escape_string( $this->db->link,$data['p_name']);
       $catId   =$this->fm->validation($data['catId']);
       $catId   =mysqli_real_escape_string( $this->db->link,$data['catId']);
       $catproId=$this->fm->validation($data['catproId']);
       $catproId=mysqli_real_escape_string( $this->db->link,$data['catproId']);
       $brandId =$this->fm->validation($data['brandId']);
       $brandId =mysqli_real_escape_string( $this->db->link,$data['brandId']);
       $body    =$this->fm->validation($data['body']);
       $body    =mysqli_real_escape_string( $this->db->link,$data['body']);
       $price   =$this->fm->validation($data['price']);
       $price   =mysqli_real_escape_string( $this->db->link,$data['price']);
       $pbl_dt  =$this->fm->validation($data['pbl_dt']);
       $pbl_dt        =mysqli_real_escape_string( $this->db->link,$data['pbl_dt']);
       $prd_type=$this->fm->validation(base64_decode($data['prd_type']));
       $prd_type=mysqli_real_escape_string( $this->db->link,base64_decode($data['prd_type']));

       //Generate deliver key
       $pro_delikey =md5(time().$p_name);

       $permited    = array('jpg' ,'jpeg','png','gif');
       $pro_imageL  =$file['pro_imageL']['name'];
       $pro_imageM  =$file['pro_imageM']['name'];
       $pro_imageS  =$file['pro_imageS']['name'];

       $pro_imageLsz=$file['pro_imageL']['size'];
       $pro_imageMsz=$file['pro_imageM']['size'];
       $pro_imageSsz=$file['pro_imageS']['size'];

       $file_tmpL   =$file['pro_imageL']['tmp_name'];
       $file_tmpM   =$file['pro_imageM']['tmp_name'];
       $file_tmpS   =$file['pro_imageS']['tmp_name'];

       $divL         =explode('.', $pro_imageL);
       $divM         =explode('.', $pro_imageM);
       $divS         =explode('.', $pro_imageS);
       $file_txtL   =strtolower(end($divL));
       $file_txtM   =strtolower(end($divM));
       $file_txtS   =strtolower(end($divS));
       // $fileNameNew=uniqid('',true).".".$fileActualExt;{You can use making uniq image too}
       $unique_imageL=substr(md5(time()),0,10).'.'.$file_txtL;
       $unique_imageM=substr(md5(time()),0,11).'.'.$file_txtM;
       $unique_imageS=substr(md5(time()),0,12).'.'.$file_txtS;
       $upload_imageL="Uploads/".$unique_imageL;
       $upload_imageM="Uploads/".$unique_imageM;
       $upload_imageS="Uploads/".$unique_imageS;

       if($p_name=="" || $catId==""|| $catproId=="" || $brandId=="" ||$body=="" ||$price=="" ||$pro_imageL==""||$pro_imageM==""||$pro_imageS=="" || $pbl_dt=="" || $prd_type==""){
       	  $msg ="<P class='alert alert-danger mt-1'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Field name must not empty!!
                     </i>
                   </P>";
          return $msg;
       }
       elseif($pro_imageLsz>1048567){
         	echo "<h5 class='text-danger'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Product Image too large!!
                     </i>
                </h5>";
        }
        elseif(in_array($file_txtL,$permited)==false){
          echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
        }
        elseif(in_array($file_txtM,$permited)==false){
          echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
        }
        elseif(in_array($file_txtS,$permited)==false){
        	echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',   $permited)."</h5>";
        }
        else{
            move_uploaded_file( $file_tmpL, $upload_imageL);
            move_uploaded_file( $file_tmpM, $upload_imageM);
            move_uploaded_file( $file_tmpS, $upload_imageS);
            $query ="INSERT INTO tbl_product(p_name,catId,catproId,brandId,body,price,pro_imageL,pro_imageM,pro_imageS,pbl_dt,prd_type,pro_delikey) VALUES('$p_name','$catId','$catproId','$brandId','$body','$price','$upload_imageL','$upload_imageM','$upload_imageS','$pbl_dt','$prd_type','$pro_delikey')";
           	$Productinsert=$this->db->insert($query);
       	if ($Productinsert) {
       		$msg_success="<h5 class='alert alert-success'>
                            <i class='fas fa-check-circle mr-1'>
                               Product Inserted Successfully!!
                            </i>
                        </h5>";
       		return $msg_success;
       	}else{
            $msg_error="<h5 class='alert alert-danger'>
                           <i class='fas fa-exclamation-triangle mr-1'>
                                Product not Inserted!!
                            </i>
                        </h5>";
       		return $msg_error;
       	}
       }
    }//getallproduct method class
    public function getallproduct(){
      //aliecing method
        $query="SELECT p.*,c.Category,b.brandName,ctp.product
            FROM  tbl_product as p,tbl_category as c,tbl_brand as b,tbl_pro_category as ctp
            WHERE p.catId=c.catId AND p.brandId=b.brandId AND p.catproId=ctp.catproId
            ORDER BY p.productId DESC";
       //3 table joindg method
       // $query ="SELECT tbl_product.*,tbl_category.catName, tbl_brand.brandName
       //          FROM tbl_product
       //          INNER JOIN tbl_category
       //          ON tbl_product.catId=tbl_category.catId

       //          INNER JOIN tbl_brand
       //          ON tbl_product.brandId=tbl_brand.brandId
       //          ORDER BY tbl_product.productId DESC";
        $result  =$this->db->select($query);
        return $result;
    }
    public function search_product($search){
       $search_sql="SELECT * FROM tbl_product WHERE p_name LIKE '%$search%' OR body like '%$search%' OR price LIKE '%$search%'  OR prd_type LIKE '%$search%'";
       $searchData = $this->db->select($search_sql);
       return $searchData;
    }
	//serch product line 140
	public function product_search($search){
	  $search=$this->fm->validation($search);
      $search=mysqli_real_escape_string( $this->db->link,$search);
	  $sql="SELECT * FROM tbl_product WHERE 	p_name LIKE '%$search%' OR body like '%$search%' OR price LIKE '%$search%' OR pbl_dt LIKE '%$search%' OR prd_type LIKE '%$search%'";
      $searchData = $this->db->select($sql);
      return $searchData; 
	}
	//serch product line 140
	public function product_search_count($search){
	  $search=$this->fm->validation($search);
      $search=mysqli_real_escape_string($this->db->link,$search);
	  $sql="SELECT * FROM tbl_product WHERE p_name LIKE '%$search%' OR body like '%$search%' OR price LIKE '%$search%' OR pbl_dt LIKE '%$search%' OR prd_type LIKE '%$search%'";
      $searchData = $this->db->select($sql);
	  if($searchData==true) {
            $count=mysqli_num_rows($searchData);
            return "(".$count.")";
       }else{
          $msg= "(is Invalid search or search query failed.Please search with right keys)";
		  return $msg;
       }
	}
    public function getAlproduct(){
       $query ="SELECT * FROM tbl_product ORDER BY productId ASC";
       $result=$this->db->select($query);
       if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }else{
          echo "(empty)";
        }
    }
    public function getAlproducttbl(){
        $query ="SELECT * FROM tbl_product ORDER BY productId ASC";
        $result=$this->db->select($query);
        if ($result==true) {
            $count=mysqli_num_rows($result);
            return "(".$count.")";
        }
     }
    public function getShopproduct(){
      //aliecing method
        $per_page=6;
        if (isset($_GET["page"])) {
           $page=$_GET["page"];
        }else{
           $page=1;
        }
        $start_from=($page-1)*$per_page;
        $query="SELECT p.*,c.catName,b.brandName,ctp.ct_proname
        FROM  tbl_product as p,tbl_category as c,tbl_brand as b,tbl_pro_category as ctp
        WHERE p.catId=c.catId AND p.brandId=b.brandId AND p.catproId=ctp.catproId
        ORDER BY p.productId DESC LIMIT $start_from,$per_page";
       //3 table joindg method
       // $query ="SELECT tbl_product.*,tbl_category.catName, tbl_brand.brandName
       //          FROM tbl_product
       //          INNER JOIN tbl_category
       //          ON tbl_product.catId=tbl_category.catId

       //          INNER JOIN tbl_brand
       //          ON tbl_product.brandId=tbl_brand.brandId
       //          ORDER BY tbl_product.productId DESC";
        $result  =$this->db->select($query);
        return $result;
    }
    public function getShopproduct_like(){
      //aliecing method
        $query="SELECT p.*,c.Category,b.brandName,ctp.product
            FROM  tbl_product as p,tbl_category as c,tbl_brand as b,tbl_pro_category as ctp
            WHERE p.catId=c.catId AND p.brandId=b.brandId AND p.catproId=ctp.catproId
            ORDER BY rand() LIMIT 0,4";
       //3 table joindg method
       // $query ="SELECT tbl_product.*,tbl_category.catName, tbl_brand.brandName
       //          FROM tbl_product
       //          INNER JOIN tbl_category
       //          ON tbl_product.catId=tbl_category.catId

       //          INNER JOIN tbl_brand
       //          ON tbl_product.brandId=tbl_brand.brandId
       //          ORDER BY tbl_product.productId DESC";
        $result  =$this->db->select($query);
        return $result;
    }
    public function getCartProduct_like(){
      //aliecing method
        $query="SELECT p.*,c.catName,b.brandName,ctp.ct_proname
            FROM  tbl_product as p,tbl_category as c,tbl_brand as b,tbl_pro_category as ctp
            WHERE p.catId=c.catId AND p.brandId=b.brandId AND p.catproId=ctp.catproId
            ORDER BY rand() LIMIT 0,5";
       //3 table joindg method
       // $query ="SELECT tbl_product.*,tbl_category.catName, tbl_brand.brandName
       //          FROM tbl_product
       //          INNER JOIN tbl_category
       //          ON tbl_product.catId=tbl_category.catId

       //          INNER JOIN tbl_brand
       //          ON tbl_product.brandId=tbl_brand.brandId
       //          ORDER BY tbl_product.productId DESC";
        $result  =$this->db->select($query);
        return $result;
    }//getProById method class
    public function activation($actId){
      $id=$this->fm->validation($actId);
      $query="UPDATE tbl_product
                     SET
                     status ='1'
                     WHERE productId='$id'";
        $ProductUpdate=$this->db->update($query);
        return $ProductUpdate;
    }
    public function Inactivation($InactId){
      $id=$this->fm->validation($InactId);
      $query="UPDATE tbl_product
                     SET
                     status ='0'
                     WHERE productId='$id'";
        $ProductUpdate=$this->db->update($query);
        return $ProductUpdate;
    }
    public function getProductByCat($smado_type_shop){
      $query   ="SELECT * FROM tbl_product WHERE prd_type='$smado_type_shop'";
      $result  =$this->db->select($query);
      return $result;
    }
	public function getProductBypro_Cat($smado_cat_shop){
      $query   ="SELECT * FROM tbl_product WHERE catproId='$smado_cat_shop'";
      $result  =$this->db->select($query);
      return $result;
    }
    public function ProductByCatId($smado_cat_shop){
      $query   ="SELECT * FROM tbl_product WHERE catId='$smado_cat_shop'";
      $result  =$this->db->select($query);
      return $result;
    }
    public function getProById($id){
        $query   ="SELECT * FROM tbl_product WHERE productId='$id'";
        $result  =$this->db->select($query);
        return $result;
    }
    // product bt product Type
    public function ProductByproduct_CatId($smado_cat_shop){
      $query   ="SELECT * FROM tbl_product WHERE prd_type='$smado_cat_shop' ORDER BY rand() LIMIT 0,20";
      $result  =$this->db->select($query);
      return $result;
    }
    //productUpdate method class
    public function productUpdate($data,$file,$id){

       $up_name =$this->fm->validation($data['up_name']);
       $up_name =mysqli_real_escape_string( $this->db->link,$data['up_name']);
       $catId   =$this->fm->validation($data['catId']);
       $catId   =mysqli_real_escape_string( $this->db->link,$data['catId']);
       $brandId =$this->fm->validation($data['brandId']);
       $brandId =mysqli_real_escape_string( $this->db->link,$data['brandId']);
       $catproId=$this->fm->validation($data['catproId']);
       $catproId=mysqli_real_escape_string( $this->db->link,$data['catproId']);
       $body    =$this->fm->validation($data['body']);
       $body    =mysqli_real_escape_string( $this->db->link,$data['body']);
       $price   =$this->fm->validation($data['price']);
       $price   =mysqli_real_escape_string( $this->db->link,$data['price']);
       $pbl_dt  =$this->fm->validation($data['pbl_dt']);
       $pbl_dt  =mysqli_real_escape_string( $this->db->link,$data['pbl_dt']);
       $prd_type=$this->fm->validation($data['prd_type']);
       $prd_type=mysqli_real_escape_string( $this->db->link,$data['prd_type']);

       // $permited    = array('jpg' ,'jpeg','png','gif');
       // $file_name   =$file['up_img']['name'];
       // $file_size   =$file['up_img']['size'];
       // $file_tmp    =$file['up_img']['tmp_name'];

       // $div         =explode('.', $file_name);
       // $file_txt    =strtolower(end($div));
       // $unique_image=substr(md5(time()),0,10).'.'.$file_txt;
       // $upload_image="Uploads/".$unique_image;

       $permited    = array('jpg' ,'jpeg','png','gif');
       $pro_imageL  =$file['up_imgL']['name'];
       $pro_imageM  =$file['up_imgM']['name'];
       $pro_imageS  =$file['up_imgS']['name'];

       $pro_imageLsz=$file['up_imgL']['size'];
       $pro_imageMsz=$file['up_imgM']['size'];
       $pro_imageSsz=$file['up_imgS']['size'];

       $file_tmpL   =$file['up_imgL']['tmp_name'];
       $file_tmpM   =$file['up_imgM']['tmp_name'];
       $file_tmpS   =$file['up_imgS']['tmp_name'];

       $divL         =explode('.', $pro_imageL);
       $divM         =explode('.', $pro_imageM);
       $divS         =explode('.', $pro_imageS);
       $file_txtL   =strtolower(end($divL));
       $file_txtM   =strtolower(end($divM));
       $file_txtS   =strtolower(end($divS));

       $unique_imageL=substr(md5(time()),0,10).'.'.$file_txtL;
       $unique_imageM=substr(md5(time()),0,11).'.'.$file_txtM;
       $unique_imageS=substr(md5(time()),0,12).'.'.$file_txtS;
       $upload_imageL="Uploads/".$unique_imageL;
       $upload_imageM="Uploads/".$unique_imageM;
       $upload_imageS="Uploads/".$unique_imageS;

       if ($up_name=="" || $catId=="" || $brandId==""|| $catproId=="" ||$body=="" ||$price=="" || $pbl_dt=="" || $prd_type==""){
            $msg ="<h4 class='alert alert-danger'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Field name must not empty!!
                     </i>
                   </h4>";
          return $msg;
       }else{
          if(!empty($pro_imageL)|| !empty($pro_imageM) || !empty($pro_imageS)){
             if($pro_imageLsz>1048567|| $pro_imageMsz>1048567 || $pro_imageSsz>1048567){
              echo "<h5 class='alert alert-danger'>Product not Updated Diew to too much large file!!</h5>";
             }elseif (in_array($file_txtL,$permited)==false){
              echo "<h3 class='alert alert-danger'>You can upload only:-".implode(',', $permited)."</h3>";
             }elseif(in_array($file_txtM,$permited)==false){
               echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',$permited)."</h5>";
             }elseif(in_array($file_txtS,$permited)==false){
              echo "<h5 class='alert alert-danger mt-1'>You can upload only:-".implode(',',$permited)."</h5>";
             }
             else{
              move_uploaded_file( $file_tmpL, $upload_imageL);
              move_uploaded_file( $file_tmpM, $upload_imageM);
              move_uploaded_file( $file_tmpS, $upload_imageS);
              $query="UPDATE tbl_product
                     SET
                     p_name   ='$up_name',
                     catId    ='$catId',
                     brandId  ='$brandId',
                     catproId ='$catproId',
                     body     ='$body',
                     price    ='$price',
                     pro_imageL='$upload_imageL',
                     pro_imageM='$upload_imageM',
                     pro_imageS='$upload_imageS',
                     pbl_dt    ='$pbl_dt',
                     prd_type  ='$prd_type'
                     WHERE productId='$id'";
             $ProductUpdate=$this->db->update($query);

          if($ProductUpdate){
          $msg_success="<h4 class='alert alert-success'>
                           <i class='fas fa-exclamation-triangle mr-1'>
                                Product updated successfully!!
                            </i>
                        </h4>";
          return $msg_success;
         }else{
          $msg ="<h4 class='alert alert-danger'>
                     <i class='fas fa-exclamation-triangle mr-1'>
                       Product not Updated..!!
                     </i>
                   </h4>";
          return $msg;
         }
       }
      }
      else{
            $query="UPDATE tbl_product
                     SET
                     p_name    ='$up_name',
                     catId     ='$catId',
                     brandId   ='$brandId',
                     catproId  ='$catproId',
                     body      ='$body',
                     price     ='$price',
                     pbl_dt    ='$pbl_dt',
                     prd_type  ='$prd_type'
               WHERE productId ='$id'";

               $ProductUpdate=$this->db->update($query);
               if($ProductUpdate){
               $msg_success="<h4 class='alert alert-success'>
                              <i class='fas fa-check-circle mr-1'>
                                Product Updated Successfully!!
                              </i>
                            </h4>";
               return $msg_success;
               }else{
               $msg ="<h4 class='alert alert-danger'>
                       <i class='fas fa-exclamation-triangle mr-1'>
                         Product not Updated..!!
                       </i>
                     </h4>";
               return $msg;
              }
            }
         }
      }//Delete product method class
      public function delProById($id){
          $query      ="SELECT * FROM tbl_product WHERE productId='$id'";
          $getData    =$this->db->select($query);
       if($getData){
         while ($delImg  =$getData->fetch_assoc()){
                $imglink =$delImg['pro_imageL'];
                $imglink =$delImg['pro_imageM'];
                $imglink =$delImg['pro_imageS'];
               unlink($imglink) ;
              }
        }
          $delquery   ="DELETE FROM tbl_product WHERE productId='$id'";
          $delProData =$this->db->delete($delquery);
       if($delProData){
                 $msg_success="<h5 class='text-success text-bold ml-5'>
                                 <i class='fas fa-check-circle mr-1'>
                                    product Deleted
                                 </i>
                                </h5>";
          return $msg_success;
          }else{
                 $msg_invalid="<h5 class='text-danger text-bold ml-5'>
                                  <i class='fas fa-exclamation-triangle mr-1'>
                                    Product not Deleted!!
                                  </i>
                               </h5>";
           return $msg_invalid;
         }
      }
      public function get_allProduct(){
        $query ="SELECT * FROM tbl_product WHERE status='0'";
        $result=$this->db->select($query);
        return $result;
   }
      public function getFeaturedProduct(){
           $query ="SELECT * FROM tbl_product WHERE type='0' ORDER BY productId DESC ";
           $result=$this->db->select($query);
           return $result;
      }
      ////=============== get all 20 types product show method class.==================/////
	  public function getProd_see_all_type1(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='1' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
      public function getMenzProduct_type1(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='1' ORDER BY rand() LIMIT 0,8";
           $result=$this->db->select($query);
           return $result;
      }
      public function getMenzProduct_type1_count1(){
        $query ="SELECT * FROM tbl_product WHERE  prd_type='1' ORDER BY prd_type ASC";
        $result=$this->db->select($query);
        if ($result==true) {
            $count=mysqli_num_rows($result);
            return  $count;
        }
      }
	  public function getProd_see_all_type2(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='2' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
      public function getWomensProduct_type2(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='2' ORDER BY rand() LIMIT 0,8";
        $result=$this->db->select($query);
        return $result;
     }

	 public function getWomenProduct_type2_count2(){
        $query ="SELECT * FROM tbl_product WHERE  prd_type='2' ORDER BY prd_type ASC";
        $result=$this->db->select($query);
        if ($result) {
            $count=mysqli_num_rows($result);
            return  $count;
        }
      }
	 public function getProd_see_all_type3(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='3' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
     }
     public function getProduct_catBy_type3(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='3' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type3_count3(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='3' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getMenzProd_see_all_type4(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='4' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProd_see_all_type4(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='4' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type4(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='4' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getElectroProductBy_type4_count4(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='4' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type5(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='5' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type5(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='5' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type5_count5(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='5' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      $count=mysqli_num_rows($result);
      if ($count>=8){
          return  $count;
       }
     }
	 public function getProd_see_all_type6(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='6' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type6(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='6' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type6_count6(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='6' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      $count=mysqli_num_rows($result);
      if ($count>=8){
          return  $count;
       }
     }
	 public function getProd_see_all_type7(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='7' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type7(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='7' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type7_count7(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='7' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type8(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='8' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type8(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='8' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type8_count8(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='8' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type9(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='9' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type9(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='9' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type9_count9(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='9' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type10(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='10' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type10(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='10' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type10_count10(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='10' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type11(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='11' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type11(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='11' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type11_count11(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='11' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
     public function getProduct_catBy_type12(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='12' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type12_count12(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='12' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type13(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='13' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type13(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='13' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type13_count13(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='13' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type14(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='14' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type14(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='14' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type14_count14(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='14' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type15(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='15' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type15(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='15' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type15_count15(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='15' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type16(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='16' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type16(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='16' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type16_count16(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='16' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type17(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='17' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type17(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='17' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type17_count17(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='17' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type18(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='18' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type18(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='18' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type18_count18(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='18' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type19(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='19' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type19(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='19' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type19_count19(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='19' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type20(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='20' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
     public function getProduct_catBy_type20(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='20' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
     public function getProduct_catBy_type20_count20(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='20' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type21(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='21' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type21(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='21' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type21_count21(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='21' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type22(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='22' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type22(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='22' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type22_count22(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='22' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type23(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='23' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type23(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='23' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type23_count23(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='23' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type24(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='24' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type24(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='24' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type24_count24(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='24' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type25(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='25' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type25(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='25' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type25_count25(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='25' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type26(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='26' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type26(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='26' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type26_count26(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='26' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type27(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='27s' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type27(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='27' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type27_count27(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='27' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type28(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='28' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type28(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='28' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type28_count28(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='28' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type29(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='29' ORDER BY rand()";
           $result=$this->db->select($query);
           return $result;
      }
	 public function getProduct_catBy_type29(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='29' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type29_count29(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='29' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type30(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='30' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type30(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='30' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type30_count30(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='30' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type31(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='31' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type31(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='31' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type31_count31(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='31' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type32(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='32' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type32(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='32' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type32_count32(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='32' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type33(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='33' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type33(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='33' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type33_count33(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='33' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type34(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='34' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type34(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='34' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type34_count34(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='34' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type35(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='35' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type35(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='35' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type35_count35(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='35' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type36(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='36' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type36(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='36' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type36_count36(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='36' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type37(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='37' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type37(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='37' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type37_count37(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='37' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type38(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='38' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type38(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='38' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type38_count38(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='38' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type39(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='39' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type39(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='39' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type39_count39(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='39' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type40(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='40' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type40(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='40' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type40_count40(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='40' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type41(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='41' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type41(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='41' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type41_count41(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='41' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type42(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='42' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	 public function getProduct_catBy_type42(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='42' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type42_count42(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='42' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type43(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='43' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	public function getProduct_catBy_type43(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='43' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	public function getProduct_catBy_type43_count43(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='43' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type44(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='44' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type44(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='44' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type44_count44(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='44' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type45(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='45' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type45(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='45' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type45_count45(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='45' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type46(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='46' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type46(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='46' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type46_count46(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='46' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type47(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='47' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type47(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='47' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type47_count47(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='47' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type48(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='48' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type48(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='48' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type48_count48(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='48' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type49(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='49' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type49(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='49' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type49_count49(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='49' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
	 public function getProd_see_all_type50(){
        $query ="SELECT * FROM tbl_product WHERE prd_type='50' ORDER BY rand()";
        $result=$this->db->select($query);
        return $result;
      }
	  public function getProduct_catBy_type50(){
      $query ="SELECT * FROM tbl_product WHERE prd_type='50' ORDER BY rand() LIMIT 0,8";
      $result=$this->db->select($query);
      return $result;
     }
	  public function getProduct_catBy_type50_count50(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='50' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
     ////=============== get all 50 types product show method class.end==================/////
     public function getOfferProduct_count(){
      $query ="SELECT * FROM tbl_product WHERE  prd_type='9' ORDER BY prd_type ASC";
      $result=$this->db->select($query);
      if ($result==true) {
          $count=mysqli_num_rows($result);
          return  $count;
       }
     }
      public function getLatestProduct(){
           $query ="SELECT * FROM tbl_product WHERE prd_type='4' ORDER BY productId DESC ";
           $result=$this->db->select($query);
           return $result;

      }
      public function getOffertProduct(){
           $query ="SELECT * FROM tbl_product WHERE type='4' ORDER BY productId DESC ";
           $result=$this->db->select($query);
           return $result;
      }
      public function getSingleProduct($id){
           $query="SELECT p.*,c.Category,b.brandName,ctp.product
                  FROM  tbl_product as p,tbl_category as c,tbl_brand as b,tbl_pro_category as ctp
                  WHERE p.catId=c.catId AND p.brandId=b.brandId AND p.catproId=ctp.catproId AND p.productId='$id'";
           $result  =$this->db->select($query);
           return $result;
      }
      public function productByCat($id){
           $catId  =mysqli_real_escape_string( $this->db->link,$id);
           $query  ="SELECT * FROM tbl_product WHERE catId='$catId'";
           $result =$this->db->select($query);
           return $result;
      }
      public function CompareinsertData($cmprid,$cmrId){
           $cmrId       =mysqli_real_escape_string( $this->db->link,$cmrId);
           $productId   =mysqli_real_escape_string( $this->db->link,$cmprid);
           $comparequery="SELECT * FROM tbl_compare WHERE cmrId='$cmrId' AND productId='$productId'";
           $check = $this->db->select($comparequery);
           if($check){
             $msg_invalid="<span class='text-danger text-bold ml-1'>
                             Already Addeed!!
                          </span>";
             return $msg_invalid;
           }
           $query  ="SELECT * FROM tbl_product WHERE productId='$productId'";
           $result =$this->db->select($query)->fetch_assoc();
           if($result){
                   $productId = $result['productId'];
                   $productName = $result['productName'];
                   $price = $result['price'];
                   $image = $result['image'];
           $query="INSERT INTO  tbl_compare(cmrId,productId,productName,price,image) VALUES('$cmrId','$productId','$productName','$price','$image')";
                 $Insertorder=$this->db->insert($query);
                 if ($Insertorder) {
                    $msg_success="<span class='text-success text-bold ml-1'>
                                    Product Added !Check Compare Page.
                                  </span>";
                    return $msg_success;
                   }else{
                           $msg_invalid="<span class='text-danger text-bold ml-1'>
                                           Product not Added!!
                                         </span>";
                    return $msg_invalid;
           }
         }
       }
       public function getComparedData($cmrId){
            $cmrId =mysqli_real_escape_string( $this->db->link,$cmrId);
            $query ="SELECT * FROM tbl_compare WHERE cmrId='$cmrId' ORDER BY id DESC";
            $result=$this->db->select($query);
            return $result;
       }
       public function delCompareData($cmrId){
            $delquery   ="DELETE FROM tbl_compare WHERE cmrId='$cmrId'";
            $delProData =$this->db->delete($delquery);
       }
       public function saveWishListData($id,$cmrId){
            $id =mysqli_real_escape_string( $this->db->link,$id);
            $comparequery="SELECT * FROM tbl_wlist WHERE cmrId='$cmrId' AND productId='$id'";
            $check = $this->db->select($comparequery);
             if($check){
             $msg_invalid="<h6 class='alert alert-danger' id='close_note'>
                              Product already added to WishList!!
							  <i class='fa fa-close pull-right' id='close_tap'></i>
                          </h6>";
             return $msg_invalid;
			 
            }
            $query="SELECT * FROM tbl_product WHERE productId='$id'";
            $result=$this->db->select($query)->fetch_assoc();
              if($result){
                 $productId = $result['productId'];
                 $p_name    = $result['p_name'];
                 $price     = $result['price'];
                 $image     = $result['pro_imageL'];
             $query="INSERT INTO tbl_wlist(cmrId,productId,p_name,price,image) VALUES('$cmrId','$productId','$p_name','$price','$image')";
             $InsertRow=$this->db->insert($query);
             if($InsertRow){
                 $msg_success="<h6 class='alert alert-success' id='close_note'>
                                 Product added to WishList.
								  <i class='fa fa-close pull-right' id='close_tap'></i>
                              </h6>";
                 return $msg_success;
              }else{
                 $msg_invalid="<h6 class='alert alert-danger' id='close_note'>
                                Product not Added!!
								<i class='fa fa-close pull-right' id='close_tap'></i>
                              </h6>";
                 return $msg_invalid;
              }
         }
      }
       public function getAllsavelist($cmrId){
        $cmrId =mysqli_real_escape_string( $this->db->link,$cmrId);
        $query ="SELECT * FROM  tbl_wlist WHERE cmrId='$cmrId' ORDER BY id DESC";
        $result=$this->db->select($query);
        return $result;
       }
       public function delWlistData($id,$cmrId){
        $delquery="DELETE FROM tbl_wlist WHERE id='$id' AND cmrId='$cmrId'";
        $delWlistData =$this->db->delete($delquery);
        if($delWlistData){
            // $msg_success="<h5 class='alert alert-success'>
            //                <i class='fas fa-exclamation-triangle'>
            //                </i> Deleted Successfully!!
            //               </h5>";
            //  return $msg_success;
         echo "<script>window.open('my_account.php?savlist','_self')</script>";
        }else{
              $msg_invalid="<h5 class='alert alert-danger'>
                                 not Deleted!!
                            </h5>";
             return $msg_invalid;
           }
       }
       public function getsavelist_count($cmrId){
           $query ="SELECT * FROM tbl_wlist WHERE cmrId='$cmrId'";
           $result=$this->db->select($query);
            if ($result==true) {
               $count=mysqli_num_rows($result);
               return "(".$count.")";
           }else{
             echo "(empty)";
           }
        }
      public function search($requestArray){
         $sql="SELECT * FROM tbl_product WHERE name LIKE '%".$requestArray['serach']."%' OR address LIKE '%".$requestArray['serach']."%'";
         $allData = $this->db->select($sql)->fetch_assoc();
         return $allData;
       }
      public function search_pro($search){
        $sql="SELECT * FROM tbl_product WHERE productName LIKE '%$search%' OR body like '%$search%' OR Agent LIKE '%$search%' OR Ag_detail LIKE '%$search%' OR price LIKE '%$search%'  OR SignUpdate LIKE '%$search%'";
        $searchData = $this->db->select($sql);
        return $searchData;
      }
  }
?>
