<?php 
define('DB_HOST', 'localhost');
define('DB_USER', 'atifpzsg_shop');
define('DB_PASS', 'smadbd_@123X,');
define('DB_NAME', 'atifpzsg_smadbd');
 ?>